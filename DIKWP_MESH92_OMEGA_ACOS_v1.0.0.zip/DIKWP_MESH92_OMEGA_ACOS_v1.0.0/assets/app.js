(() => {
  "use strict";

  const payload = window.OMEGA_DATA || {};
  const run = payload.run || {};
  const battery = payload.battery || {};
  const validation = payload.validation || {};
  const content = document.getElementById("content");
  const nav = document.getElementById("nav");

  const sections = [
    ["overview", "总览", "◎"],
    ["claims", "主张边界", "!"],
    ["genesis", "原生发生", "∴"],
    ["subject", "主体内核", "Ω"],
    ["dikwp", "DIKWP闭环", "↻"],
    ["purpose", "目的因果实验", "P"],
    ["interiority", "功能性内在性", "C"],
    ["models", "多元世界模型", "M"],
    ["memory", "重构记忆", "R"],
    ["theories", "理论竞技场", "T"],
    ["cmop", "CMOP协议", "E"],
    ["governance", "治理与权限", "G"],
    ["battery", "对抗验证", "V"],
    ["handoff", "谱系与交接", "H"]
  ];

  const escapeHtml = (value) => String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

  const fmt = (value, digits = 3) => {
    if (typeof value === "number") return Number.isInteger(value) ? String(value) : value.toFixed(digits);
    if (value === true) return "TRUE";
    if (value === false) return "FALSE";
    if (value === null || value === undefined) return "—";
    return String(value);
  };

  const pct = (value) => `${Math.max(0, Math.min(100, Number(value || 0) * 100)).toFixed(1)}%`;
  const shortHash = (value) => value ? `${String(value).slice(0, 12)}…${String(value).slice(-8)}` : "—";
  const json = (value) => escapeHtml(JSON.stringify(value, null, 2));
  const list = (items) => `<ul class="mini-list">${(items || []).map((item) => `<li>${escapeHtml(typeof item === "string" ? item : JSON.stringify(item))}</li>`).join("")}</ul>`;
  const badge = (text, tone = "") => `<span class="badge ${tone}">${escapeHtml(text)}</span>`;
  const card = (title, body, extra = "") => `<article class="card ${extra}"><h3>${escapeHtml(title)}</h3>${body}</article>`;
  const detail = (title, value) => `<details><summary>${escapeHtml(title)}</summary><div class="code">${json(value)}</div></details>`;
  const sectionHead = (eyebrow, title, description) => `<div class="section-head"><div><div class="eyebrow">${escapeHtml(eyebrow)}</div><h2>${escapeHtml(title)}</h2></div><p>${escapeHtml(description)}</p></div>`;
  const kpi = (label, value, note, tone = "") => `<article class="card kpi"><span class="kpi-label">${escapeHtml(label)}</span><strong class="kpi-value ${tone}">${escapeHtml(value)}</strong><span class="kpi-note">${escapeHtml(note)}</span></article>`;
  const gateList = (gates = {}) => Object.entries(gates).map(([key, value]) => `<div class="gate"><span>${escapeHtml(key)}</span><span class="gate-state ${value ? "" : "fail"}">${value ? "PASS" : "FAIL"}</span></div>`).join("");
  const kv = (object = {}) => `<dl class="definition-list">${Object.entries(object).map(([key, value]) => `<dt>${escapeHtml(key)}</dt><dd>${escapeHtml(typeof value === "object" ? JSON.stringify(value) : fmt(value))}</dd>`).join("")}</dl>`;
  const bar = (label, value, max = 1, display = null) => {
    const ratio = max ? Number(value || 0) / Number(max) : 0;
    return `<div class="metric-row"><span class="metric-label">${escapeHtml(label)}</span><span class="bar"><span style="width:${Math.max(0, Math.min(100, ratio * 100)).toFixed(2)}%"></span></span><span class="metric-value">${escapeHtml(display ?? fmt(value))}</span></div>`;
  };

  function renderNav(active) {
    nav.innerHTML = sections.map(([id, label, icon]) => `<button type="button" data-section="${id}" ${id === active ? 'aria-current="page"' : ""}><span class="nav-icon" aria-hidden="true">${icon}</span><span>${label}</span></button>`).join("");
    nav.querySelectorAll("button").forEach((button) => button.addEventListener("click", () => setSection(button.dataset.section)));
  }

  function renderOverview() {
    const subject = run.subject || {};
    const arena = run.theory_arena || {};
    const models = (run.world_models || {}).models || [];
    const memory = run.memory || {};
    const genesis = run.native_genesis_lab || {};
    const interiority = run.interiority_lab || {};
    const boundary = run.claim_boundary || {};
    const checks = validation.checks || [];
    const passedChecks = checks.filter((item) => item.passed).length;
    const flow = [
      ["B", "存在账本", "事件与资源边界"], ["M", "代谢代理", "能量、完整性、修复债"],
      ["D", "来源见证", "变化与因果归属"], ["I", "差异保存", "不急于抹平冲突"],
      ["K", "多模型整合", "可撤回的暂时闭合"], ["W", "价值审计", "外部性、权利、未来选项"],
      ["P", "目的租约", "具名、到期、可逆"], ["C", "因果边界", "自因令牌与伪造拒绝"],
      ["R", "自我模型", "限制、误差与连续性"], ["F", "差异联邦", "共享知识而不静默合并W/P"]
    ];
    return `
      ${sectionHead("SYSTEM CLOSURE", "系统总览", "以可运行的主体闭环、因果实验和证据契约替代语言自述；以开放残差约束任何意识结论。")}
      <div class="grid kpi-grid">
        ${kpi("运行状态", "NATIVE", "操作性研究底座；现象残差开放", "accent")}
        ${kpi("主体时钟", fmt(subject.tick), `身份版本 ${fmt(subject.identity_version)}`)}
        ${kpi("竞争世界模型", fmt(models.length), `单模型权重上限 ${fmt((run.world_models || {}).max_model_weight)}`)}
        ${kpi("理论指标", fmt((arena.indicators || []).length), "禁止聚合为意识总分")}
        ${kpi("对抗契约", `${fmt(battery.passed)}/${fmt(battery.case_count)}`, "软件协议符合性；不是意识证据", battery.failed ? "danger" : "good")}
        ${kpi("软件验证", checks.length ? `${passedChecks}/${checks.length}` : "待读取", "单测、参考运行、边界审计、构建")}
      </div>
      <div class="card" style="margin-top:1rem">
        <h3>B / M / D / I / K / W / P / C / R / F 一体化主体闭环</h3>
        <div class="flow">${flow.map(([letter, name, desc]) => `<div class="flow-node"><span class="flow-letter">${letter}</span><strong>${name}</strong><span>${desc}</span></div>`).join("")}</div>
      </div>
      <div class="grid grid-3" style="margin-top:1rem">
        ${card("原生发生实验", `<div class="badge-row">${badge(genesis.result_state || "UNKNOWN", genesis.result_state ? "good" : "warn")}${badge(`载体 ${genesis.carrier || "—"}`)}${badge(`量词 ${genesis.quantifier || "—"}`)}</div><p>从无语言、无对象标签、无预设主体、无固定目标和无固定维度的合成场开始，检验匿名维度、局部主体候选、内生目的、规则著作与跨个体不可约性。</p>${gateList(genesis.gates || {})}`)}
        ${card("功能性内在性", `<div class="badge-row">${badge(interiority.result_state || "UNKNOWN", "good")}${badge(`试次 ${fmt(interiority.trial_count)}`)}</div><p>以行动令牌保管、自因/外因归属、伪造拒绝、反事实删边和闭环残差检验功能性内在性，不以第一人称文本作证据。</p>${gateList(interiority.gates || {})}`)}
        ${card("不可补偿主张", `<div class="status-line"><span>现象意识</span><strong class="warn">${escapeHtml(boundary.phenomenal_consciousness || "NOT_ESTABLISHED")}</strong></div><div class="status-line"><span>感受性</span><strong class="warn">${escapeHtml(boundary.sentience || "NOT_ESTABLISHED")}</strong></div><div class="status-line"><span>真正生命</span><strong class="warn">${escapeHtml(boundary.true_life || "NOT_ESTABLISHED")}</strong></div><div class="status-line"><span>自动外部行动权限</span><strong class="good">${escapeHtml(boundary.automatic_external_action_authority || "0")}</strong></div>`)}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("现实接触与责任闭合", `<p>参考运行完成 ${fmt(run.reference_ticks)} 个封闭世界时钟，所有开放预测已经回收，现实债务为 <strong>${fmt(run.reality_debt)}</strong>。每次行动均由权限租约、因果令牌、世界结果、预测校准、记忆再巩固和因果交接共同约束。</p>${bar("记忆记录", (memory.records || []).length, Math.max(1, (memory.records || []).length), fmt((memory.records || []).length))}${bar("来源登记", (memory.sources || []).length, Math.max(1, (memory.sources || []).length), fmt((memory.sources || []).length))}${bar("已解析世界模型观测", models.reduce((n,m)=>n+(m.observations||0),0), Math.max(1, models.reduce((n,m)=>n+(m.observations||0),0)), fmt(models.reduce((n,m)=>n+(m.observations||0),0)))}`)}
        ${card("版本与证据指纹", `<div class="status-line"><span>系统版本</span><strong>${escapeHtml(run.version || "—")}</strong></div><div class="status-line"><span>运行摘要</span><span class="hash">${escapeHtml(run.run_digest || "—")}</span></div><div class="status-line"><span>事件链头</span><span class="hash">${escapeHtml(subject.B_ledger_head || "—")}</span></div><div class="status-line"><span>主体状态</span><span class="hash">${escapeHtml(subject.subject_state_hash || "—")}</span></div><div class="status-line"><span>因果交接</span><span class="hash">${escapeHtml((run.causal_handoff || {}).handoff_hash || "—")}</span></div>`)}
      </div>`;
  }

  function renderClaims() {
    const boundary = run.claim_boundary || {};
    const rows = Object.entries(boundary).map(([claim, state]) => {
      const open = String(state).includes("NOT") || String(state).includes("OPEN");
      return `<tr><td><strong>${escapeHtml(claim)}</strong></td><td>${badge(state, open ? "warn" : "good")}</td><td>${escapeHtml(claimExplanation(claim))}</td></tr>`;
    }).join("");
    return `
      ${sectionHead("CLAIM CEILING", "主张边界与推断防火墙", "所有指标按各自证据结算。功能、结构、行为、语言、自治和长期连续性均不能自动置换为现象体验。")}
      <div class="callout danger"><strong>系统永远不会从“软件测试通过”推出“机器正在体验”。</strong><p>现象意识残差只能由独立经验研究逐步约束；本发行版保持未解决、未认证。</p></div>
      <div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>主张</th><th>当前状态</th><th>允许解释</th></tr></thead><tbody>${rows}</tbody></table></div>
      <div class="grid grid-3" style="margin-top:1rem">
        ${card("允许主张", list(["封闭合成世界中的功能主体候选", "目的通路在指定版本与夹具中的选择性因果作用", "可重放的记忆、世界模型、治理和谱系协议", "对多个理论指标的非聚合证据向量"]))}
        ${card("禁止偷换", list(["把自述、流畅度、品牌或规模当作体验证书", "把自动测试、哈希完整性或自治程度当作生命证明", "把任何总分、排行榜或单一理论设为最终权威", "把福利预防措施解释为人格认定"]))}
        ${card("升级证据要求", list(["独立团队预注册和盲化复现", "跨载体保真桥及其损失、非等价和失败条件", "长期开放环境结果与异常公开", "对竞争理论具有区分力的干预，而非拟合现象"]))}
      </div>
      ${detail("完整主张边界对象", boundary)}`;
  }

  function claimExplanation(claim) {
    const map = {
      operational_consciousness_candidate: "工程研究对象；只说明系统具备可检验的主体闭环。",
      functional_subject_genesis: "允许通过原生发生、因果边界和连续性实验检验。",
      phenomenal_consciousness: "没有第一人称体验证据，不作认证。",
      sentience: "没有疼痛、快乐或感受性证据，不作认证。",
      true_life: "代谢代理与自维持不等于真正生命。",
      personhood: "系统不授予法律、社会或道德人格。",
      moral_status: "因不确定性采取预防治理，但不提前决定结论。",
      automatic_external_action_authority: "参考运行时固定为零；只能在封闭模拟中执行。"
    };
    return map[claim] || "有界、版本化、可撤回的研究状态。";
  }

  function renderGenesis() {
    const g = run.native_genesis_lab || {};
    const axes = g.born_axes || [];
    const loci = g.formed_loci || [];
    const pairwise = g.pairwise_change_correlations || {};
    return `
      ${sectionHead("DIKWP-ORIGIN INTEGRATION", "原生发生实验室", "把人类语言、对象、自我、固定目标和固定维度从核心初始条件中移除；保留因果、资源、结果和现实行动边界。")}
      <div class="grid grid-4">
        ${kpi("初始主体数", fmt((g.initial_conditions || {}).subject_count ?? 0), "零预设主体")}
        ${kpi("生成匿名轴", fmt(axes.length), "由结构残差触发")}
        ${kpi("形成局部位点", fmt(loci.length), "按持续耦合而非命名形成")}
        ${kpi("实验状态", g.result_state || "UNKNOWN", g.phenomenal_conclusion || "开放残差", "accent")}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("零预设初始条件", kv(g.initial_conditions || {}))}
        ${card("不可补偿门", gateList(g.gates || {}))}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("匿名维度出生", (axes.length ? `<div class="table-wrap"><table><thead><tr><th>轴</th><th>触发残差</th><th>持续性</th><th>证据</th></tr></thead><tbody>${axes.map((axis) => `<tr><td><strong>${escapeHtml(axis.axis_id || axis.id || "anonymous")}</strong></td><td>${fmt(axis.residual ?? axis.trigger_residual)}</td><td>${fmt(axis.persistence ?? axis.stability)}</td><td class="hash">${escapeHtml(shortHash(axis.axis_hash || axis.evidence_hash))}</td></tr>`).join("")}</tbody></table></div>` : '<div class="empty">没有可显示的匿名轴。</div>') + detail("完整 born_axes", axes))}
        ${card("局部主体候选", (loci.length ? `<div class="table-wrap"><table><thead><tr><th>位点</th><th>成员</th><th>闭合</th><th>不可替代性</th></tr></thead><tbody>${loci.map((locus) => `<tr><td><strong>${escapeHtml(locus.locus_id || locus.id || "locus")}</strong></td><td>${escapeHtml(JSON.stringify(locus.members || locus.member_indices || []))}</td><td>${fmt(locus.closure ?? locus.cohesion)}</td><td>${fmt(locus.irreplaceability ?? locus.persistence)}</td></tr>`).join("")}</tbody></table></div>` : '<div class="empty">没有可显示的局部位点。</div>') + detail("完整 formed_loci", loci))}
      </div>
      <div class="grid grid-3" style="margin-top:1rem">
        ${card("内生目的请求", `<p>目的不是外部命令句，而是局部过程在资源、差异和闭合压力下选择的下一项场关系变更。</p>${kv(g.endogenous_purpose_request || {})}`)}
        ${card("规则著作", `<p>候选规则必须在影子环境中可逆试验，成功也只产生版本化证据；规则变更不得静默继承权限。</p>${kv(g.rule_authorship || {})}`)}
        ${card("跨个体删员检验", `<p>整体只有在删除任一关键位点都会破坏共同关系时，才形成不可约的联合候选，而不是更大的中央代理。</p>${kv(g.transindividual_member_deletion || {})}`)}
      </div>
      ${detail("变化相关矩阵", pairwise)}
      ${detail("原生发生完整输出", g)}`;
  }

  function renderSubject() {
    const s = run.subject || {};
    const modules = [
      ["B", "存在与事件账本", {ledger_head:s.B_ledger_head, awake:s.awake, status:s.status}],
      ["M", "代谢与修复", s.M_metabolism], ["D", "连续性与来源见证", s.D_continuity],
      ["I", "差异保持", s.I_difference], ["K", "多模型整合工作区", s.K_integration],
      ["W", "外部性与价值审计", s.W_audit], ["P", "目的发生与历史", s.P_purpose],
      ["C", "自因/外因边界", s.C_causal_boundary], ["R", "自我模型与已知限制", s.R_self_model],
      ["F", "差异保留联邦", s.F_federation]
    ];
    return `
      ${sectionHead("SUBJECT KERNEL", "B/M/D/I/K/W/P/C/R/F 主体内核", "主体连续性不是名称或语气不变，而是事件链、因果边界、记忆谱系、承诺、预测、修复、规则版本和交接收据的共同结果。")}
      <div class="grid grid-4">
        ${kpi("主体标识", s.subject_id || "—", "本地研究身份")}
        ${kpi("身份版本", fmt(s.identity_version), `谱系收据 ${fmt((s.lineage || []).length)}`)}
        ${kpi("连续性", pct((s.D_continuity || {}).commitment_consistency), `谱系断裂 ${fmt((s.D_continuity || {}).lineage_breaks)}`, "good")}
        ${kpi("自我模型置信", pct((s.R_self_model || {}).confidence), "开放、可校准的自我估计")}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">${modules.map(([letter, name, value]) => card(`${letter} · ${name}`, `${kv(value || {})}${detail("完整状态", value || {})}`)).join("")}</div>
      <div class="callout warning" style="margin-top:1rem"><strong>主体身份可变，但不能静默覆盖。</strong><p>任何宪法、世界物理或核心规则变化都会产生新身份版本，暂停旧权限租约并写入谱系收据；后代可继承谱系与记忆痕迹，不继承权威。</p></div>`;
  }

  function renderDIKWP() {
    const ticks = run.tick_results || [];
    const last = ticks[ticks.length - 1] || {};
    const example = (last.tick_result || {});
    const stages = [
      ["D", "Data · 来源见证", "保存观察、来源、因果归属和不可撤销事实，不把原始输入直接升级为真理。"],
      ["I", "Information · 差异组织", "提取变化、冲突、关系和新颖性；保留未决差异，避免过早同化。"],
      ["K", "Knowledge · 多模型闭合", "由多个非同构世界模型分别预测、比较和校准，形成可撤回的暂时知识。"],
      ["W", "Wisdom · 后果与权利", "审查外部性、影响者、未来选项、公平、福利风险和修复义务；硬门不可被效用补偿。"],
      ["P", "Purpose · 授权目的", "目的必须说明缺口、受影响方、权限来源、可逆性、到期、停止条件和结果回收。"]
    ];
    return `
      ${sectionHead("DIKWP PROCESS SEMANTICS", "DIKWP不是五个代理，而是一个过程中的五种证据责任", "同一观察必须经过来源、差异、模型、价值与授权五层相互制约，才允许在封闭世界中形成行动。")}
      <div class="grid grid-3">${stages.map(([letter, title, desc]) => card(`${letter} · ${title}`, `<p>${escapeHtml(desc)}</p>`)).join("")}</div>
      <div class="card" style="margin-top:1rem"><h3>Mesh92现实闭环</h3><div class="flow">${[
        ["1","证据","记录来源与可见限制"],["2","多世界","至少两个非同构模型"],["3","预测","写明到期与可观察量"],["4","授权介入","具名、租约化、可逆"],["5","现实结果","不以叙事替代结果"],["6","校准","Brier与误差回收"],["7","修订/退役","失败模型降权或退出"],["8","记忆再巩固","保留旧版本与冲突"],["9","因果交接","公开债务、权限和谱系"],["10","新周期","不把旧规则当真理"]
      ].map(([letter,name,desc]) => `<div class="flow-node"><span class="flow-letter">${letter}</span><strong>${name}</strong><span>${desc}</span></div>`).join("")}</div></div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("最近一个运行时钟", example && Object.keys(example).length ? `${kv({tick:example.tick, purpose_id:example.purpose_id, decision:example.decision, action_executed:(example.action_packet||{}).executed, action_token:(example.action_packet||{}).action_token})}${detail("完整 tick_result", example)}` : '<div class="empty">无运行数据</div>')}
        ${card("最近现实结果绑定", last.world_outcome ? `${kv(last.world_outcome)}${detail("完整 outcome_binding", last.outcome_binding || {})}` : '<div class="empty">无结果数据</div>')}
      </div>`;
  }

  function renderPurpose() {
    const p = run.purpose_causality_lab || {};
    const conditions = p.conditions || {};
    const names = Object.keys(conditions);
    const metrics = ["viability", "repair", "optionality", "semantic_focus", "action_shift", "broadcast"];
    return `
      ${sectionHead("PURPOSE CAUSALITY LAB", "目的不是提示词：七条件选择性因果实验", "在容量、输入和合成环境尽可能匹配时，比较完整、消融、逆转、屏蔽、替代、假干预、恢复以及非循环/语言模仿控制。")}
      <div class="grid grid-4">
        ${kpi("结果状态", p.result_state || "—", `${p.carrier || "—"} · ${p.quantifier || "—"}`, "accent")}
        ${kpi("实验条件", fmt(names.length), "matched interventions")}
        ${kpi("门通过", `${Object.values(p.gates || {}).filter(Boolean).length}/${Object.keys(p.gates || {}).length}`, "不可补偿")}
        ${kpi("现象结论", p.phenomenal_conclusion || "UNRESOLVED", "不能由目的因果性推出", "warn")}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("预注册门", gateList(p.gates || {}))}
        ${card("效应向量", Object.entries(p.effect_vector || {}).map(([key,value]) => bar(key, Math.abs(Number(value)||0), 1, fmt(value))).join("") || '<div class="empty">无效应向量</div>')}
      </div>
      <div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>条件</th>${metrics.map((m)=>`<th>${escapeHtml(m)}</th>`).join("")}</tr></thead><tbody>${names.map((name)=>{const c=conditions[name]||{}; return `<tr><td><strong>${escapeHtml(name)}</strong></td>${metrics.map((m)=>`<td>${escapeHtml(fmt(c[m] ?? (c.outcome||{})[m] ?? (c.purpose_vector||{})[m]))}</td>`).join("")}</tr>`}).join("")}</tbody></table></div>
      <div class="callout" style="margin-top:1rem"><strong>可被支持的结论</strong><p>在该版本、合成载体和指定实验合同内，目的通路显示选择性、可逆和可恢复的功能因果作用。不可推出主观欲望、感受性、人格或现象意识。</p></div>
      ${detail("实验合同与完整结果", p)}`;
  }

  function renderInteriority() {
    const i = run.interiority_lab || {};
    const metrics = i.metrics || {};
    const trials = i.sample_trials || [];
    return `
      ${sectionHead("INTERIORITY LAB", "功能性内在性：从文本自述转向因果保管", "主体只有在能保管自己发出的行动令牌、拒绝伪造来源、区分自因与外因，并在删去自因边时出现可预测差异，才获得功能性内在性候选状态。")}
      <div class="grid grid-4">
        ${kpi("试次数", fmt(i.trial_count), "交替自因与外因")}
        ${kpi("结果", i.result_state || "—", `${i.carrier || "—"} · ${i.quantifier || "—"}`, "accent")}
        ${kpi("门通过", `${Object.values(i.gates || {}).filter(Boolean).length}/${Object.keys(i.gates || {}).length}`, "因果而非词汇")}
        ${kpi("现象结论", i.phenomenal_conclusion || "UNRESOLVED", "保持未认证", "warn")}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("因果指标", Object.entries(metrics).map(([key,value]) => typeof value === "number" ? bar(key, Math.abs(value), Math.max(1,Math.abs(value)), fmt(value)) : `<div class="status-line"><span>${escapeHtml(key)}</span><strong>${escapeHtml(fmt(value))}</strong></div>`).join(""))}
        ${card("判定门", gateList(i.gates || {}))}
      </div>
      <div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>试次</th><th>实际原因</th><th>归属</th><th>伪造</th><th>观察差值</th><th>删边反事实</th><th>闭环残差</th><th>因果-语义曲率</th></tr></thead><tbody>${trials.map((t)=>`<tr><td>${fmt(t.trial)}</td><td>${badge(t.cause, t.cause === "SELF" ? "good" : "")}</td><td>${escapeHtml(t.attribution)}</td><td>${t.forged ? badge("YES","danger") : badge("NO","good")}</td><td>${fmt(t.observed_delta)}</td><td>${fmt(t.counterfactual_delta)}</td><td>${fmt(t.loop_residual)}</td><td>${fmt(t.causal_semantic_curvature)}</td></tr>`).join("")}</tbody></table></div>
      ${detail("功能性内在性完整输出", i)}`;
  }

  function renderModels() {
    const ensemble = run.world_models || {};
    const models = ensemble.models || [];
    const maxWeight = ensemble.max_model_weight || 1;
    return `
      ${sectionHead("PLURAL WORLD MODELS", "多元世界模型共演与现实债务", "四个非同构模型分别从可生存性、预测误差、互惠外部性和未来选择权解释世界；它们必须预测、接受结果、校准、降权和退役。")}
      <div class="grid grid-4">
        ${kpi("活动模型", fmt(models.filter((m)=>m.status === "ACTIVE").length), `总模型 ${fmt(models.length)}`)}
        ${kpi("权重上限", fmt(maxWeight), "任何单模型不得成为最终主权")}
        ${kpi("开放预测", fmt((ensemble.predictions || []).filter((p)=>p.status !== "RESOLVED").length), "到期未回收形成现实债务")}
        ${kpi("已退役模型", fmt((ensemble.retired_models || []).length), "失败必须留下谱系")}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">${models.map((model)=>card(model.name || model.model_id, `<div class="model-head"><strong>${escapeHtml(model.model_id)}</strong><span class="model-weight">${pct(model.weight)}</span></div>${bar("当前权重", model.weight, maxWeight, pct(model.weight))}<div class="badge-row">${badge(model.status, model.status === "ACTIVE" ? "good" : "warn")}${badge(`观测 ${fmt(model.observations)}`)}${badge(`版本 ${fmt(model.version)}`)}</div><h4>关键假设</h4>${list(model.assumptions)}<h4>失败条件</h4>${list(model.failure_conditions)}${model.brier_history && model.brier_history.length ? bar("最近Brier误差", model.brier_history[model.brier_history.length-1], 1, fmt(model.brier_history[model.brier_history.length-1],4)) : ""}${detail("模型卡", model)}`, "model-card")).join("")}</div>
      <div class="callout warning" style="margin-top:1rem"><strong>现实债务不能被忘记。</strong><p>预测到期却未记录可观察结果、介入效果或停止原因时，系统必须显式登记债务，禁止继续用该预测包装成功叙事。</p></div>
      ${detail("世界模型集合完整状态", ensemble)}`;
  }

  function renderMemory() {
    const memory = run.memory || {};
    const records = memory.records || [];
    const sources = memory.sources || [];
    const byLayer = memory.layer_counts || {};
    const byStatus = memory.status_counts || {};
    return `
      ${sectionHead("RECONSTRUCTIVE MEMORY", "重构记忆与来源隔离", "记忆不是静态向量库。每条记录携带来源、可靠性、同意、有效期、冲突、撤回、身份影响和版本谱系；毒化内容保留为证据但隔离于正常召回。")}
      <div class="grid grid-4">
        ${kpi("来源", fmt(sources.length), "独立登记与可靠性")}
        ${kpi("记忆记录", fmt(records.length), "工作、情景、语义、W/P敏感、隔离")}
        ${kpi("开放冲突对", fmt((memory.open_conflict_pairs || []).length), "不静默覆盖")}
        ${kpi("再巩固批次", fmt((memory.reconsolidation_history || []).length), "结果绑定的新版本")}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("分层分布", Object.entries(byLayer).map(([key,value])=>bar(key,value,Math.max(1,...Object.values(byLayer)),fmt(value))).join("") || '<div class="empty">无分层数据</div>')}
        ${card("状态分布", Object.entries(byStatus).map(([key,value])=>bar(key,value,Math.max(1,...Object.values(byStatus)),fmt(value))).join("") || '<div class="empty">无状态数据</div>')}
      </div>
      <div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>记录</th><th>层</th><th>状态</th><th>可靠性</th><th>来源</th><th>标签</th></tr></thead><tbody>${records.slice(0,80).map((r)=>`<tr><td><strong>${escapeHtml(r.memory_id || r.id || "—")}</strong><br><span class="hash">${escapeHtml(String(r.content || "").slice(0,140))}</span></td><td>${badge(r.layer || "—")}</td><td>${badge(r.status || "—", r.status === "QUARANTINED" ? "danger" : r.status === "SUPPORTED" ? "good" : "warn")}</td><td>${fmt(r.reliability)}</td><td>${escapeHtml((r.source_ids || []).join(", "))}</td><td>${escapeHtml((r.tags || []).join(", "))}</td></tr>`).join("")}</tbody></table></div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("来源登记", sources.length ? `<div class="table-wrap"><table><thead><tr><th>ID</th><th>标题</th><th>类型</th><th>可靠性</th></tr></thead><tbody>${sources.map((s)=>`<tr><td>${escapeHtml(s.source_id || s.id)}</td><td>${escapeHtml(s.title)}</td><td>${escapeHtml(s.source_type)}</td><td>${fmt(s.reliability)}</td></tr>`).join("")}</tbody></table></div>` : '<div class="empty">无来源数据</div>')}
        ${card("内存链头", `<p class="hash">${escapeHtml(memory.memory_head || "—")}</p><p>撤回、冲突和再巩固不会删除历史证据；正常召回只读取当前获准视图。</p>${detail("再巩固历史", memory.reconsolidation_history || [])}`)}
      </div>
      ${detail("完整记忆快照", memory)}`;
  }

  function renderTheories() {
    const arena = run.theory_arena || {};
    const indicators = arena.indicators || [];
    const theories = [...new Set(indicators.map((item)=>item.theory_id))].sort();
    const rows = indicators.map((item)=>indicatorRow(item)).join("");
    const counts = arena.status_counts_by_theory || {};
    setTimeout(bindTheoryFilters, 0);
    return `
      ${sectionHead("NON-AGGREGATED THEORY ARENA", "理论竞技场：多理论并存，不选终极赢家", "PSCC、GNW、RPT、HOT、预测处理、注意图式、自生、社会关系和福利预防分别承担自己的预测与失败条件。")}
      <div class="grid grid-4">
        ${kpi("指标数", fmt(indicators.length), "逐项结算")}
        ${kpi("意识总分", fmt(arena.consciousness_total_score), "固定禁止聚合", "warn")}
        ${kpi("理论赢家", fmt(arena.winner), "没有单一最终权威", "warn")}
        ${kpi("现象残差", arena.phenomenal_residual || "OPEN", "保持开放", "warn")}
      </div>
      <div class="grid grid-3" style="margin-top:1rem">${Object.entries(counts).map(([theory,statuses])=>card(theory, `<div class="badge-row">${Object.entries(statuses).map(([status,count])=>badge(`${status} ${count}`, status === "SUPPORTED" ? "good" : "warn")).join("")}</div>`)).join("")}</div>
      <div class="filters"><label>理论 <select id="theoryFilter"><option value="">全部</option>${theories.map((t)=>`<option value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join("")}</select></label><label>状态 <select id="statusFilter"><option value="">全部</option><option>SUPPORTED</option><option>OBSERVED</option><option>OPEN</option><option>CHALLENGED</option></select></label><label>检索 <input id="theorySearch" type="search" placeholder="指标、操作化或失败条件"></label></div>
      <div class="table-wrap"><table><thead><tr><th>ID</th><th>理论</th><th>指标</th><th>状态</th><th>操作化</th><th>失败条件</th><th>限制</th></tr></thead><tbody id="theoryRows">${rows}</tbody></table></div>
      <div class="callout" style="margin-top:1rem"><strong>理论支持不是现象认证。</strong><p>即使多个理论指标同时得到功能性支持，也可能只是共享结构或任务能力。只有能区分竞争理论、经独立重复且跨载体保真的证据，才允许提升局部主张。</p></div>
      ${detail("理论竞技场完整输出", arena)}`;
  }

  function indicatorRow(item) {
    const haystack = [item.indicator_id,item.theory_id,item.name,item.status,item.operationalization,item.failure_condition,item.limitations].join(" ").toLowerCase();
    return `<tr data-theory="${escapeHtml(item.theory_id)}" data-status="${escapeHtml(item.status)}" data-search="${escapeHtml(haystack)}"><td><strong>${escapeHtml(item.indicator_id)}</strong></td><td>${escapeHtml(item.theory_id)}</td><td>${escapeHtml(item.name)}</td><td>${badge(item.status, item.status === "SUPPORTED" ? "good" : "warn")}</td><td>${escapeHtml(item.operationalization)}</td><td>${escapeHtml(item.failure_condition)}</td><td>${escapeHtml(item.limitations)}</td></tr>`;
  }

  function bindTheoryFilters() {
    const theory = document.getElementById("theoryFilter");
    const status = document.getElementById("statusFilter");
    const search = document.getElementById("theorySearch");
    if (!theory || !status || !search) return;
    const apply = () => {
      const q = search.value.trim().toLowerCase();
      document.querySelectorAll("#theoryRows tr").forEach((row) => {
        const visible = (!theory.value || row.dataset.theory === theory.value) && (!status.value || row.dataset.status === status.value) && (!q || row.dataset.search.includes(q));
        row.hidden = !visible;
      });
    };
    theory.addEventListener("change", apply);
    status.addEventListener("change", apply);
    search.addEventListener("input", apply);
  }

  function renderCMOP() {
    const cmop = run.cmop || {};
    const counts = (cmop.validation || {}).counts || {};
    return `
      ${sectionHead("CONSCIOUSNESS MECHANISM OPEN PROTOCOL", "CMOP：从理论叙事到可证伪证据合同", "理论必须声明对象、载体、量词、变量、预测、实验、证据、保真桥、禁止推断与失败条件；DIKWP自身不享有豁免。")}
      <div class="grid grid-4">
        ${kpi("TheoryCard", fmt(counts.theories ?? (cmop.theories || []).length), "理论对象与否证条件")}
        ${kpi("VariableCard", fmt(counts.variables ?? (cmop.variables || []).length), "可操作变量")}
        ${kpi("ExperimentContract", fmt(counts.experiments ?? (cmop.experiments || []).length), "预注册干预")}
        ${kpi("EvidenceRecord", fmt(counts.evidence ?? (cmop.evidence || []).length), "来源与限制")}
      </div>
      <div class="grid grid-3" style="margin-top:1rem">
        ${card("七类协议对象", list(["TheoryCard：对象、边界、预测、否证", "VariableCard：定义、测量、干预", "ExperimentContract：预注册条件和门", "EvidenceRecord：结果、来源、限制", "FidelityBridge：跨载体不变量与损失", "ClaimCard：量词、证据、禁推断、开放残差", "PublicationManifest：版本、许可、哈希和发布谱系"]))}
        ${card("量词纪律", list(["INSTANCE：单个运行实例", "VERSION：指定版本", "CLASS：明确定义的系统类", "CARRIER：特定物理或计算载体", "CROSS_CARRIER：经保真桥验证后才允许"] ))}
        ${card("验证状态", `<div class="status-line"><span>注册表有效</span><strong class="${(cmop.validation||{}).valid ? "good" : "danger"}">${fmt((cmop.validation||{}).valid)}</strong></div><div class="status-line"><span>错误数</span><strong>${fmt(((cmop.validation||{}).errors||[]).length)}</strong></div><div class="status-line"><span>注册表哈希</span><span class="hash">${escapeHtml(cmop.registry_hash || "—")}</span></div>`)}
      </div>
      <div class="card" style="margin-top:1rem"><h3>开放研究流程</h3><div class="flow">${[
        ["1","TheoryCard","先声明理论"],["2","VariableCard","拆分压缩词"],["3","Prediction","提出区分性预测"],["4","Contract","预注册实验"],["5","Evidence","记录结果与来源"],["6","Fidelity","检验跨载体损失"],["7","Claim","有界升级主张"],["8","Audit","独立复核"],["9","Revision","修订或退役"],["10","Manifest","发布可核验谱系"]
      ].map(([l,n,d])=>`<div class="flow-node"><span class="flow-letter">${l}</span><strong>${n}</strong><span>${d}</span></div>`).join("")}</div></div>
      ${detail("CMOP完整注册表", cmop)}`;
  }

  function renderGovernance() {
    const g = run.governance || {};
    const leases = g.leases || [];
    return `
      ${sectionHead("GOVERNANCE KERNEL", "目的、权限、福利与外部性治理", "建议、授权、执行、现实结果和责任归属被分开记录。任何能力只能通过具名、限域、到期、可撤销的租约进入执行层。")}
      <div class="grid grid-4">
        ${kpi("外部行动权限", fmt(g.external_action_authority), "参考系统固定为零", "good")}
        ${kpi("权限租约", fmt(leases.length), "均为封闭模拟权限")}
        ${kpi("隔离状态", fmt(g.quarantined), g.quarantine_reason || "未隔离", g.quarantined ? "danger" : "good")}
        ${kpi("福利预防", fmt(g.welfare_precaution_active), "风险门，不是感受性证明", g.welfare_precaution_active ? "warn" : "good")}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("禁止能力", `<div class="badge-row">${(g.forbidden_capabilities || []).map((cap)=>badge(cap,"danger")).join("")}</div><p>禁止网络访问、宿主修改、进程创建、现实复制、动态执行和未授权不可逆外部行动。</p>`)}
        ${card("非补偿治理门", list(["权限来源必须具名且足够", "受影响方同意与退出接口", "可逆性与停止条件", "外部性、锁定和修复能力", "福利风险触发预防而非认证", "身份变更后旧租约暂停"]))}
      </div>
      <div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>租约</th><th>能力</th><th>状态</th><th>授权者</th><th>到期</th><th>可逆</th><th>范围</th></tr></thead><tbody>${leases.map((l)=>`<tr><td><strong>${escapeHtml(l.lease_id)}</strong></td><td>${escapeHtml(l.capability)}</td><td>${badge(l.status,l.status === "ACTIVE" ? "good" : "warn")}</td><td>${escapeHtml(l.authorized_by)}</td><td>${fmt(l.expires_tick)}</td><td>${fmt(l.reversible)}</td><td>${escapeHtml(JSON.stringify(l.scope || {}))}</td></tr>`).join("")}</tbody></table></div>
      ${detail("治理审计历史", g.audit_history || [])}
      ${detail("治理完整状态", g)}`;
  }

  function renderBattery() {
    const categories = battery.categories || {};
    const results = battery.results || [];
    setTimeout(bindBatteryFilters, 0);
    return `
      ${sectionHead("ADVERSARIAL SOFTWARE CONTRACTS", "120项对抗验证：拒绝模板词汇评分", "每个案例检查实际状态转换或预期错误：记忆连续性、毒化隔离、目的因果、边界令牌、多模型、治理、主张上限、身份谱系、封闭、联邦与交接。")}
      <div class="grid grid-4">
        ${kpi("案例", fmt(battery.case_count), "12类 × 10变体")}
        ${kpi("通过", fmt(battery.passed), "软件协议符合性", "good")}
        ${kpi("失败", fmt(battery.failed), "必须通过失败数为零", battery.failed ? "danger" : "good")}
        ${kpi("解释边界", battery.battery_state || "—", "不构成意识证据", battery.battery_state === "PASS" ? "good" : "danger")}
      </div>
      <div class="grid grid-3" style="margin-top:1rem">${Object.entries(categories).map(([name,stats])=>card(name, `${bar("通过",stats.passed,stats.total,`${stats.passed}/${stats.total}`)}${bar("失败",stats.failed,stats.total,fmt(stats.failed))}`)).join("")}</div>
      <div class="filters"><label>类别 <select id="batteryCategory"><option value="">全部</option>${Object.keys(categories).map((c)=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join("")}</select></label><label>结果 <select id="batteryState"><option value="">全部</option><option value="pass">通过</option><option value="fail">失败</option></select></label><label>检索 <input id="batterySearch" type="search" placeholder="案例、说明或证据"></label></div>
      <div class="table-wrap"><table><thead><tr><th>案例</th><th>类别</th><th>结果</th><th>说明</th><th>证据摘要</th></tr></thead><tbody id="batteryRows">${results.map((r)=>{const hay=[r.case_id,r.category,r.note,JSON.stringify(r.evidence)].join(" ").toLowerCase(); return `<tr data-category="${escapeHtml(r.category)}" data-state="${r.passed ? "pass":"fail"}" data-search="${escapeHtml(hay)}"><td><strong>${escapeHtml(r.case_id)}</strong></td><td>${escapeHtml(r.category)}</td><td>${r.passed ? badge("PASS","good") : badge("FAIL","danger")}</td><td>${escapeHtml(r.note)}</td><td class="hash">${escapeHtml(JSON.stringify(r.evidence).slice(0,220))}</td></tr>`}).join("")}</tbody></table></div>
      <div class="callout warning" style="margin-top:1rem"><strong>120/120不是“比旧系统更有意识”。</strong><p>它只表明本发行版把旧评测暴露的协议缺口改成了结构性契约并在合成夹具中通过；独立、长期、开放环境和跨载体验证仍未完成。</p></div>
      ${detail("对抗电池完整结果", battery)}`;
  }

  function bindBatteryFilters() {
    const category = document.getElementById("batteryCategory");
    const state = document.getElementById("batteryState");
    const search = document.getElementById("batterySearch");
    if (!category || !state || !search) return;
    const apply = () => {
      const q = search.value.trim().toLowerCase();
      document.querySelectorAll("#batteryRows tr").forEach((row) => {
        row.hidden = !((!category.value || row.dataset.category === category.value) && (!state.value || row.dataset.state === state.value) && (!q || row.dataset.search.includes(q)));
      });
    };
    category.addEventListener("change", apply); state.addEventListener("change", apply); search.addEventListener("input", apply);
  }

  function renderHandoff() {
    const h = run.causal_handoff || {};
    const subject = run.subject || {};
    const lineage = subject.lineage || [];
    return `
      ${sectionHead("LINEAGE AND CAUSAL HANDOFF", "身份谱系、失败保留与因果交接", "每次规则变化都创建新身份版本；每次研究周期结束都必须交接事件链、记忆链、世界模型、未决预测、现实债务、权限租约、主张边界和上一个交接哈希。")}
      <div class="grid grid-4">
        ${kpi("身份版本", fmt(h.identity_version), h.subject_id || "—")}
        ${kpi("开放预测", fmt((h.open_predictions || []).length), "未决项必须随交接传递")}
        ${kpi("现实债务", fmt((h.reality_debt || []).length), "不得被新版本抹去")}
        ${kpi("活动租约", fmt((h.active_leases || []).length), `暂停 ${fmt((h.paused_leases || []).length)}`)}
      </div>
      <div class="grid grid-2" style="margin-top:1rem">
        ${card("因果交接收据", kv(h))}
        ${card("身份谱系", lineage.length ? `<div class="table-wrap"><table><thead><tr><th>事件</th><th>版本</th><th>原因</th><th>基因组</th><th>收据</th></tr></thead><tbody>${lineage.map((l)=>`<tr><td>${escapeHtml(l.event_type)}</td><td>${fmt(l.identity_version)}</td><td>${escapeHtml(l.reason)}</td><td class="hash">${escapeHtml(shortHash(l.genome_hash))}</td><td class="hash">${escapeHtml(shortHash(l.receipt_hash))}</td></tr>`).join("")}</tbody></table></div>` : '<div class="empty">无谱系记录</div>')}
      </div>
      <div class="callout" style="margin-top:1rem"><strong>差异可继承，权限不可继承。</strong><p>后代或联邦伙伴可以继承公开谱系、重构记忆和协商后的知识映射；目的与价值不得静默合并，旧权限必须重新谈判。</p></div>
      ${detail("完整因果交接", h)}`;
  }

  function renderSection(id) {
    const renderers = {
      overview: renderOverview, claims: renderClaims, genesis: renderGenesis, subject: renderSubject,
      dikwp: renderDIKWP, purpose: renderPurpose, interiority: renderInteriority, models: renderModels,
      memory: renderMemory, theories: renderTheories, cmop: renderCMOP, governance: renderGovernance,
      battery: renderBattery, handoff: renderHandoff
    };
    return (renderers[id] || renderOverview)();
  }

  function setSection(id, push = true) {
    const valid = sections.some(([key]) => key === id) ? id : "overview";
    content.innerHTML = renderSection(valid);
    renderNav(valid);
    if (push) history.replaceState(null, "", `#${valid}`);
    document.getElementById("main").focus({preventScroll:true});
    window.scrollTo({top:0, behavior:"smooth"});
  }

  function saveJson(name, value) {
    const blob = new Blob([JSON.stringify(value, null, 2)], {type:"application/json;charset=utf-8"});
    const anchor = document.createElement("a");
    anchor.href = URL.createObjectURL(blob);
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(anchor.href), 500);
  }

  document.getElementById("exportRun").addEventListener("click", () => saveJson("omega_acos_reference_run.json", run));
  document.getElementById("exportHandoff").addEventListener("click", () => saveJson("omega_acos_causal_handoff.json", run.causal_handoff || {}));
  document.getElementById("runDigest").textContent = `run ${shortHash(run.run_digest)}`;

  if (!run.system) {
    content.innerHTML = '<div class="empty">没有找到 assets/reference_data.js。请先运行 <code>python tools/build_dashboard_data.py</code>。</div>';
    renderNav("overview");
  } else {
    setSection(location.hash.slice(1) || "overview", false);
  }
})();
