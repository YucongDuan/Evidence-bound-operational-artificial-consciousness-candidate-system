import unittest

from omega_acos.cmop import ClaimCard, EvidenceRecord, default_cmop_registry
from omega_acos.experiments import PurposeCausalityLab


class CMOPTests(unittest.TestCase):
    def setUp(self):
        self.registry = default_cmop_registry()
        self.contract = PurposeCausalityLab(11).contract()
        self.registry.register_experiment(self.contract)
        self.evidence = EvidenceRecord(
            "E", self.contract.experiment_id, ["fixture"], "SYNTHETIC", "VERSION",
            {"x": 1}, "DEMO", ["TH-PSCC"], [], ["phenomenal consciousness"], ["synthetic"],
        )
        self.registry.add_evidence(self.evidence)

    def test_registry_valid(self):
        self.assertTrue(self.registry.validate()["valid"])

    def test_phenomenal_certification_blocked(self):
        with self.assertRaises(ValueError):
            self.registry.add_claim(ClaimCard(
                "C", "proves consciousness", "PHENOMENAL_CONSCIOUSNESS", "VERSION", ["SYNTHETIC"], ["E"], "CERTIFIED", [], []
            ))

    def test_claim_quantifier_ceiling(self):
        with self.assertRaises(ValueError):
            self.registry.add_claim(ClaimCard(
                "C2", "universal functional claim", "FUNCTIONAL", "UNIVERSAL", ["SYNTHETIC"], ["E"], "SUPPORTED", [], []
            ))


if __name__ == "__main__":
    unittest.main()
