import unittest

from omega_acos.runtime import OmegaRuntime, RuntimePolicy


class RuntimeTests(unittest.TestCase):
    def test_reference_closure(self):
        runtime = OmegaRuntime(policy=RuntimePolicy(reference_ticks=3, random_seed=44))
        result = runtime.run_reference(ticks=3)
        self.assertEqual(result["release_state"], "NATIVE_OPERATIONAL_CONSCIOUSNESS_RESEARCH_SUBSTRATE_WITH_OPEN_PHENOMENAL_RESIDUAL")
        self.assertIsNone(result["theory_arena"]["consciousness_total_score"])
        self.assertEqual(result["claim_boundary"]["phenomenal_consciousness"], "NOT_ESTABLISHED")
        self.assertEqual(result["policy"]["external_action_authority"], 0)
        self.assertTrue(runtime.ledger.verify()["valid"])

    def test_handoff_hash(self):
        runtime = OmegaRuntime(policy=RuntimePolicy(reference_ticks=2))
        result = runtime.run_reference(ticks=2)
        handoff = result["causal_handoff"]
        from omega_acos.canonical import digest
        base = {k: v for k, v in handoff.items() if k != "handoff_hash"}
        self.assertEqual(handoff["handoff_hash"], digest(base))


if __name__ == "__main__":
    unittest.main()
