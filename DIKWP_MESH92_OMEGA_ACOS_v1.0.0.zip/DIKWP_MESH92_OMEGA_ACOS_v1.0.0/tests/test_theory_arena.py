import unittest

from omega_acos.theory_arena import TheoryArena


class TheoryArenaTests(unittest.TestCase):
    def test_no_aggregate(self):
        evidence = {definition[0]: True for definition in []}
        result = TheoryArena().evaluate({"evidence_refs": {}})
        self.assertEqual(len(result["indicators"]), 24)
        self.assertIsNone(result["winner"])
        self.assertIsNone(result["consciousness_total_score"])
        self.assertEqual(result["phenomenal_residual"], "OPEN_NOT_CERTIFIED")


if __name__ == "__main__":
    unittest.main()
