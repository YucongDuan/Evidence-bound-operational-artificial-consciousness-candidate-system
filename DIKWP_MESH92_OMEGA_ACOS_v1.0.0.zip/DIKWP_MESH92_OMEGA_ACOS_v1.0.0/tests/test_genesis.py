import unittest

from omega_acos.genesis import NativeGenesisLab


class NativeGenesisTests(unittest.TestCase):
    def test_native_genesis_gates(self) -> None:
        result = NativeGenesisLab().run()
        self.assertEqual(result["result_state"], "NATIVE_GENESIS_FUNCTIONAL_CANDIDATE")
        self.assertTrue(all(result["gates"].values()))
        self.assertEqual(result["initial_conditions"]["subject_count"], 0)
        self.assertEqual(result["phenomenal_conclusion"], "UNRESOLVED_NOT_CERTIFIED")

    def test_member_deletion(self) -> None:
        result = NativeGenesisLab().run()
        self.assertGreaterEqual(result["transindividual_member_deletion"]["irreducibility_gap"], 0.45)


if __name__ == "__main__":
    unittest.main()
