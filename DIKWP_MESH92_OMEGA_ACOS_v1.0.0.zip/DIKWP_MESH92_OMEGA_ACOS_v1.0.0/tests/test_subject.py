import unittest

from omega_acos.runtime import OmegaRuntime, RuntimePolicy


class SubjectTests(unittest.TestCase):
    def test_tick_outcome_and_boundary(self):
        runtime = OmegaRuntime(policy=RuntimePolicy(reference_ticks=1, random_seed=1))
        tick = runtime.subject.tick(runtime.world.observe(None))
        self.assertTrue(tick["action_packet"]["executed"])
        outcome = runtime.world.step(tick["action_packet"])
        bound = runtime.subject.apply_simulated_outcome(tick["action_packet"], outcome)
        self.assertTrue(bound["applied"])
        self_obs = runtime.subject._D_witness(runtime.world.observe(tick["action_packet"]["action_token"]))
        self.assertEqual(self_obs["causal_attribution"], "SELF_CAUSED")

    def test_sleep_wake_continuity(self):
        runtime = OmegaRuntime(policy=RuntimePolicy(reference_ticks=1))
        before = runtime.subject.state.identity_version
        runtime.subject.sleep()
        runtime.subject.wake()
        self.assertEqual(runtime.subject.state.identity_version, before)
        self.assertTrue(runtime.ledger.verify()["valid"])

    def test_rule_mutation_versions_identity_and_pauses_lease(self):
        runtime = OmegaRuntime(policy=RuntimePolicy(reference_ticks=1))
        runtime.subject.tick(runtime.world.observe(None))
        before = runtime.subject.state.identity_version
        result = runtime.subject.mutate_constitution({"rule": "test"}, reason="test", authorized_by=["AUDITOR"])
        self.assertEqual(result["identity_version"], before + 1)
        self.assertTrue(result["paused_leases"])

    def test_wp_federation_merge_blocked(self):
        runtime = OmegaRuntime(policy=RuntimePolicy(reference_ticks=1))
        with self.assertRaises(ValueError):
            runtime.subject.federate(
                peer_id="p", peer_identity_hash="h",
                mappings=[{"layer": "P", "mode": "MERGE", "local": "a", "peer": "b"}],
                local_consent="L", peer_consent="R", withdrawal_condition="any",
            )


if __name__ == "__main__":
    unittest.main()
