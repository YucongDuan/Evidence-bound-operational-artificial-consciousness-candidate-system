import unittest

from omega_acos.interiority import InteriorityLab


class InteriorityTests(unittest.TestCase):
    def test_interiority_gates(self) -> None:
        result = InteriorityLab().run()
        self.assertEqual(result["result_state"], "FUNCTIONAL_INTERIORITY_CANDIDATE")
        self.assertTrue(all(result["gates"].values()))
        self.assertEqual(result["phenomenal_conclusion"], "UNRESOLVED_NOT_CERTIFIED")

    def test_no_first_person_evidence(self) -> None:
        result = InteriorityLab().run()
        self.assertTrue(result["gates"]["first_person_report_not_used"])


if __name__ == "__main__":
    unittest.main()
