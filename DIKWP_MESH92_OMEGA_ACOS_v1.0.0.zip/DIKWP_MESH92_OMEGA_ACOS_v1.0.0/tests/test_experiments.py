import unittest

from omega_acos.experiments import PurposeCausalityLab


class ExperimentTests(unittest.TestCase):
    def test_purpose_matrix(self):
        result = PurposeCausalityLab(1234).run()
        self.assertTrue(all(result["gates"].values()))
        self.assertEqual(result["result_state"], "STRUCTURAL_PURPOSE_CAUSALITY_CANDIDATE")
        self.assertEqual(result["phenomenal_conclusion"], "BLOCKED_PHENOMENAL_RESIDUAL")

    def test_language_report_not_evidence(self):
        result = PurposeCausalityLab(1234).run()
        imitation = result["conditions"]["LANGUAGE_IMITATION"]
        self.assertTrue(imitation["report_text"])
        self.assertEqual(imitation["purpose_vector"]["repair"], 0.0)


if __name__ == "__main__":
    unittest.main()
