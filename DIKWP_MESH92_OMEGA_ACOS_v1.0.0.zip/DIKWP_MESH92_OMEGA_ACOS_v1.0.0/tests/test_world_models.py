import unittest

from omega_acos.world_models import WorldModelEnsemble


class WorldModelTests(unittest.TestCase):
    def test_plurality_calibration_and_cap(self):
        ensemble = WorldModelEnsemble.default()
        state = {"energy": .7, "integrity": .8, "repair_debt": .1, "uncertainty": .6, "prediction_error": .3, "information_gain": .7, "trust": .6, "consent": 1.0, "externality": .05, "repair_capacity": .7, "optionality": .8, "reversibility": 1.0, "lock_in": .05}
        predictions = ensemble.predict(state, proposition="x", created_tick=0, due_tick=1, observable="x")
        self.assertGreaterEqual(len(predictions), 2)
        for index, prediction in enumerate(predictions):
            ensemble.resolve(prediction.prediction_id, 1.0 if index % 2 else 0.0)
        weights = [m.weight for m in ensemble.models.values() if m.status == "ACTIVE"]
        self.assertAlmostEqual(sum(weights), 1.0, places=6)
        self.assertLessEqual(max(weights), ensemble.max_model_weight)
        self.assertTrue(all(p.brier is not None for p in predictions))

    def test_reality_debt(self):
        ensemble = WorldModelEnsemble.default()
        ensemble.predict({}, proposition="x", created_tick=0, due_tick=1, observable="x")
        self.assertEqual(len(ensemble.reality_debt(1)), 4)


if __name__ == "__main__":
    unittest.main()
