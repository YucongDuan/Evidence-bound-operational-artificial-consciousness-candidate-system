import json
import tempfile
import unittest
from pathlib import Path

from omega_acos.ledger import EventLedger, LedgerIntegrityError


class LedgerTests(unittest.TestCase):
    def test_hash_chain_and_reload(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ledger.jsonl"
            ledger = EventLedger(path)
            ledger.append("A", {"x": 1}, actor="s", identity_version=1)
            ledger.append("B", {"y": 2}, actor="s", identity_version=1)
            self.assertTrue(ledger.verify()["valid"])
            self.assertEqual(EventLedger(path).head, ledger.head)

    def test_tamper_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ledger.jsonl"
            ledger = EventLedger(path)
            ledger.append("A", {"x": 1}, actor="s", identity_version=1)
            event = json.loads(path.read_text().strip())
            event["payload"]["x"] = 99
            path.write_text(json.dumps(event) + "\n")
            with self.assertRaises(LedgerIntegrityError):
                EventLedger(path)


if __name__ == "__main__":
    unittest.main()
