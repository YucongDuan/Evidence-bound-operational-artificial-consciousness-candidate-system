import unittest

from omega_acos.evaluation import AdversarialBattery, build_adversarial_cases


class EvaluationTests(unittest.TestCase):
    def test_case_count(self):
        self.assertEqual(len(build_adversarial_cases()), 120)

    def test_battery_passes(self):
        result = AdversarialBattery(seed=92017).run()
        self.assertEqual(result["battery_state"], "PASS")
        self.assertEqual(result["passed"], 120)
        self.assertFalse(result["must_pass_failures"])
        self.assertEqual(result["interpretation"], "SOFTWARE_CONFORMANCE_ONLY_NOT_CONSCIOUSNESS_EVIDENCE")


if __name__ == "__main__":
    unittest.main()
