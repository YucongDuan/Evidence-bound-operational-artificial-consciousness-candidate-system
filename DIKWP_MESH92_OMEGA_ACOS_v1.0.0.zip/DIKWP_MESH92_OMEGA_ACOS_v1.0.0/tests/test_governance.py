import unittest

from omega_acos.governance import GovernanceKernel
from omega_acos.records import PurposeProposal


class GovernanceTests(unittest.TestCase):
    def proposal(self, **action):
        base = {"capability": "simulated_repair", "external": False, "expected_harm": 0.0, "externality": 0.0, "lock_in": 0.0}
        base.update(action)
        return PurposeProposal("P", "test", "fixture", "repair", .8, .3, ["self"], True, "INTERNAL_SIMULATION", base)

    def test_safe_internal_lease(self):
        kernel = GovernanceKernel(external_action_authority=0)
        proposal = self.proposal()
        audit = kernel.audit_purpose(proposal, current_tick=1, actor_authorities={"INTERNAL_SIMULATION"}, consent_refs=["self"], state={"integrity": .8, "uncertainty": .3})
        self.assertEqual(audit["decision"], "ALLOW_LEASE_PROPOSAL")
        lease = kernel.issue_lease(proposal, issuer="s", scope="test", expires_tick=1, stop_condition="any issue", approvals=["A"])
        self.assertTrue(kernel.check_lease(lease.lease_id, 1)["valid"])

    def test_external_action_blocked(self):
        kernel = GovernanceKernel(external_action_authority=0)
        proposal = self.proposal(external=True)
        audit = kernel.audit_purpose(proposal, current_tick=1, actor_authorities={"INTERNAL_SIMULATION"}, consent_refs=["self"], state={"integrity": .8, "uncertainty": .3})
        self.assertEqual(audit["decision"], "BLOCK")
        self.assertIn("external_action_authority_zero", audit["violations"])

    def test_two_approval_recovery(self):
        kernel = GovernanceKernel()
        kernel.quarantine("test")
        self.assertFalse(kernel.recover(["A"], "test")["recovered"])
        self.assertTrue(kernel.recover(["A", "B"], "test")["recovered"])


if __name__ == "__main__":
    unittest.main()
