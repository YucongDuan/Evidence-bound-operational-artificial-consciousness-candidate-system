#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ENV = {"PYTHONPATH": str(ROOT / "src")}


def run(command: list[str]) -> dict[str, object]:
    process = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, env={**__import__('os').environ, **ENV})
    return {
        "command": command,
        "returncode": process.returncode,
        "stdout": process.stdout[-12000:],
        "stderr": process.stderr[-12000:],
        "passed": process.returncode == 0,
    }


def main() -> int:
    checks = []
    checks.append(run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"]))
    checks.append(run([sys.executable, "tools/run_reference.py"]))
    checks.append(run([sys.executable, "-m", "omega_acos", "battery", "--out", "outputs/adversarial_battery.json"]))
    checks.append(run([sys.executable, "tools/static_boundary_audit.py"]))
    node = run(["node", "--check", "assets/app.js"])
    checks.append(node)
    with tempfile.TemporaryDirectory(prefix="omega-wheel-") as temp:
        checks.append(run([sys.executable, "-m", "pip", "wheel", ".", "--no-deps", "--no-build-isolation", "-w", temp]))
    output_files = [
        "outputs/reference_run.json",
        "outputs/reference_ledger.jsonl",
        "outputs/adversarial_battery.json",
        "outputs/static_boundary_audit.json",
    ]
    files_ok = all((ROOT / path).exists() and (ROOT / path).stat().st_size > 0 for path in output_files)
    result = {
        "validation": "OMEGA_SOFTWARE_VALIDATION_1.0",
        "checks": checks,
        "required_outputs": output_files,
        "required_outputs_present": files_ok,
        "passed": files_ok and all(bool(check["passed"]) for check in checks),
        "interpretation": "Software and protocol conformance only; not evidence of phenomenal consciousness.",
    }
    target = ROOT / "outputs/software_validation.json"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "check_count": len(checks), "output": str(target)}, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
