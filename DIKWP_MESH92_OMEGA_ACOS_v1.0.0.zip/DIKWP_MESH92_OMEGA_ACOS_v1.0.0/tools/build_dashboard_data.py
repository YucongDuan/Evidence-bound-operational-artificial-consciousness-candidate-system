#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    run = json.loads((ROOT / "outputs/reference_run.json").read_text(encoding="utf-8"))
    battery = json.loads((ROOT / "outputs/adversarial_battery.json").read_text(encoding="utf-8"))
    validation_path = ROOT / "outputs/software_validation.json"
    validation = json.loads(validation_path.read_text(encoding="utf-8")) if validation_path.exists() else {}
    payload = {"run": run, "battery": battery, "validation": validation}
    target = ROOT / "assets/reference_data.js"
    target.write_text("window.OMEGA_DATA = " + json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + ";\n", encoding="utf-8")
    print(target)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
