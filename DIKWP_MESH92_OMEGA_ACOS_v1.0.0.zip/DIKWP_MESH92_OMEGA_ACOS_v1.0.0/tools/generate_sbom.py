#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE = {".git", "__pycache__", ".pytest_cache", "release"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    components = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or any(part in EXCLUDE for part in path.parts):
            continue
        rel = path.relative_to(ROOT).as_posix()
        components.append({
            "type": "file",
            "name": rel,
            "hashes": [{"alg": "SHA-256", "content": sha256(path)}],
        })
    sbom = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.5",
        "version": 1,
        "metadata": {
            "component": {
                "type": "application",
                "name": "DIKWP-MESH92 OMEGA-ACOS",
                "version": "1.0.0",
            }
        },
        "components": components,
    }
    target = ROOT / "release/sbom.cdx.json"
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(sbom, ensure_ascii=False, indent=2), encoding="utf-8")
    manifest = ROOT / "release/SHA256SUMS"
    manifest.write_text("\n".join(f"{item['hashes'][0]['content']}  {item['name']}" for item in components) + "\n", encoding="utf-8")
    print(json.dumps({"components": len(components), "sbom": str(target), "manifest": str(manifest)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
