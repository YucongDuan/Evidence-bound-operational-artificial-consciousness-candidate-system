#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from omega_acos.runtime import OmegaRuntime  # noqa: E402


def main() -> int:
    outputs = ROOT / "outputs"
    outputs.mkdir(parents=True, exist_ok=True)
    ledger_path = outputs / "reference_ledger.jsonl"
    if ledger_path.exists():
        ledger_path.unlink()
    runtime = OmegaRuntime(ledger_path=ledger_path)
    result = runtime.run_reference()
    runtime.save_run(outputs / "reference_run.json", result)
    summary = {
        "system": result["system"],
        "version": result["version"],
        "release_state": result["release_state"],
        "run_digest": result["run_digest"],
        "tick": result["subject"]["tick"],
        "identity_version": result["subject"]["identity_version"],
        "native_genesis": result["native_genesis_lab"]["result_state"],
        "interiority": result["interiority_lab"]["result_state"],
        "purpose_causality": result["purpose_causality_lab"]["result_state"],
        "theory_indicator_count": len(result["theory_arena"]["indicators"]),
        "consciousness_total_score": result["theory_arena"]["consciousness_total_score"],
        "phenomenal_residual": result["theory_arena"]["phenomenal_residual"],
        "external_action_authority": result["policy"]["external_action_authority"],
        "reality_debt": result["reality_debt"],
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
