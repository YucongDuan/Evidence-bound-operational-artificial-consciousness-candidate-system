#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOTS = [ROOT / "src", ROOT / "assets", ROOT / "index.html"]
FORBIDDEN_PATTERNS = {
    "network_library": re.compile(r"\b(requests|urllib\.request|httpx|aiohttp|socket)\b"),
    "process_creation": re.compile(r"\b(subprocess|os\.system|Popen)\b"),
    "dynamic_execution": re.compile(r"\b(eval|exec)\s*\("),
    "external_url_in_runtime": re.compile(r"fetch\s*\(|XMLHttpRequest|WebSocket"),
    "browser_tracking": re.compile(r"google-analytics|gtag\(|segment\.com|mixpanel|telemetry", re.I),
}


def iter_files() -> list[Path]:
    files: list[Path] = []
    for root in SOURCE_ROOTS:
        if root.is_file():
            files.append(root)
        elif root.exists():
            files.extend(path for path in root.rglob("*") if path.is_file() and path.suffix in {".py", ".js", ".html", ".css"})
    return sorted(files)


def main() -> int:
    findings = []
    for path in iter_files():
        text = path.read_text(encoding="utf-8", errors="replace")
        for label, pattern in FORBIDDEN_PATTERNS.items():
            for match in pattern.finditer(text):
                line = text.count("\n", 0, match.start()) + 1
                # URLs in source provenance strings are allowed; the audit targets executable calls.
                findings.append({"file": str(path.relative_to(ROOT)), "line": line, "rule": label, "match": match.group(0)})
    # canonical.py uses no dynamic eval; JS dashboard is data-only. Allow provenance URLs by construction.
    result = {
        "audit": "OMEGA_STATIC_BOUNDARY_AUDIT_1.0",
        "files_scanned": len(iter_files()),
        "findings": findings,
        "external_action_authority_literal_zero": "external_action_authority: int = 0" in (ROOT / "src/omega_acos/runtime.py").read_text(encoding="utf-8"),
        "claim_boundary_present": (ROOT / "CLAIM_BOUNDARY.md").exists(),
        "pass": not findings,
    }
    out = ROOT / "outputs/static_boundary_audit.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["pass"] and result["external_action_authority_literal_zero"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
