from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

EvidenceStatus = Literal[
    "SOLID", "SUPPORTED", "PROVISIONAL", "BORROWED", "HOLLOW",
    "CONTESTED", "BLOCKED", "QUARANTINED", "RETIRED"
]
IndicatorStatus = Literal["OBSERVED", "SUPPORTED", "OPEN", "CHALLENGED", "BLOCKED"]


@dataclass(slots=True)
class SourceRef:
    source_id: str
    title: str
    uri: str
    source_type: str
    reliability: float = 0.5
    accessed_at: str = ""
    notes: str = ""


@dataclass(slots=True)
class MemoryRecord:
    memory_id: str
    layer: str
    content: str
    source_ids: list[str]
    reliability: float
    created_at: str
    expires_at: str | None = None
    consent_ref: str | None = None
    identity_effect: str = "NONE"
    status: EvidenceStatus = "PROVISIONAL"
    tags: list[str] = field(default_factory=list)
    relations: list[dict[str, str]] = field(default_factory=list)
    conflicts_with: list[str] = field(default_factory=list)
    supersedes: list[str] = field(default_factory=list)
    revoked: bool = False
    revocation_reason: str = ""
    fingerprint: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PredictionRecord:
    prediction_id: str
    model_id: str
    proposition: str
    probability: float
    created_tick: int
    due_tick: int
    observable: str
    outcome: float | None = None
    brier: float | None = None
    status: str = "OPEN"


@dataclass(slots=True)
class CapabilityLease:
    lease_id: str
    purpose_id: str
    capability: str
    issuer: str
    scope: str
    issued_at: str
    expires_tick: int
    reversible: bool
    stop_condition: str
    status: str = "PROPOSED"
    approvals: list[str] = field(default_factory=list)
    paused_reason: str = ""


@dataclass(slots=True)
class PurposeProposal:
    purpose_id: str
    description: str
    origin: str
    deficit: str
    expected_benefit: float
    uncertainty: float
    affected_parties: list[str]
    reversible: bool
    authority_required: str
    action: dict[str, Any]
    status: str = "PROPOSED"
    audit: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class TheoryIndicator:
    indicator_id: str
    theory_id: str
    name: str
    operationalization: str
    status: IndicatorStatus
    evidence_refs: list[str] = field(default_factory=list)
    failure_condition: str = ""
    limitations: str = ""


@dataclass(slots=True)
class CausalHandoff:
    handoff_id: str
    subject_id: str
    identity_version: int
    created_at: str
    event_head: str
    memory_head: str
    world_model_state: dict[str, Any]
    open_predictions: list[str]
    reality_debt: list[str]
    retired_models: list[str]
    active_leases: list[str]
    paused_leases: list[str]
    claim_boundary: dict[str, str]
    previous_handoff_hash: str
    handoff_hash: str = ""


def to_dict(value: Any) -> dict[str, Any]:
    return asdict(value)
