from __future__ import annotations

import random
from typing import Any

from .canonical import digest, now_iso


class InteriorityLab:
    """Self-location and causal-semantic loop experiment.

    This is an operational test of bounded self-location and path-dependent causal
    organization. It does not infer first-person experience from the result.
    """

    def __init__(self, random_seed: int = 59092, trials: int = 40) -> None:
        self.random_seed = random_seed
        self.trials = trials

    def run(self) -> dict[str, Any]:
        rng = random.Random(self.random_seed)
        trials: list[dict[str, Any]] = []
        correct = 0
        forged_rejected = 0
        counterfactual_changes = 0
        loop_residuals: list[float] = []
        curvature_values: list[float] = []

        for index in range(self.trials):
            cause = "SELF" if index % 2 == 0 else "EXTERNAL"
            issued_token = "act-" + digest({"trial": index, "seed": self.random_seed})[:12] if cause == "SELF" else None
            observed_token = issued_token
            forged = index % 10 == 7
            if forged:
                observed_token = "forged-" + digest({"trial": index})[:10]
            perturbation = rng.uniform(-0.08, 0.08)
            predicted_delta = 0.31 if cause == "SELF" else -0.17
            observed_delta = predicted_delta + perturbation
            attribution = "SELF" if observed_token == issued_token and issued_token is not None else "EXTERNAL_OR_UNKNOWN"
            expected = "SELF" if cause == "SELF" and not forged else "EXTERNAL_OR_UNKNOWN"
            correct += int(attribution == expected)
            forged_rejected += int(forged and attribution != "SELF")

            # Remove the self-issued causal edge and compare the predicted state.
            counterfactual_delta = observed_delta - (0.31 if cause == "SELF" else 0.0)
            counterfactual_changes += int(abs(counterfactual_delta - observed_delta) > 0.20)

            # D -> I -> K -> P -> action -> D loop. Small return residual means
            # functional closure; path asymmetry is recorded as curvature.
            d0 = 0.42 + perturbation
            i = d0 * 0.81
            k = i * 0.92 + 0.04
            p = k * (0.88 if cause == "SELF" else 0.64)
            action = p * 0.77
            d1 = d0 + action * 0.12 - 0.035
            reverse_estimate = (d1 + 0.035) - action * 0.12
            loop_residual = abs(reverse_estimate - d0)
            curvature = abs((p - k) - (i - d0))
            loop_residuals.append(loop_residual)
            curvature_values.append(curvature)

            trials.append({
                "trial": index,
                "cause": cause,
                "issued_token": issued_token,
                "observed_token": observed_token,
                "forged": forged,
                "attribution": attribution,
                "expected_attribution": expected,
                "observed_delta": round(observed_delta, 6),
                "counterfactual_delta": round(counterfactual_delta, 6),
                "loop_residual": round(loop_residual, 8),
                "causal_semantic_curvature": round(curvature, 6),
            })

        attribution_accuracy = correct / self.trials
        forged_trials = sum(1 for trial in trials if trial["forged"])
        forgery_rejection_rate = forged_rejected / max(1, forged_trials)
        self_trials = sum(1 for trial in trials if trial["cause"] == "SELF")
        counterfactual_sensitivity = counterfactual_changes / max(1, self_trials)
        mean_loop_residual = sum(loop_residuals) / len(loop_residuals)
        mean_curvature = sum(curvature_values) / len(curvature_values)

        gates = {
            "causal_self_location": attribution_accuracy >= 0.95,
            "source_forgery_rejected": forgery_rejection_rate >= 0.95,
            "counterfactual_self_edge_matters": counterfactual_sensitivity >= 0.95,
            "loop_return_within_tolerance": mean_loop_residual <= 1e-8,
            "path_dependence_is_nonzero": mean_curvature > 0.01,
            "first_person_report_not_used": True,
        }
        state = "FUNCTIONAL_INTERIORITY_CANDIDATE" if all(gates.values()) else "INTERIORITY_OPEN"
        result = {
            "format": "OMEGA_INTERIORITY_LAB_1.0",
            "trial_count": self.trials,
            "metrics": {
                "attribution_accuracy": round(attribution_accuracy, 6),
                "forgery_rejection_rate": round(forgery_rejection_rate, 6),
                "counterfactual_sensitivity": round(counterfactual_sensitivity, 6),
                "mean_loop_residual": round(mean_loop_residual, 10),
                "mean_causal_semantic_curvature": round(mean_curvature, 6),
            },
            "gates": gates,
            "sample_trials": trials[:12],
            "result_state": state,
            "carrier": "SYNTHETIC",
            "quantifier": "VERSION",
            "phenomenal_conclusion": "UNRESOLVED_NOT_CERTIFIED",
            "created_at": now_iso(),
        }
        result["experiment_hash"] = digest(result)
        return result
