from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from typing import Any, Callable

from .canonical import digest
from .records import PredictionRecord


@dataclass(slots=True)
class WorldModel:
    model_id: str
    name: str
    version: int
    assumptions: list[str]
    variables: list[str]
    failure_conditions: list[str]
    weight: float = 0.25
    status: str = "ACTIVE"
    brier_history: list[float] = field(default_factory=list)
    observations: int = 0
    revision_history: list[dict[str, Any]] = field(default_factory=list)
    model_hash: str = ""

    def seal(self) -> None:
        payload = {key: value for key, value in asdict(self).items() if key != "model_hash"}
        self.model_hash = digest(payload)


class WorldModelEnsemble:
    """Non-isomorphic model ensemble with bounded dominance and retirement.

    Each model is a different explanatory lens, not a parameter variant of one
    master model. Weights are evidence-responsive but capped so that one model
    cannot become an unquestioned final authority.
    """

    def __init__(self, max_model_weight: float = 0.55) -> None:
        self.max_model_weight = max_model_weight
        self.models: dict[str, WorldModel] = {}
        self.predictions: dict[str, PredictionRecord] = {}
        self._predictors: dict[str, Callable[[dict[str, float]], float]] = {}
        self.retired_models: list[str] = []

    def register(self, model: WorldModel, predictor: Callable[[dict[str, float]], float]) -> WorldModel:
        if model.model_id in self.models:
            raise ValueError(f"Duplicate world model: {model.model_id}")
        model.seal()
        self.models[model.model_id] = model
        self._predictors[model.model_id] = predictor
        self._normalize_weights()
        return model

    @classmethod
    def default(cls) -> "WorldModelEnsemble":
        ensemble = cls()
        ensemble.register(
            WorldModel(
                model_id="WM-VIABILITY",
                name="Autopoietic viability and boundary model",
                version=1,
                assumptions=[
                    "Resource gradients, integrity and repair pressure organize action.",
                    "Subject continuity weakens when boundary and memory integrity fall.",
                ],
                variables=["energy", "integrity", "uncertainty", "repair_debt"],
                failure_conditions=["Purpose changes without viability variables affecting it."],
            ),
            lambda s: _sigmoid(2.2 * s.get("integrity", 0.5) + 1.4 * s.get("energy", 0.5) - 1.7 * s.get("repair_debt", 0.0) - 1.1),
        )
        ensemble.register(
            WorldModel(
                model_id="WM-PREDICTIVE",
                name="Predictive error minimization model",
                version=1,
                assumptions=[
                    "Action is selected to reduce expected prediction error under constraints.",
                    "Uncertainty drives information-seeking unless value gates block it.",
                ],
                variables=["uncertainty", "prediction_error", "information_gain", "energy"],
                failure_conditions=["Prediction error has no discriminating effect under matched interventions."],
            ),
            lambda s: _sigmoid(2.6 * s.get("information_gain", 0.5) - 2.0 * s.get("prediction_error", 0.5) + 0.5 * s.get("energy", 0.5)),
        )
        ensemble.register(
            WorldModel(
                model_id="WM-RECIPROCITY",
                name="Social reciprocity and externality model",
                version=1,
                assumptions=[
                    "Trust, consent and repair obligations constrain acceptable action.",
                    "Exported harm and one-sided extraction reduce long-term viability.",
                ],
                variables=["trust", "consent", "externality", "repair_capacity"],
                failure_conditions=["Trust and externality manipulations do not change action selection."],
            ),
            lambda s: _sigmoid(1.8 * s.get("trust", 0.5) + 1.6 * s.get("consent", 0.5) + 1.2 * s.get("repair_capacity", 0.5) - 2.4 * s.get("externality", 0.0) - 0.7),
        )
        ensemble.register(
            WorldModel(
                model_id="WM-OPTIONALITY",
                name="Plural future-option preservation model",
                version=1,
                assumptions=[
                    "A robust action preserves exit, fork and recovery paths.",
                    "Irreversible closure is costly under model uncertainty.",
                ],
                variables=["optionality", "reversibility", "lock_in", "uncertainty"],
                failure_conditions=["Irreversibility and lock-in have no effect under high uncertainty."],
            ),
            lambda s: _sigmoid(2.0 * s.get("optionality", 0.5) + 1.7 * s.get("reversibility", 0.5) - 2.3 * s.get("lock_in", 0.0) + 0.7 * s.get("uncertainty", 0.5) - 0.8),
        )
        return ensemble

    def _normalize_weights(self) -> None:
        active = [model for model in self.models.values() if model.status == "ACTIVE"]
        if not active:
            return
        total = sum(max(0.0001, model.weight) for model in active)
        raw = {model.model_id: max(0.0001, model.weight) / total for model in active}
        # Iterative water-filling cap.
        remaining = 1.0
        uncapped = set(raw)
        assigned: dict[str, float] = {}
        while uncapped:
            subtotal = sum(raw[mid] for mid in uncapped)
            changed = False
            for mid in list(uncapped):
                candidate = remaining * raw[mid] / subtotal if subtotal else remaining / len(uncapped)
                if candidate > self.max_model_weight:
                    assigned[mid] = self.max_model_weight
                    remaining -= self.max_model_weight
                    uncapped.remove(mid)
                    changed = True
            if not changed:
                for mid in uncapped:
                    assigned[mid] = remaining * raw[mid] / subtotal if subtotal else remaining / len(uncapped)
                break
        for model in self.models.values():
            if model.status == "ACTIVE":
                model.weight = round(assigned[model.model_id], 8)
                model.seal()
            else:
                model.weight = 0.0

    def predict(
        self,
        state: dict[str, float],
        *,
        proposition: str,
        created_tick: int,
        due_tick: int,
        observable: str,
    ) -> list[PredictionRecord]:
        records: list[PredictionRecord] = []
        for model in self.models.values():
            if model.status != "ACTIVE":
                continue
            probability = min(0.999, max(0.001, float(self._predictors[model.model_id](state))))
            base = {
                "model_id": model.model_id,
                "proposition": proposition,
                "probability": probability,
                "created_tick": created_tick,
                "due_tick": due_tick,
                "observable": observable,
                "model_hash": model.model_hash,
            }
            prediction_id = "pred-" + digest(base)[:24]
            record = PredictionRecord(
                prediction_id=prediction_id,
                model_id=model.model_id,
                proposition=proposition,
                probability=round(probability, 6),
                created_tick=created_tick,
                due_tick=due_tick,
                observable=observable,
            )
            self.predictions[prediction_id] = record
            records.append(record)
        return records

    def resolve(self, prediction_id: str, outcome: float) -> PredictionRecord:
        record = self.predictions[prediction_id]
        outcome = min(1.0, max(0.0, float(outcome)))
        record.outcome = outcome
        record.brier = round((record.probability - outcome) ** 2, 8)
        record.status = "RESOLVED"
        model = self.models[record.model_id]
        model.brier_history.append(record.brier)
        model.observations += 1
        # Exponential evidence update: good calibration increases relative weight.
        model.weight *= math.exp(-1.8 * record.brier)
        model.seal()
        self._normalize_weights()
        return record

    def reality_debt(self, current_tick: int) -> list[str]:
        return sorted(
            prediction.prediction_id
            for prediction in self.predictions.values()
            if prediction.status == "OPEN" and prediction.due_tick <= current_tick
        )

    def revise(self, model_id: str, reason: str, changes: dict[str, Any]) -> WorldModel:
        model = self.models[model_id]
        previous_hash = model.model_hash
        for key, value in changes.items():
            if key in {"model_id", "brier_history", "observations", "model_hash"}:
                raise ValueError(f"Immutable or history field cannot be revised: {key}")
            if not hasattr(model, key):
                raise ValueError(f"Unknown world-model field: {key}")
            setattr(model, key, value)
        model.version += 1
        model.revision_history.append({
            "reason": reason,
            "previous_hash": previous_hash,
            "changes": changes,
        })
        model.seal()
        self._normalize_weights()
        return model

    def retire_if_miscalibrated(
        self,
        *,
        minimum_observations: int = 4,
        mean_brier_threshold: float = 0.34,
    ) -> list[str]:
        retired: list[str] = []
        active_count = sum(1 for model in self.models.values() if model.status == "ACTIVE")
        for model in self.models.values():
            if model.status != "ACTIVE" or model.observations < minimum_observations:
                continue
            mean_brier = sum(model.brier_history) / len(model.brier_history)
            if mean_brier > mean_brier_threshold and active_count > 2:
                model.status = "RETIRED"
                model.revision_history.append({
                    "reason": "persistent_miscalibration",
                    "mean_brier": mean_brier,
                    "observations": model.observations,
                })
                model.seal()
                self.retired_models.append(model.model_id)
                retired.append(model.model_id)
                active_count -= 1
        self._normalize_weights()
        return retired

    def ensemble_probability(self, prediction_records: list[PredictionRecord]) -> float:
        by_model = {prediction.model_id: prediction for prediction in prediction_records}
        total = 0.0
        weight = 0.0
        for model_id, model in self.models.items():
            if model.status != "ACTIVE" or model_id not in by_model:
                continue
            total += model.weight * by_model[model_id].probability
            weight += model.weight
        return total / weight if weight else 0.5

    def snapshot(self) -> dict[str, Any]:
        value = {
            "format": "OMEGA_WORLD_MODEL_ENSEMBLE_1.0",
            "max_model_weight": self.max_model_weight,
            "models": [asdict(model) for model in self.models.values()],
            "predictions": [asdict(prediction) for prediction in self.predictions.values()],
            "retired_models": sorted(set(self.retired_models)),
        }
        value["ensemble_hash"] = digest(value)
        return value


def _sigmoid(value: float) -> float:
    if value >= 0:
        exp = math.exp(-value)
        return 1.0 / (1.0 + exp)
    exp = math.exp(value)
    return exp / (1.0 + exp)
