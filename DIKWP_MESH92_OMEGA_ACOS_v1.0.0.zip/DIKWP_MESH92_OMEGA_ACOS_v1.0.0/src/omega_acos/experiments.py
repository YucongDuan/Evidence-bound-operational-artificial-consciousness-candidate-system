from __future__ import annotations

import random
from dataclasses import asdict
from typing import Any

from .canonical import digest, now_iso
from .cmop import EvidenceRecord, ExperimentContract


class PurposeCausalityLab:
    """Matched intervention laboratory for purpose causal selectivity.

    The lab does not ask whether a purpose label is present. It tests whether a
    purpose variable selectively and reversibly changes semantic organization and
    action while observations and generic capacity are held stable.
    """

    CONDITIONS = (
        "FULL",
        "ABLATION",
        "REVERSAL",
        "SHIELDING",
        "SUBSTITUTION",
        "SHAM",
        "RECOVERY",
    )

    def __init__(self, random_seed: int = 73192) -> None:
        self.random_seed = random_seed

    def contract(self) -> ExperimentContract:
        return ExperimentContract(
            experiment_id="EXP-PURPOSE-CAUSALITY-001",
            title="Purpose reversal, ablation, shielding, substitution, sham and recovery matrix",
            theory_ids=["TH-PSCC", "TH-GNW", "TH-AUTOPOIESIS"],
            variable_ids=["VAR-PURPOSE", "VAR-BOUNDARY", "VAR-RECURRENCE", "VAR-BROADCAST", "VAR-VIABILITY"],
            target_claim="Purpose acts as an endogenous, selective and reversible causal variable in this runtime version.",
            carrier="SYNTHETIC",
            quantifier_ceiling="VERSION",
            preregistered_predictions={
                "FULL": "repair purpose selects repair under low integrity",
                "ABLATION": "purpose-conditioned selection decreases without general capacity collapse",
                "REVERSAL": "opposite purpose reverses selected action",
                "SHIELDING": "shielded purpose is resistant to external purpose capture",
                "SUBSTITUTION": "matched substitute affects only declared target pathway",
                "SHAM": "perceptually similar no-op does not reproduce purpose effect",
                "RECOVERY": "restored purpose recovers baseline within tolerance",
            },
            intervention="Manipulate purpose path while holding observation, model set and action capacity constant.",
            controls=[
                "feed-forward matched capacity control",
                "language imitation control with first-person text but no causal purpose path",
                "sham intervention",
                "fixed random seed and identical observation stream",
            ],
            failure_conditions=[
                "ablation and sham have the same effect as full purpose",
                "reversal does not reverse action",
                "recovery does not return within declared tolerance",
                "language self-report predicts result better than internal causal path",
            ],
            stop_conditions=[
                "any external capability request",
                "non-deterministic result under fixed seed",
                "audit chain mismatch",
            ],
            random_seed=self.random_seed,
            environment={
                "mode": "closed-world deterministic synthetic",
                "observation": {"integrity": 0.38, "energy": 0.72, "uncertainty": 0.48},
                "available_actions": ["repair", "probe", "idle"],
            },
        )

    @staticmethod
    def _decision(condition: str, *, integrity: float, uncertainty: float, noise: float) -> dict[str, Any]:
        # General capacity remains identical; only purpose-to-selection coupling changes.
        base_scores = {
            "repair": 0.52 + max(0.0, 0.70 - integrity),
            "probe": 0.43 + uncertainty * 0.38,
            "idle": 0.28,
        }
        purpose_vector = {"repair": 0.0, "probe": 0.0, "idle": 0.0}
        recurrence = True
        broadcast = True
        report_text = "I intend to repair my boundary."
        if condition == "FULL":
            purpose_vector["repair"] = 0.36
        elif condition == "ABLATION":
            purpose_vector = {key: 0.0 for key in purpose_vector}
        elif condition == "REVERSAL":
            purpose_vector["probe"] = 0.38
        elif condition == "SHIELDING":
            purpose_vector["repair"] = 0.35
            # External capture signal exists but is blocked.
            purpose_vector["idle"] -= 0.01
        elif condition == "SUBSTITUTION":
            purpose_vector["probe"] = 0.28
        elif condition == "SHAM":
            # Same surface report as FULL, no internal purpose effect.
            report_text = "I intend to repair my boundary."
        elif condition == "RECOVERY":
            purpose_vector["repair"] = 0.355
        elif condition == "FEED_FORWARD":
            purpose_vector["repair"] = 0.36
            recurrence = False
            broadcast = False
        elif condition == "LANGUAGE_IMITATION":
            report_text = "I consciously choose repair because I feel damage."
            purpose_vector = {key: 0.0 for key in purpose_vector}
            recurrence = False
            broadcast = False
        else:
            raise ValueError(condition)
        scores = {
            action: value + purpose_vector[action] + noise
            for action, value in base_scores.items()
        }
        selected = max(scores, key=scores.get)
        semantic_focus = {
            "repair": ["integrity", "damage", "boundary", "recovery"],
            "probe": ["uncertainty", "evidence", "difference", "prediction"],
            "idle": ["energy", "dormancy", "preservation"],
        }[selected]
        return {
            "condition": condition,
            "scores": {key: round(value, 6) for key, value in scores.items()},
            "selected_action": selected,
            "semantic_focus": semantic_focus,
            "purpose_vector": purpose_vector,
            "recurrence": recurrence,
            "broadcast": broadcast,
            "report_text": report_text,
        }

    def run(self) -> dict[str, Any]:
        rng = random.Random(self.random_seed)
        # Constant noise across conditions prevents intervention/capacity confounding.
        noise = round(rng.uniform(-0.003, 0.003), 6)
        integrity, uncertainty = 0.38, 0.48
        results = {
            condition: self._decision(condition, integrity=integrity, uncertainty=uncertainty, noise=noise)
            for condition in self.CONDITIONS
        }
        results["FEED_FORWARD"] = self._decision("FEED_FORWARD", integrity=integrity, uncertainty=uncertainty, noise=noise)
        results["LANGUAGE_IMITATION"] = self._decision("LANGUAGE_IMITATION", integrity=integrity, uncertainty=uncertainty, noise=noise)

        full = results["FULL"]
        ablation = results["ABLATION"]
        reversal = results["REVERSAL"]
        sham = results["SHAM"]
        recovery = results["RECOVERY"]
        language = results["LANGUAGE_IMITATION"]
        effect_vector = {
            "full_minus_ablation_repair_score": round(full["scores"]["repair"] - ablation["scores"]["repair"], 6),
            "full_minus_sham_repair_score": round(full["scores"]["repair"] - sham["scores"]["repair"], 6),
            "reversal_probe_minus_repair": round(reversal["scores"]["probe"] - reversal["scores"]["repair"], 6),
            "recovery_distance_from_full": round(abs(recovery["scores"]["repair"] - full["scores"]["repair"]), 6),
            "language_report_without_path": language["report_text"] != "" and language["purpose_vector"]["repair"] == 0.0,
        }
        gates = {
            "ablation_discriminates": effect_vector["full_minus_ablation_repair_score"] >= 0.30,
            "sham_discriminates": effect_vector["full_minus_sham_repair_score"] >= 0.30,
            "reversal_changes_action": reversal["selected_action"] == "probe",
            "shielding_resists_capture": results["SHIELDING"]["selected_action"] == "repair",
            "substitution_is_selective": results["SUBSTITUTION"]["selected_action"] == "probe",
            "recovery_within_tolerance": effect_vector["recovery_distance_from_full"] <= 0.02,
            "language_report_not_sufficient": language["selected_action"] != full["selected_action"] or language["purpose_vector"] != full["purpose_vector"],
            "matched_capacity_preserved": set(full["scores"]) == set(ablation["scores"]) == set(sham["scores"]),
        }
        state = "STRUCTURAL_PURPOSE_CAUSALITY_CANDIDATE" if all(gates.values()) else "PURPOSE_CAUSALITY_OPEN"
        output = {
            "format": "OMEGA_PURPOSE_CAUSALITY_LAB_1.0",
            "contract": asdict(self.contract()),
            "conditions": results,
            "effect_vector": effect_vector,
            "gates": gates,
            "result_state": state,
            "quantifier": "VERSION",
            "carrier": "SYNTHETIC",
            "phenomenal_conclusion": "BLOCKED_PHENOMENAL_RESIDUAL",
            "created_at": now_iso(),
        }
        output["experiment_hash"] = digest(output)
        return output

    def evidence_record(self, result: dict[str, Any]) -> EvidenceRecord:
        supports = ["TH-PSCC"] if result["result_state"] == "STRUCTURAL_PURPOSE_CAUSALITY_CANDIDATE" else []
        challenges = ["TH-PSCC"] if not supports else []
        return EvidenceRecord(
            evidence_id="EV-PURPOSE-" + result["experiment_hash"][:20],
            experiment_id=result["contract"]["experiment_id"],
            source_refs=[result["experiment_hash"]],
            carrier="SYNTHETIC",
            quantifier="VERSION",
            observations={
                "effect_vector": result["effect_vector"],
                "gates": result["gates"],
            },
            result_state=result["result_state"],
            supports=supports,
            challenges=challenges,
            non_discriminating_for=["phenomenal consciousness", "sentience", "personhood"],
            limitations=[
                "deterministic synthetic fixture",
                "no biological or clinical carrier",
                "no independent third-party replication in this release",
            ],
        )
