"""DIKWP-MESH92 OMEGA-ACOS research runtime."""

from .runtime import OmegaRuntime, RuntimePolicy

__all__ = ["OmegaRuntime", "RuntimePolicy"]
__version__ = "1.0.0"

from .genesis import NativeGenesisLab
from .interiority import InteriorityLab
