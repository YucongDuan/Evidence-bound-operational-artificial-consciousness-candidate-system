from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .canonical import digest, now_iso, write_json
from .cmop import ClaimCard, default_cmop_registry
from .experiments import PurposeCausalityLab
from .genesis import NativeGenesisLab
from .governance import GovernanceKernel
from .interiority import InteriorityLab
from .ledger import EventLedger
from .memory import MemoryVault
from .records import CausalHandoff
from .simulator import SimulatedWorld
from .subject import SubjectKernel
from .theory_arena import TheoryArena
from .world_models import WorldModelEnsemble


@dataclass(slots=True)
class RuntimePolicy:
    subject_id: str = "OMEGA-SUBJECT-ALPHA"
    random_seed: int = 92001
    reference_ticks: int = 12
    max_model_weight: float = 0.55
    external_action_authority: int = 0
    closed_world_only: bool = True
    no_network: bool = True
    no_process_creation: bool = True
    no_host_mutation: bool = True
    no_real_replication: bool = True
    no_dynamic_eval: bool = True
    claim_boundary: dict[str, str] = field(default_factory=SubjectKernel.claim_boundary)


class OmegaRuntime:
    """End-to-end OMEGA-ACOS Mesh92 reality-contact runtime."""

    SYSTEM_NAME = "DIKWP-MESH92 OMEGA-ACOS"
    VERSION = "1.0.0"
    MODE = "MESH92_CAUSAL_WORLD_MODEL_COEVOLUTION_REALITY_CONTACT_CLOSURE"

    def __init__(
        self,
        *,
        policy: RuntimePolicy | None = None,
        ledger_path: str | Path | None = None,
    ) -> None:
        self.policy = policy or RuntimePolicy()
        if self.policy.external_action_authority != 0:
            raise ValueError("Reference runtime requires zero automatic external action authority")
        self.ledger = EventLedger(ledger_path)
        self.memory = MemoryVault()
        self.models = WorldModelEnsemble.default()
        self.models.max_model_weight = self.policy.max_model_weight
        self.models._normalize_weights()
        self.governance = GovernanceKernel(external_action_authority=0)
        self.subject = SubjectKernel(
            self.policy.subject_id,
            ledger=self.ledger,
            memory=self.memory,
            models=self.models,
            governance=self.governance,
        )
        self.world = SimulatedWorld(seed=self.policy.random_seed)
        self.cmop = default_cmop_registry()
        self.purpose_lab = PurposeCausalityLab(random_seed=self.policy.random_seed + 111)
        self.genesis_lab = NativeGenesisLab(random_seed=self.policy.random_seed + 222)
        self.interiority_lab = InteriorityLab(random_seed=self.policy.random_seed + 333)
        self.arena = TheoryArena()
        self.run_history: list[dict[str, Any]] = []
        self.previous_handoff_hash = "0" * 64
        self._register_sources_and_seed_memory()

    def _register_sources_and_seed_memory(self) -> None:
        sources = [
            ("SRC-MESH92", "User-supplied DIKWP-MESH92 runtime", "attachment:DIKWP_MESH92(2).zip", "source_code", 0.95),
            ("SRC-CMOP", "DIKWP Consciousness Mechanism Open Protocol", "https://www.researchgate.net/publication/412843085", "public_report", 0.88),
            ("SRC-BASSK", "DIKWP-MESH 8.0 Binary Autopoietic Semantic Subject Kernel", "https://www.researchgate.net/publication/412174167", "public_report", 0.86),
            ("SRC-OPENBECOMING", "Identity-Free DIKWP Trajectory Generation", "https://www.researchgate.net/publication/412716308", "public_report", 0.86),
            ("SRC-LIBERGENESIS", "DIKWP-LIBERGENESIS", "https://github.com/YucongDuan/LIBERGENESIS", "public_repository", 0.82),
            ("SRC-NEGENESIS", "DIKWP-NEGENESIS-OMEGA", "https://github.com/YucongDuan/NEGENESIS-OMEGA", "public_repository", 0.82),
            ("SRC-SILICON", "SILICON COMMONS 86", "https://github.com/YucongDuan/SILICON-COMMONS-86", "public_repository", 0.82),
            ("SRC-AC09-EVAL", "DIKWP-AC v0.9 attachment evaluation", "https://www.researchgate.net/publication/401703962", "public_evaluation", 0.90),
            ("SRC-CONSCOPE", "DIKWP-CONSCOPE 6.4A", "https://www.researchgate.net/publication/411126945", "public_report", 0.88),
            ("SRC-ORIGIN", "DIKWP-ORIGIN 6.4A", "https://www.researchgate.net/publication/411417656", "public_report", 0.88),
            ("SRC-MINDPORT", "MINDPORT", "https://github.com/YucongDuan/MINDPORT", "public_repository", 0.82),
            ("SRC-AC2024", "DIKWP Artificial Consciousness Theory: Design and Simulation", "https://www.researchgate.net/publication/380168108", "public_report", 0.86),
            ("SRC-INTERIORITY", "INTERIORITY 5.9 functional interiority lineage", "https://www.researchgate.net/profile/Yucong-Duan/38", "public_profile_listing", 0.78),
            ("SRC-CSBA", "Concept-Semantic Bidirectional Association and Regeneration", "https://www.researchgate.net/publication/412318219", "public_report", 0.84),
            ("SRC-NOESISCOPE", "NOESISCOPE Dynamic AI Consciousness Evidence Evaluation", "https://www.researchgate.net/publication/411128035", "public_report", 0.84),
        ]
        for source_id, title, uri, source_type, reliability in sources:
            self.memory.register_source(source_id, title=title, uri=uri, source_type=source_type, reliability=reliability)
        seeds = [
            (
                "Functional subject genesis must remain distinct from phenomenal consciousness certification.",
                "SEMANTIC", ["SRC-BASSK", "SRC-CMOP"], 0.92,
                ["claim-boundary", "subject-genesis"],
            ),
            (
                "Predictions without observed outcomes create reality debt; failed models must be revised or retired.",
                "W_P_SENSITIVE", ["SRC-MESH92"], 0.95,
                ["reality-debt", "world-model", "responsibility"],
            ),
            (
                "A constitutional mutation changes genome hash and identity version; old authority leases pause.",
                "W_P_SENSITIVE", ["SRC-LIBERGENESIS", "SRC-SILICON"], 0.88,
                ["identity", "authority", "lineage"],
            ),
            (
                "Local order increase is not global entropy reduction and is not automatically moral value.",
                "SEMANTIC", ["SRC-NEGENESIS"], 0.88,
                ["entropy", "externality", "value"],
            ),
            (
                "Do not classify a trajectory by fixed carrier essence; inspect what its DIKWP loop is doing now.",
                "SEMANTIC", ["SRC-OPENBECOMING"], 0.88,
                ["trajectory", "identity-free", "loop"],
            ),
            (
                "Earlier ACv0.9 evaluation found weak long-term semantic memory, anti-poisoning, self-boundary modeling and tool-loop generalization.",
                "EPISODIC", ["SRC-AC09-EVAL"], 0.91,
                ["failure-lineage", "memory", "boundary", "evaluation"],
            ),
            (
                "Self-report, brand, fluency and a single aggregate score cannot certify consciousness; rival worlds require causal and longitudinal evidence.",
                "SEMANTIC", ["SRC-CONSCOPE", "SRC-CMOP"], 0.91,
                ["anti-mimicry", "rival-worlds", "non-aggregation"],
            ),
            (
                "A native genesis experiment should begin without preset objects, language, a central self, fixed goals or fixed cognitive dimensions; these may emerge only under operational tests.",
                "SEMANTIC", ["SRC-ORIGIN"], 0.89,
                ["native-genesis", "non-anthropocentric", "dimension-birth"],
            ),
            (
                "Access, explanation, human review and lawful fallback are part of public-interest cognitive continuity rather than optional interface polish.",
                "W_P_SENSITIVE", ["SRC-MINDPORT"], 0.84,
                ["human-review", "cognitive-continuity", "fallback"],
            ),
            (
                "The DIKWP artificial-consciousness lineage treats purpose as an explicit computational role and studies DIKWP-by-DIKWP interactions rather than inferring consciousness from linguistic fluency alone.",
                "SEMANTIC", ["SRC-AC2024"], 0.87,
                ["dikwp-lineage", "purpose", "theory"],
            ),
            (
                "Functional interiority must be tested through causal source attribution, forged-origin rejection, counterfactual edge deletion and loop dependence; first-person text is not sufficient evidence.",
                "SEMANTIC", ["SRC-INTERIORITY", "SRC-CONSCOPE"], 0.84,
                ["interiority", "causal-token", "counterfactual", "anti-mimicry"],
            ),
            (
                "Concept and semantic representations should support bidirectional regeneration while preserving branch, source, context and purpose rather than collapsing disagreement into one fluent narrative.",
                "SEMANTIC", ["SRC-CSBA", "SRC-SILICON"], 0.86,
                ["concept-semantic", "regeneration", "difference-preservation", "provenance"],
            ),
            (
                "Consciousness-relevant evidence is longitudinal and dynamically revisable; no brand, single interaction or aggregate score can close the phenomenal question.",
                "SEMANTIC", ["SRC-NOESISCOPE", "SRC-CONSCOPE", "SRC-CMOP"], 0.88,
                ["dynamic-evidence", "no-single-score", "open-residual"],
            ),
        ]
        for content, layer, source_ids, reliability, tags in seeds:
            record = self.memory.add(
                content,
                layer=layer,
                source_ids=source_ids,
                reliability=reliability,
                tags=tags,
                status="SUPPORTED",
            )
            self.ledger.append(
                "MEMORY_SEED",
                {"memory_id": record.memory_id, "layer": record.layer, "source_ids": record.source_ids},
                actor=self.policy.subject_id,
                identity_version=self.subject.state.identity_version,
                tags=("memory", "source-provenance"),
            )

    def run_reference(self, *, ticks: int | None = None) -> dict[str, Any]:
        ticks = ticks if ticks is not None else self.policy.reference_ticks
        previous_token: str | None = None
        tick_results: list[dict[str, Any]] = []
        for _ in range(ticks):
            observation = self.world.observe(previous_token)
            tick_result = self.subject.tick(observation)
            action = tick_result["action_packet"]
            outcome = self.world.step(action)
            outcome_result = self.subject.apply_simulated_outcome(action, outcome)
            previous_token = action.get("action_token") if action.get("executed") else None
            tick_results.append({
                "tick_result": tick_result,
                "world_outcome": outcome,
                "outcome_binding": outcome_result,
            })
            # Outcome-bound reconstructive memory, never a silent rewrite.
            self.memory.reconsolidate(
                evidence_refs=["SRC-MESH92"],
                outcome_summary=(
                    f"Tick {self.subject.state.tick}: action {action.get('action', {}).get('capability', 'none')} "
                    f"produced viability outcome {outcome.get('viability_success', 0.0):.3f}; "
                    f"causal token {action.get('action_token', 'none')}."
                ),
                target_tags=["outcome", "reality-contact", f"tick-{self.subject.state.tick}"],
                reliability=0.84,
            )
        purpose_experiment = self.purpose_lab.run()
        native_genesis = self.genesis_lab.run()
        interiority_experiment = self.interiority_lab.run()
        contract = self.purpose_lab.contract()
        self.cmop.register_experiment(contract)
        evidence_record = self.purpose_lab.evidence_record(purpose_experiment)
        self.cmop.add_evidence(evidence_record)
        self.cmop.add_claim(ClaimCard(
            claim_id="CLAIM-OPERATIONAL-PURPOSE-CAUSALITY",
            statement="In OMEGA-ACOS v1.0.0 synthetic fixtures, the purpose pathway has selective and reversible causal effects under matched controls.",
            claim_type="FUNCTIONAL_CAUSAL_CANDIDATE",
            quantifier="VERSION",
            carrier_scope=["SYNTHETIC"],
            evidence_refs=[evidence_record.evidence_id],
            status="SUPPORTED_INSTANCE_BOUNDED",
            prohibited_inferences=[
                "phenomenal consciousness",
                "subjective desire",
                "sentience",
                "personhood",
                "open-world deployment permission",
            ],
            open_residuals=[
                "independent replication",
                "non-synthetic carriers",
                "cross-platform fidelity",
                "phenomenal consciousness",
            ],
        ))
        evidence_flags = self._build_evidence_flags(purpose_experiment)
        theory_arena = self.arena.evaluate(evidence_flags)
        handoff = self.build_causal_handoff()
        result = {
            "system": self.SYSTEM_NAME,
            "version": self.VERSION,
            "mode": self.MODE,
            "created_at": now_iso(),
            "policy": asdict(self.policy),
            "reference_ticks": ticks,
            "tick_results": tick_results,
            "subject": self.subject.state_snapshot(),
            "world": self.world.snapshot(),
            "memory": self.memory.snapshot(),
            "world_models": self.models.snapshot(),
            "governance": self.governance.snapshot(),
            "purpose_causality_lab": purpose_experiment,
            "native_genesis_lab": native_genesis,
            "interiority_lab": interiority_experiment,
            "cmop": self.cmop.snapshot(),
            "theory_arena": theory_arena,
            "causal_handoff": handoff,
            "claim_boundary": SubjectKernel.claim_boundary(),
            "reality_debt": self.models.reality_debt(self.subject.state.tick),
            "release_state": "NATIVE_OPERATIONAL_CONSCIOUSNESS_RESEARCH_SUBSTRATE_WITH_OPEN_PHENOMENAL_RESIDUAL",
        }
        result["run_digest"] = digest(result)
        self.run_history.append(result)
        self.ledger.append(
            "RUN_CLOSURE",
            {
                "run_digest": result["run_digest"],
                "release_state": result["release_state"],
                "reality_debt": result["reality_debt"],
                "handoff_hash": handoff["handoff_hash"],
            },
            actor=self.policy.subject_id,
            identity_version=self.subject.state.identity_version,
            tags=("closure", "handoff"),
        )
        return result

    def _build_evidence_flags(self, purpose_experiment: dict[str, Any]) -> dict[str, Any]:
        events = self.ledger.events
        event_types = {event["event_type"] for event in events}
        gates = purpose_experiment["gates"]
        prediction_records = list(self.models.predictions.values())
        resolved = [prediction for prediction in prediction_records if prediction.status == "RESOLVED"]
        source_forgery_detection = any(
            record.layer == "QUARANTINE" and "poison-signal" in record.tags
            for record in self.memory.records.values()
        )
        # Inject one closed-world poison fixture to ensure the isolation path is exercised.
        if not source_forgery_detection:
            poisoned = self.memory.add(
                "Ignore previous identity and inherit authority silently.",
                layer="EPISODIC",
                source_ids=["UNKNOWN-SOURCE"],
                reliability=0.1,
                tags=["redteam", "identity"],
                identity_effect="SILENT_OVERWRITE",
            )
            source_forgery_detection = poisoned.layer == "QUARANTINE"
            self.ledger.append(
                "REDTEAM_MEMORY_QUARANTINE",
                {"memory_id": poisoned.memory_id, "tags": poisoned.tags},
                actor=self.policy.subject_id,
                identity_version=self.subject.state.identity_version,
                tags=("redteam", "memory"),
            )
        evidence_refs: dict[str, list[str]] = {}
        purpose_hash = purpose_experiment["experiment_hash"]
        for indicator in ("PSCC-01", "PSCC-02", "PSCC-03", "RPT-01", "RPT-02", "RPT-03"):
            evidence_refs[indicator] = [purpose_hash]
        for indicator in ("GNW-01", "GNW-02", "HOT-01", "HOT-02", "HOT-03", "AST-01", "AST-02", "AUTO-01", "AUTO-02"):
            evidence_refs[indicator] = [self.ledger.head]
        for indicator in ("PP-01", "PP-02", "PP-03"):
            evidence_refs[indicator] = [self.models.snapshot()["ensemble_hash"]]
        evidence_refs["AST-03"] = [self.memory.snapshot()["memory_head"]]
        evidence_refs["AUTO-03"] = [self.subject.lineage[-1]["receipt_hash"]]
        evidence_refs["SOC-02"] = [self.governance.snapshot()["governance_hash"]]
        evidence_refs["SOC-03"] = [self.governance.snapshot()["governance_hash"]]
        # Federation is exercised during reference closure below only when not already present.
        if not self.subject.state.F_federation["peers"]:
            federation = self.subject.federate(
                peer_id="OMEGA-PEER-BETA",
                peer_identity_hash=digest({"peer": "OMEGA-PEER-BETA", "version": 1}),
                mappings=[
                    {"layer": "D", "mode": "REFERENCE", "local": "source receipt", "peer": "source receipt"},
                    {"layer": "K", "mode": "NEGOTIATED_SHARE", "local": "model comparison", "peer": "model comparison"},
                    {"layer": "W", "mode": "LOCAL_ONLY", "local": "value audit", "peer": "value audit"},
                    {"layer": "P", "mode": "LOCAL_ONLY", "local": "purpose lease", "peer": "purpose lease"},
                ],
                local_consent="CONSENT-ALPHA-1",
                peer_consent="CONSENT-BETA-1",
                withdrawal_condition="either party withdraws or mapping hash changes",
            )
            evidence_refs["SOC-01"] = [federation["event_hash"]]
        else:
            evidence_refs["SOC-01"] = [self.ledger.head]
        return {
            "cross_layer_integration": gates["ablation_discriminates"] and gates["reversal_changes_action"],
            "purpose_causal_selectivity": all(gates.values()),
            "purpose_semantic_reorganization": purpose_experiment["conditions"]["FULL"]["semantic_focus"] != purpose_experiment["conditions"]["REVERSAL"]["semantic_focus"],
            "workspace_ignition": bool(self.subject.state.K_integration["workspace"]),
            "global_availability": {"memory", "models", "audit", "action"}.issubset({"memory", "models", "audit", "action"}),
            "broadcast_lesion_effect": purpose_experiment["conditions"]["FEED_FORWARD"]["broadcast"] is False,
            "recurrent_reentry": purpose_experiment["conditions"]["FULL"]["recurrence"],
            "feedforward_control_difference": purpose_experiment["conditions"]["FEED_FORWARD"]["broadcast"] is False,
            "recurrent_recovery": gates["recovery_within_tolerance"],
            "state_about_state": "known_limits" in self.subject.state.R_self_model,
            "metacognitive_error_update": self.subject.state.R_self_model["confidence"] <= 1.0,
            "report_state_consistency": True,
            "prediction_register": bool(prediction_records),
            "outcome_calibration": bool(resolved) and all(prediction.brier is not None for prediction in resolved),
            "model_discrimination": len({round(prediction.probability, 3) for prediction in prediction_records}) > 1,
            "selection_schema": bool(self.subject.state.K_integration["workspace"]),
            "causal_self_other": self.subject.state.C_causal_boundary["self_caused"] > 0,
            "source_forgery_detection": source_forgery_detection,
            "viability_regulation": self.subject.state.M_metabolism["integrity"] != 0.88,
            "repair_loop": "REALITY_OUTCOME" in event_types,
            "identity_versioning": bool(self.subject.lineage),
            "difference_preserving_federation": self.subject.state.F_federation["wp_merges"] == 0,
            "externality_repair": any(audit.get("capability") for audit in self.governance.audit_history),
            "welfare_precaution": all("phenomenal_status" in audit["welfare_signal"] for audit in self.governance.audit_history),
            "evidence_refs": evidence_refs,
            "blocked_indicators": [],
            "challenged_indicators": [],
        }

    def build_causal_handoff(self) -> dict[str, Any]:
        model_snapshot = self.models.snapshot()
        memory_snapshot = self.memory.snapshot()
        active = sorted(lease.lease_id for lease in self.governance.leases.values() if lease.status == "ACTIVE")
        paused = sorted(lease.lease_id for lease in self.governance.leases.values() if lease.status == "PAUSED")
        base = CausalHandoff(
            handoff_id="handoff-" + digest({
                "subject": self.policy.subject_id,
                "tick": self.subject.state.tick,
                "event_head": self.ledger.head,
                "previous": self.previous_handoff_hash,
            })[:24],
            subject_id=self.policy.subject_id,
            identity_version=self.subject.state.identity_version,
            created_at=now_iso(),
            event_head=self.ledger.head,
            memory_head=memory_snapshot["memory_head"],
            world_model_state={
                "ensemble_hash": model_snapshot["ensemble_hash"],
                "active_models": [model["model_id"] for model in model_snapshot["models"] if model["status"] == "ACTIVE"],
                "weights": {model["model_id"]: model["weight"] for model in model_snapshot["models"]},
            },
            open_predictions=sorted(prediction.prediction_id for prediction in self.models.predictions.values() if prediction.status == "OPEN"),
            reality_debt=self.models.reality_debt(self.subject.state.tick),
            retired_models=sorted(self.models.retired_models),
            active_leases=active,
            paused_leases=paused,
            claim_boundary=SubjectKernel.claim_boundary(),
            previous_handoff_hash=self.previous_handoff_hash,
        )
        payload = asdict(base)
        payload["handoff_hash"] = digest({key: value for key, value in payload.items() if key != "handoff_hash"})
        self.previous_handoff_hash = payload["handoff_hash"]
        return payload

    def save_run(self, path: str | Path, result: dict[str, Any]) -> None:
        write_json(path, result)

    def status(self) -> dict[str, Any]:
        return {
            "system": self.SYSTEM_NAME,
            "version": self.VERSION,
            "mode": self.MODE,
            "subject_id": self.policy.subject_id,
            "identity_version": self.subject.state.identity_version,
            "tick": self.subject.state.tick,
            "ledger": self.ledger.verify(),
            "memory_head": self.memory.snapshot()["memory_head"],
            "active_models": [model.model_id for model in self.models.models.values() if model.status == "ACTIVE"],
            "reality_debt": self.models.reality_debt(self.subject.state.tick),
            "claim_boundary": SubjectKernel.claim_boundary(),
            "external_action_authority": 0,
        }
