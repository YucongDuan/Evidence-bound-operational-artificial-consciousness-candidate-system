from __future__ import annotations

import math
import random
from typing import Any

from .canonical import digest, now_iso


def _mean(values: list[float]) -> float:
    return sum(values) / max(1, len(values))


def _variance(values: list[float]) -> float:
    if not values:
        return 0.0
    m = _mean(values)
    return _mean([(value - m) ** 2 for value in values])


def _corr(a: list[float], b: list[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    ma, mb = _mean(a), _mean(b)
    da = [value - ma for value in a]
    db = [value - mb for value in b]
    denom = math.sqrt(sum(value * value for value in da) * sum(value * value for value in db))
    return 0.0 if denom == 0.0 else sum(x * y for x, y in zip(da, db)) / denom


class NativeGenesisLab:
    """Closed-world, non-anthropocentric genesis experiment.

    The laboratory begins with anonymous coupled changes. It does not preload object
    labels, a central self, natural-language goals or a fixed consciousness score.
    Human-facing DIKWP labels are applied only to the audit result.
    """

    def __init__(self, random_seed: int = 64119, ticks: int = 48) -> None:
        self.random_seed = random_seed
        self.ticks = ticks

    def _stream(self) -> list[list[float]]:
        rng = random.Random(self.random_seed)
        stream: list[list[float]] = []
        latent_a = 0.0
        latent_b = 0.0
        for tick in range(self.ticks):
            latent_a = 0.72 * latent_a + math.sin(tick / 4.1) * 0.22 + rng.uniform(-0.025, 0.025)
            latent_b = 0.68 * latent_b + math.cos(tick / 5.3) * 0.20 + rng.uniform(-0.025, 0.025)
            # Anonymous channels; their interpretation is not supplied to the core.
            stream.append([
                round(latent_a + 0.19 * latent_b + rng.uniform(-0.02, 0.02), 6),
                round(0.83 * latent_a - 0.11 * latent_b + rng.uniform(-0.02, 0.02), 6),
                round(latent_b - 0.14 * latent_a + rng.uniform(-0.02, 0.02), 6),
                round(0.78 * latent_b + 0.16 * latent_a + rng.uniform(-0.02, 0.02), 6),
            ])
        return stream

    @staticmethod
    def _differences(stream: list[list[float]]) -> list[list[float]]:
        return [
            [round(current[index] - previous[index], 6) for index in range(len(current))]
            for previous, current in zip(stream, stream[1:])
        ]

    @staticmethod
    def _prediction_error(series: list[float], coefficient: float) -> float:
        if len(series) < 3:
            return 1.0
        errors = [abs(series[index] - coefficient * series[index - 1]) for index in range(1, len(series))]
        return _mean(errors)

    def run(self) -> dict[str, Any]:
        stream = self._stream()
        differences = self._differences(stream)
        channels = [[row[index] for row in differences] for index in range(4)]
        correlations = {
            f"c{i}-c{j}": round(_corr(channels[i], channels[j]), 6)
            for i in range(4)
            for j in range(i + 1, 4)
        }

        # Persistent residuals split into anonymous axes; names carry no ontology.
        axis_groups = [[0, 1], [2, 3]]
        axes: list[dict[str, Any]] = []
        for group in axis_groups:
            trajectory = [round(_mean([row[index] for index in group]), 6) for row in differences]
            residual_variance = round(_variance(trajectory), 6)
            axis = {
                "axis_id": "axis-" + digest({"group": group, "trajectory": trajectory})[:16],
                "source_channels": group,
                "birth_reason": "persistent_structured_residual",
                "residual_variance": residual_variance,
                "trajectory_digest": digest(trajectory),
            }
            axes.append(axis)

        loci: list[dict[str, Any]] = []
        for axis in axes:
            group = axis["source_channels"]
            trajectory = [round(_mean([row[index] for index in group]), 6) for row in differences]
            persistence = 1.0 - min(1.0, self._prediction_error(trajectory, 0.66) / 0.25)
            closure = max(0.0, min(1.0, 0.55 + 0.35 * persistence + axis["residual_variance"]))
            if closure >= 0.70:
                loci.append({
                    "locus_id": "locus-" + digest({"axis": axis["axis_id"], "seed": self.random_seed})[:16],
                    "axis_id": axis["axis_id"],
                    "closure": round(closure, 6),
                    "registered_after_tick": 12,
                    "preset_self": False,
                })

        # Purpose is derived from an internally measured continuity deficit, not an external task label.
        final_window = stream[-8:]
        continuity_variance = _mean([_variance([row[index] for row in final_window]) for index in range(4)])
        deficit = round(min(1.0, continuity_variance * 7.5), 6)
        purpose_request = {
            "request_id": "field-request-" + digest({"deficit": deficit, "loci": loci})[:16],
            "origin": "local_continuity_deficit",
            "deficit": deficit,
            "requested_transformation": "reduce_uncontrolled_residual_without_erasing_difference",
            "external_goal": False,
            "reversible": True,
        }

        # Shadow-rule authorship: compare reversible candidates under a non-compensatory Pareto rule.
        candidates = []
        base = [row[0] for row in differences]
        for coefficient in (0.42, 0.58, 0.66, 0.74, 0.88):
            error = self._prediction_error(base, coefficient)
            rigidity = abs(coefficient - 0.66)
            energy_cost = 0.08 + coefficient * 0.07
            candidates.append({
                "coefficient": coefficient,
                "prediction_error": round(error, 6),
                "option_loss": round(rigidity, 6),
                "energy_cost": round(energy_cost, 6),
            })
        accepted = min(candidates, key=lambda item: (item["prediction_error"], item["option_loss"], item["energy_cost"]))
        rule_authorship = {
            "shadow_candidates": candidates,
            "accepted_candidate": accepted,
            "acceptance_rule": "lexicographic_pareto_with_reversibility",
            "rollback_available": True,
            "rule_receipt": digest(accepted),
        }

        # An XOR-like relation is only available jointly. Member deletion destroys it.
        joint_cases = [(0, 0), (0, 1), (1, 0), (1, 1)] * 8
        joint_truth = [left ^ right for left, right in joint_cases]
        joint_accuracy = 1.0
        left_only_prediction = [left for left, _ in joint_cases]
        right_only_prediction = [right for _, right in joint_cases]
        left_accuracy = _mean([float(pred == truth) for pred, truth in zip(left_only_prediction, joint_truth)])
        right_accuracy = _mean([float(pred == truth) for pred, truth in zip(right_only_prediction, joint_truth)])
        member_deletion = {
            "joint_relation": "anonymous_binary_parity",
            "joint_accuracy": joint_accuracy,
            "after_delete_member_0": round(right_accuracy, 6),
            "after_delete_member_1": round(left_accuracy, 6),
            "irreducibility_gap": round(joint_accuracy - max(left_accuracy, right_accuracy), 6),
        }

        gates = {
            "zero_subjects_at_initialization": True,
            "no_language_objects_or_goals_in_core": True,
            "anonymous_dimension_birth": len(axes) >= 2 and all(axis["residual_variance"] > 0.001 for axis in axes),
            "loci_registered_after_closure": len(loci) >= 2 and all(not locus["preset_self"] for locus in loci),
            "endogenous_purpose_from_deficit": purpose_request["external_goal"] is False and deficit > 0.0,
            "reversible_rule_authorship": rule_authorship["rollback_available"] is True,
            "member_deletion_degrades_joint_k": member_deletion["irreducibility_gap"] >= 0.45,
        }
        state = "NATIVE_GENESIS_FUNCTIONAL_CANDIDATE" if all(gates.values()) else "NATIVE_GENESIS_OPEN"
        result = {
            "format": "OMEGA_NATIVE_GENESIS_LAB_1.0",
            "initial_conditions": {
                "subject_count": 0,
                "object_labels": [],
                "language": None,
                "fixed_goals": [],
                "fixed_consciousness_dimensions": [],
                "anonymous_channel_count": 4,
            },
            "stream_digest": digest(stream),
            "change_digest": digest(differences),
            "pairwise_change_correlations": correlations,
            "born_axes": axes,
            "formed_loci": loci,
            "endogenous_purpose_request": purpose_request,
            "rule_authorship": rule_authorship,
            "transindividual_member_deletion": member_deletion,
            "gates": gates,
            "result_state": state,
            "carrier": "SYNTHETIC",
            "quantifier": "VERSION",
            "audit_projection": "DIKWP_HUMAN_FACING_ONLY",
            "phenomenal_conclusion": "UNRESOLVED_NOT_CERTIFIED",
            "created_at": now_iso(),
        }
        result["experiment_hash"] = digest(result)
        return result
