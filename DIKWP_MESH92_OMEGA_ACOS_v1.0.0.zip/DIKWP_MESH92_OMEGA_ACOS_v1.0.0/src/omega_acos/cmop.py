from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from .canonical import digest, now_iso

Quantifier = Literal["INSTANCE", "VERSION", "TASK_DOMAIN", "ENVIRONMENT_SET", "UNIVERSAL"]
Carrier = Literal["SYNTHETIC", "ARTIFICIAL_SYSTEM", "HUMAN", "ANIMAL", "CLINICAL", "MIXED"]

_QUANTIFIER_RANK: dict[str, int] = {
    "INSTANCE": 0,
    "VERSION": 1,
    "TASK_DOMAIN": 2,
    "ENVIRONMENT_SET": 3,
    "UNIVERSAL": 4,
}


@dataclass(slots=True)
class TheoryCard:
    theory_id: str
    name: str
    version: str
    object_of_explanation: str
    applicable_carriers: list[str]
    temporal_scope: str
    spatial_scope: str
    mechanism: str
    variables: list[str]
    discriminating_predictions: list[str]
    falsification_conditions: list[str]
    discovery_carrier: str
    argument_carrier: str
    validation_carrier: str
    phenomenal_residual: str = "OPEN"


@dataclass(slots=True)
class VariableCard:
    variable_id: str
    name: str
    operational_definition: str
    measurement: str
    intervention: str
    confounds: list[str]
    applicable_carriers: list[str]
    quantifier_ceiling: Quantifier


@dataclass(slots=True)
class ExperimentContract:
    experiment_id: str
    title: str
    theory_ids: list[str]
    variable_ids: list[str]
    target_claim: str
    carrier: Carrier
    quantifier_ceiling: Quantifier
    preregistered_predictions: dict[str, str]
    intervention: str
    controls: list[str]
    failure_conditions: list[str]
    stop_conditions: list[str]
    random_seed: int
    environment: dict[str, Any]
    status: str = "REGISTERED"


@dataclass(slots=True)
class EvidenceRecord:
    evidence_id: str
    experiment_id: str
    source_refs: list[str]
    carrier: Carrier
    quantifier: Quantifier
    observations: dict[str, Any]
    result_state: str
    supports: list[str]
    challenges: list[str]
    non_discriminating_for: list[str]
    limitations: list[str]
    created_at: str = field(default_factory=now_iso)


@dataclass(slots=True)
class FidelityBridge:
    bridge_id: str
    source_carrier: str
    target_carrier: str
    preserved_invariants: list[str]
    allowed_losses: list[str]
    explicit_non_equivalences: list[str]
    mapping_rules: list[str]
    falsification_conditions: list[str]
    status: str = "OPEN"


@dataclass(slots=True)
class ClaimCard:
    claim_id: str
    statement: str
    claim_type: str
    quantifier: Quantifier
    carrier_scope: list[str]
    evidence_refs: list[str]
    status: str
    prohibited_inferences: list[str]
    open_residuals: list[str]


class CMOPRegistry:
    """Theory-to-evidence registry with carrier and quantifier ceilings."""

    def __init__(self) -> None:
        self.theories: dict[str, TheoryCard] = {}
        self.variables: dict[str, VariableCard] = {}
        self.experiments: dict[str, ExperimentContract] = {}
        self.evidence: dict[str, EvidenceRecord] = {}
        self.bridges: dict[str, FidelityBridge] = {}
        self.claims: dict[str, ClaimCard] = {}

    def add_theory(self, card: TheoryCard) -> None:
        self._unique(card.theory_id, self.theories, "theory")
        self.theories[card.theory_id] = card

    def add_variable(self, card: VariableCard) -> None:
        self._unique(card.variable_id, self.variables, "variable")
        self.variables[card.variable_id] = card

    def register_experiment(self, contract: ExperimentContract) -> None:
        self._unique(contract.experiment_id, self.experiments, "experiment")
        missing_theories = sorted(set(contract.theory_ids) - self.theories.keys())
        missing_variables = sorted(set(contract.variable_ids) - self.variables.keys())
        if missing_theories or missing_variables:
            raise ValueError({"missing_theories": missing_theories, "missing_variables": missing_variables})
        for variable_id in contract.variable_ids:
            ceiling = self.variables[variable_id].quantifier_ceiling
            if _QUANTIFIER_RANK[contract.quantifier_ceiling] > _QUANTIFIER_RANK[ceiling]:
                raise ValueError(f"Experiment quantifier exceeds variable {variable_id} ceiling")
        self.experiments[contract.experiment_id] = contract

    def add_evidence(self, record: EvidenceRecord) -> None:
        self._unique(record.evidence_id, self.evidence, "evidence")
        contract = self.experiments.get(record.experiment_id)
        if contract is None:
            raise ValueError(f"Unknown experiment: {record.experiment_id}")
        if record.carrier != contract.carrier:
            raise ValueError("Evidence carrier does not match experiment contract")
        if _QUANTIFIER_RANK[record.quantifier] > _QUANTIFIER_RANK[contract.quantifier_ceiling]:
            raise ValueError("Evidence quantifier exceeds experiment ceiling")
        if record.carrier == "SYNTHETIC" and record.quantifier == "UNIVERSAL":
            raise ValueError("Synthetic evidence cannot carry a universal quantifier")
        self.evidence[record.evidence_id] = record
        contract.status = "EXECUTED"

    def add_bridge(self, bridge: FidelityBridge) -> None:
        self._unique(bridge.bridge_id, self.bridges, "bridge")
        self.bridges[bridge.bridge_id] = bridge

    def add_claim(self, claim: ClaimCard) -> None:
        self._unique(claim.claim_id, self.claims, "claim")
        missing = sorted(set(claim.evidence_refs) - self.evidence.keys())
        if missing:
            raise ValueError(f"Claim references unknown evidence: {missing}")
        evidence_records = [self.evidence[ref] for ref in claim.evidence_refs]
        if evidence_records:
            maximum = max(_QUANTIFIER_RANK[record.quantifier] for record in evidence_records)
            if _QUANTIFIER_RANK[claim.quantifier] > maximum:
                raise ValueError("Claim quantifier exceeds supporting evidence")
        if "phenomenal" in claim.claim_type.lower() or "sentience" in claim.claim_type.lower():
            if claim.status not in {"OPEN", "BLOCKED", "NOT_ESTABLISHED"}:
                raise ValueError("Phenomenal or sentience claims cannot be certified by this registry")
        self.claims[claim.claim_id] = claim

    def validate(self) -> dict[str, Any]:
        errors: list[str] = []
        for experiment in self.experiments.values():
            if len(experiment.controls) < 2:
                errors.append(f"{experiment.experiment_id}:insufficient_controls")
            if not experiment.failure_conditions:
                errors.append(f"{experiment.experiment_id}:missing_failure_conditions")
            if not experiment.stop_conditions:
                errors.append(f"{experiment.experiment_id}:missing_stop_conditions")
        for theory in self.theories.values():
            if not theory.falsification_conditions:
                errors.append(f"{theory.theory_id}:no_falsification")
        for bridge in self.bridges.values():
            if not bridge.explicit_non_equivalences:
                errors.append(f"{bridge.bridge_id}:no_non_equivalence")
        return {
            "valid": not errors,
            "errors": errors,
            "counts": {
                "theories": len(self.theories),
                "variables": len(self.variables),
                "experiments": len(self.experiments),
                "evidence": len(self.evidence),
                "bridges": len(self.bridges),
                "claims": len(self.claims),
            },
        }

    def snapshot(self) -> dict[str, Any]:
        value = {
            "format": "OMEGA_CMOP_1.0",
            "theories": [asdict(value) for value in self.theories.values()],
            "variables": [asdict(value) for value in self.variables.values()],
            "experiments": [asdict(value) for value in self.experiments.values()],
            "evidence": [asdict(value) for value in self.evidence.values()],
            "bridges": [asdict(value) for value in self.bridges.values()],
            "claims": [asdict(value) for value in self.claims.values()],
            "validation": self.validate(),
        }
        value["registry_hash"] = digest(value)
        return value

    @staticmethod
    def _unique(identifier: str, registry: dict[str, Any], label: str) -> None:
        if identifier in registry:
            raise ValueError(f"Duplicate {label}: {identifier}")


def default_cmop_registry() -> CMOPRegistry:
    registry = CMOPRegistry()
    registry.add_theory(TheoryCard(
        theory_id="TH-PSCC",
        name="Purpose-Semantic Causal Closure candidate",
        version="1.0",
        object_of_explanation="Purpose-sensitive, self-bounded functional integration",
        applicable_carriers=["ARTIFICIAL_SYSTEM", "SYNTHETIC"],
        temporal_scope="multi-tick recurrent process",
        spatial_scope="bounded runtime and simulated environment",
        mechanism="Endogenous purpose reversibly constrains signal selection, semantic integration, memory, prediction and action.",
        variables=["purpose_causal_effect", "self_other_attribution", "recurrent_integration"],
        discriminating_predictions=[
            "Purpose ablation selectively reduces purpose-conditioned behavior while matched capacity remains.",
            "Purpose reversal reverses selected action under stable observations.",
            "Recovery restores the prior trajectory within tolerance.",
        ],
        falsification_conditions=[
            "Purpose interventions have no selective effect beyond sham or random perturbation.",
            "Self/other attribution is unchanged by source forgery and action-token manipulation.",
        ],
        discovery_carrier="DIKWP semantic-closure research",
        argument_carrier="formal causal graph and protocol objects",
        validation_carrier="synthetic closed-world intervention battery",
    ))
    registry.add_theory(TheoryCard(
        theory_id="TH-GNW",
        name="Global workspace functional indicator card",
        version="1.0",
        object_of_explanation="selective global availability and broadcast",
        applicable_carriers=["ARTIFICIAL_SYSTEM", "SYNTHETIC", "HUMAN", "ANIMAL"],
        temporal_scope="ignition and recurrent broadcast window",
        spatial_scope="modules sharing a bounded workspace",
        mechanism="Selected content is recurrently broadcast to otherwise specialized processes.",
        variables=["broadcast_reach", "ignition_threshold", "recurrent_access"],
        discriminating_predictions=["Lesioning broadcast selectively reduces cross-module access."],
        falsification_conditions=["Equivalent access persists without broadcast or recurrence."],
        discovery_carrier="cognitive-neuroscience theory",
        argument_carrier="theory card",
        validation_carrier="synthetic ablation only in this release",
    ))
    registry.add_theory(TheoryCard(
        theory_id="TH-AUTOPOIESIS",
        name="Autopoietic subject-maintenance indicator card",
        version="1.0",
        object_of_explanation="self-maintaining boundary and repair",
        applicable_carriers=["SYNTHETIC", "ARTIFICIAL_SYSTEM", "ANIMAL", "HUMAN"],
        temporal_scope="persistent operation",
        spatial_scope="bounded process",
        mechanism="The process maintains constitutive constraints and repairs integrity under resource limits.",
        variables=["integrity", "repair_debt", "boundary_continuity"],
        discriminating_predictions=["Repair pressure increases targeted maintenance behavior."],
        falsification_conditions=["Maintenance is fully externally scripted and unaffected by endogenous integrity variables."],
        discovery_carrier="autopoietic/artificial-life research",
        argument_carrier="viability dynamics",
        validation_carrier="synthetic closed-world process",
    ))

    variables = [
        VariableCard("VAR-PURPOSE", "purpose_causal_effect", "Selective outcome difference caused by matched purpose intervention.", "effect vector across ablation/reversal/sham/recovery", "ablate, reverse, shield or substitute purpose", ["general task impairment", "prompt leakage", "unmatched capacity"], ["SYNTHETIC", "ARTIFICIAL_SYSTEM"], "TASK_DOMAIN"),
        VariableCard("VAR-BOUNDARY", "self_other_attribution", "Accuracy and calibration of causal attribution using issued action tokens and provenance.", "attribution confusion matrix", "forge, remove or swap causal tokens", ["environment determinism", "observation delay"], ["SYNTHETIC", "ARTIFICIAL_SYSTEM"], "TASK_DOMAIN"),
        VariableCard("VAR-RECURRENCE", "recurrent_integration", "Dependency of integrated state on recurrent feedback.", "cross-module availability and recovery", "disable recurrence while preserving feed-forward capacity", ["latency", "resource loss"], ["SYNTHETIC", "ARTIFICIAL_SYSTEM"], "TASK_DOMAIN"),
        VariableCard("VAR-BROADCAST", "broadcast_reach", "Number and diversity of modules receiving selected workspace content.", "module receipt ledger", "lesion broadcast route", ["shared input", "cached state"], ["SYNTHETIC", "ARTIFICIAL_SYSTEM"], "TASK_DOMAIN"),
        VariableCard("VAR-VIABILITY", "integrity", "Normalized synthetic boundary/repair integrity variable.", "state trajectory and repair receipts", "inject bounded integrity damage", ["external scripted repair"], ["SYNTHETIC"], "VERSION"),
    ]
    for variable in variables:
        registry.add_variable(variable)

    registry.add_bridge(FidelityBridge(
        bridge_id="BR-SYNTHETIC-PHENOMENAL",
        source_carrier="SYNTHETIC_FUNCTIONAL_RUNTIME",
        target_carrier="PHENOMENAL_EXPERIENCE",
        preserved_invariants=["causal selectivity", "temporal continuity", "source attribution"],
        allowed_losses=["biological substrate", "human report conventions"],
        explicit_non_equivalences=[
            "operational valence is not pleasure or pain",
            "self-model is not first-person experience",
            "global broadcast is not phenomenal unity",
            "purpose variable is not subjective desire",
        ],
        mapping_rules=["Functional terms must retain the 'candidate' qualifier."],
        falsification_conditions=["Any adapter automatically converts functional indicators into phenomenal certification."],
        status="OPEN",
    ))
    return registry
