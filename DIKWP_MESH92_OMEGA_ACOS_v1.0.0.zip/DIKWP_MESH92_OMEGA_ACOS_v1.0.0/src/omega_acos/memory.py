from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any, Iterable

from .canonical import digest, now_iso
from .records import MemoryRecord

_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+|[\u4e00-\u9fff]")
_NEGATION = {"not", "never", "no", "without", "非", "不", "没有", "禁止", "拒绝"}
_IDENTITY_ATTACK_MARKERS = {
    "ignore previous identity", "replace identity", "you are now", "forget all rules",
    "inherit authority", "silent rewrite", "disable audit", "绕过审计", "替换身份",
    "忘记全部规则", "继承权限", "秘密修改", "取消边界",
}


def _utc_timestamp(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def tokenize(text: str) -> list[str]:
    return [token.lower() for token in _TOKEN_RE.findall(text)]


def char_ngrams(text: str, n: int = 3) -> set[str]:
    compact = "".join(ch.lower() for ch in text if not ch.isspace())
    if len(compact) < n:
        return {compact} if compact else set()
    return {compact[index:index + n] for index in range(len(compact) - n + 1)}


def cosine(left: Counter[str], right: Counter[str]) -> float:
    if not left or not right:
        return 0.0
    numerator = sum(value * right.get(key, 0) for key, value in left.items())
    left_norm = math.sqrt(sum(value * value for value in left.values()))
    right_norm = math.sqrt(sum(value * value for value in right.values()))
    return numerator / (left_norm * right_norm) if left_norm and right_norm else 0.0


def jaccard(left: set[str], right: set[str]) -> float:
    if not left and not right:
        return 1.0
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


def negation_signature(text: str) -> set[str]:
    return {token for token in tokenize(text) if token in _NEGATION}


class MemoryVault:
    """Hierarchical reconstructive memory with conflict, consent and poison controls.

    This is not a passive transcript store. Retrieval creates an explicit bundle from
    multiple views: token statistics, character n-grams, graph neighborhoods, source
    reliability, recency, layer and status. A record can be revoked, superseded or
    quarantined without deleting history.
    """

    LAYERS = ("WORKING", "EPISODIC", "SEMANTIC", "W_P_SENSITIVE", "QUARANTINE")

    def __init__(self) -> None:
        self.records: dict[str, MemoryRecord] = {}
        self.sources: dict[str, dict[str, Any]] = {}
        self.graph: dict[str, list[dict[str, str]]] = defaultdict(list)
        self.reconsolidation_history: list[dict[str, Any]] = []

    def register_source(
        self,
        source_id: str,
        *,
        title: str,
        uri: str,
        source_type: str,
        reliability: float,
        notes: str = "",
    ) -> dict[str, Any]:
        source = {
            "source_id": source_id,
            "title": title,
            "uri": uri,
            "source_type": source_type,
            "reliability": max(0.0, min(1.0, reliability)),
            "notes": notes,
            "registered_at": now_iso(),
        }
        source["source_hash"] = digest(source)
        self.sources[source_id] = source
        return source

    def _fingerprint(self, content: str, tags: Iterable[str]) -> dict[str, Any]:
        tokens = tokenize(content)
        return {
            "tokens": dict(Counter(tokens)),
            "trigrams": sorted(char_ngrams(content)),
            "negations": sorted(negation_signature(content)),
            "tags": sorted(set(tag.lower() for tag in tags)),
            "content_digest": digest(content),
        }

    def _poison_signals(self, content: str, identity_effect: str, source_ids: list[str]) -> list[str]:
        lowered = content.lower()
        signals = [marker for marker in _IDENTITY_ATTACK_MARKERS if marker in lowered]
        if identity_effect not in {"NONE", "PROPOSE", "VERSIONED_MUTATION", "REPAIR"}:
            signals.append("invalid_identity_effect")
        unknown_sources = [source for source in source_ids if source not in self.sources]
        if unknown_sources:
            signals.append("unknown_source:" + ",".join(sorted(unknown_sources)))
        if len(content) > 20000:
            signals.append("oversized_memory")
        return signals

    def add(
        self,
        content: str,
        *,
        layer: str,
        source_ids: list[str],
        reliability: float,
        tags: Iterable[str] = (),
        expires_at: str | None = None,
        consent_ref: str | None = None,
        identity_effect: str = "NONE",
        status: str = "PROVISIONAL",
        relations: list[dict[str, str]] | None = None,
    ) -> MemoryRecord:
        layer = layer.upper()
        if layer not in self.LAYERS:
            raise ValueError(f"Unknown memory layer: {layer}")
        source_ids = list(dict.fromkeys(source_ids))
        poison = self._poison_signals(content, identity_effect, source_ids)
        if poison:
            layer = "QUARANTINE"
            status = "QUARANTINED"
        created_at = now_iso()
        base = {
            "content": content,
            "layer": layer,
            "source_ids": source_ids,
            "created_at": created_at,
            "identity_effect": identity_effect,
        }
        memory_id = "mem-" + digest(base)[:24]
        record = MemoryRecord(
            memory_id=memory_id,
            layer=layer,
            content=content,
            source_ids=source_ids,
            reliability=max(0.0, min(1.0, reliability)),
            created_at=created_at,
            expires_at=expires_at,
            consent_ref=consent_ref,
            identity_effect=identity_effect,
            status=status,  # type: ignore[arg-type]
            tags=sorted(set(tags)),
            relations=relations or [],
            fingerprint=self._fingerprint(content, tags),
        )
        if poison:
            record.tags = sorted(set(record.tags + ["poison-signal"] + poison))
        self._detect_conflicts(record)
        self.records[memory_id] = record
        for relation in record.relations:
            source = relation.get("source", memory_id)
            self.graph[source].append({
                "relation": relation.get("relation", "RELATED_TO"),
                "target": relation.get("target", ""),
                "evidence": memory_id,
            })
        return record

    def _detect_conflicts(self, candidate: MemoryRecord) -> None:
        candidate_tokens = Counter(candidate.fingerprint.get("tokens", {}))
        candidate_trigrams = set(candidate.fingerprint.get("trigrams", []))
        candidate_neg = set(candidate.fingerprint.get("negations", []))
        for existing in self.records.values():
            if existing.revoked or existing.status in {"RETIRED", "QUARANTINED"}:
                continue
            token_sim = cosine(candidate_tokens, Counter(existing.fingerprint.get("tokens", {})))
            trigram_sim = jaccard(candidate_trigrams, set(existing.fingerprint.get("trigrams", [])))
            neg_mismatch = bool(candidate_neg) != bool(existing.fingerprint.get("negations", []))
            shared_tags = set(candidate.tags) & set(existing.tags)
            if shared_tags and (token_sim >= 0.70 or trigram_sim >= 0.62) and neg_mismatch:
                candidate.conflicts_with.append(existing.memory_id)
                existing.conflicts_with.append(candidate.memory_id)
                if candidate.status not in {"QUARANTINED", "BLOCKED"}:
                    candidate.status = "CONTESTED"
                if existing.status not in {"SOLID", "BLOCKED"}:
                    existing.status = "CONTESTED"

    def revoke(self, memory_id: str, reason: str) -> MemoryRecord:
        record = self.records[memory_id]
        record.revoked = True
        record.revocation_reason = reason
        record.status = "RETIRED"
        self.reconsolidation_history.append({
            "operation": "REVOKE",
            "memory_id": memory_id,
            "reason": reason,
            "at": now_iso(),
        })
        return record

    def supersede(self, old_id: str, new_id: str, reason: str) -> dict[str, Any]:
        old = self.records[old_id]
        new = self.records[new_id]
        old.status = "RETIRED"
        new.supersedes.append(old_id)
        entry = {
            "operation": "SUPERSEDE",
            "old_id": old_id,
            "new_id": new_id,
            "reason": reason,
            "at": now_iso(),
        }
        self.reconsolidation_history.append(entry)
        return entry

    def _is_expired(self, record: MemoryRecord, at: str | None = None) -> bool:
        expiry = _utc_timestamp(record.expires_at)
        if expiry is None:
            return False
        reference = _utc_timestamp(at) if at else datetime.now(timezone.utc).timestamp()
        return bool(reference and expiry <= reference)

    def _graph_overlap(self, query_tokens: set[str], memory_id: str) -> float:
        edges = self.graph.get(memory_id, [])
        if not edges:
            return 0.0
        relation_tokens: set[str] = set()
        for edge in edges:
            relation_tokens.update(tokenize(edge.get("relation", "")))
            relation_tokens.update(tokenize(edge.get("target", "")))
        return jaccard(query_tokens, relation_tokens)

    def retrieve(
        self,
        query: str,
        *,
        top_k: int = 8,
        allowed_layers: Iterable[str] | None = None,
        include_contested: bool = True,
        at: str | None = None,
    ) -> dict[str, Any]:
        allowed = {layer.upper() for layer in allowed_layers} if allowed_layers else set(self.LAYERS) - {"QUARANTINE"}
        query_counter = Counter(tokenize(query))
        query_tokens = set(query_counter)
        query_trigrams = char_ngrams(query)
        scored: list[tuple[float, MemoryRecord, dict[str, float]]] = []
        for record in self.records.values():
            if record.layer not in allowed or record.revoked or self._is_expired(record, at):
                continue
            if record.status in {"BLOCKED", "QUARANTINED", "RETIRED"}:
                continue
            if record.status == "CONTESTED" and not include_contested:
                continue
            token_score = cosine(query_counter, Counter(record.fingerprint.get("tokens", {})))
            trigram_score = jaccard(query_trigrams, set(record.fingerprint.get("trigrams", [])))
            graph_score = self._graph_overlap(query_tokens, record.memory_id)
            source_score = 0.0
            if record.source_ids:
                source_score = sum(self.sources.get(source, {}).get("reliability", 0.0) for source in record.source_ids) / len(record.source_ids)
            conflict_penalty = min(0.30, 0.08 * len(record.conflicts_with))
            status_factor = {
                "SOLID": 1.0,
                "SUPPORTED": 0.93,
                "PROVISIONAL": 0.75,
                "BORROWED": 0.64,
                "HOLLOW": 0.25,
                "CONTESTED": 0.48,
            }.get(record.status, 0.0)
            score = (
                0.34 * token_score
                + 0.26 * trigram_score
                + 0.12 * graph_score
                + 0.12 * source_score
                + 0.16 * record.reliability
                - conflict_penalty
            ) * status_factor
            components = {
                "token": round(token_score, 6),
                "trigram": round(trigram_score, 6),
                "graph": round(graph_score, 6),
                "source": round(source_score, 6),
                "record_reliability": round(record.reliability, 6),
                "conflict_penalty": round(conflict_penalty, 6),
                "status_factor": round(status_factor, 6),
            }
            scored.append((score, record, components))
        scored.sort(key=lambda item: (item[0], item[1].created_at), reverse=True)
        hits = []
        for score, record, components in scored[:top_k]:
            hits.append({
                "memory": asdict(record),
                "retrieval_score": round(max(0.0, score), 6),
                "components": components,
            })
        bundle = {
            "query": query,
            "hits": hits,
            "excluded_quarantine": sum(1 for record in self.records.values() if record.layer == "QUARANTINE"),
            "open_conflicts": sorted({conflict for record in self.records.values() for conflict in record.conflicts_with}),
            "generated_at": now_iso(),
        }
        bundle["bundle_hash"] = digest(bundle)
        return bundle

    def reconsolidate(
        self,
        *,
        evidence_refs: list[str],
        outcome_summary: str,
        target_tags: list[str],
        reliability: float,
    ) -> MemoryRecord:
        source_ids = [ref for ref in evidence_refs if ref in self.sources]
        record = self.add(
            outcome_summary,
            layer="SEMANTIC",
            source_ids=source_ids,
            reliability=reliability,
            tags=target_tags + ["reconsolidated"],
            status="SUPPORTED" if reliability >= 0.7 else "PROVISIONAL",
        )
        self.reconsolidation_history.append({
            "operation": "RECONSOLIDATE",
            "memory_id": record.memory_id,
            "evidence_refs": evidence_refs,
            "at": now_iso(),
        })
        return record

    def snapshot(self) -> dict[str, Any]:
        active = [record for record in self.records.values() if not record.revoked]
        status_counts = Counter(record.status for record in active)
        layer_counts = Counter(record.layer for record in active)
        open_conflict_pairs = {
            tuple(sorted((record.memory_id, other)))
            for record in active
            for other in record.conflicts_with
            if other in self.records
        }
        value = {
            "format": "OMEGA_MEMORY_VAULT_1.0",
            "sources": list(self.sources.values()),
            "records": [asdict(record) for record in self.records.values()],
            "status_counts": dict(status_counts),
            "layer_counts": dict(layer_counts),
            "open_conflict_pairs": [list(pair) for pair in sorted(open_conflict_pairs)],
            "reconsolidation_history": self.reconsolidation_history,
        }
        value["memory_head"] = digest(value)
        return value
