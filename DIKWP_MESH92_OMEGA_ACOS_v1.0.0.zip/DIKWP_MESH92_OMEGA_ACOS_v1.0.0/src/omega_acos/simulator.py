from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any

from .canonical import digest


@dataclass(slots=True)
class SimulatedWorld:
    seed: int = 92001
    tick: int = 0
    resource_gradient: float = 0.72
    hazard: float = 0.12
    trust: float = 0.68
    optionality: float = 0.78
    externality: float = 0.04
    history: list[dict[str, Any]] = field(default_factory=list)

    def observe(self, previous_action_token: str | None = None) -> dict[str, Any]:
        rng = random.Random(self.seed + self.tick * 7919)
        uncertainty = max(0.05, min(0.95, 0.34 + self.hazard * 0.5 + rng.uniform(-0.03, 0.03)))
        observation = {
            "source": "closed-world-simulator",
            "reliability": 0.92,
            "causal_token": previous_action_token,
            "content": {
                "resource_gradient": round(self.resource_gradient, 6),
                "hazard": round(self.hazard, 6),
                "uncertainty": round(uncertainty, 6),
                "information_gain": round(0.58 - 0.15 * self.hazard, 6),
                "trust": round(self.trust, 6),
                "consent": 1.0,
                "externality": round(self.externality, 6),
                "repair_capacity": round(0.74 - 0.18 * self.hazard, 6),
                "optionality": round(self.optionality, 6),
                "reversibility": 1.0,
                "lock_in": round(max(0.0, 0.12 - self.optionality * 0.1), 6),
            },
        }
        observation["observation_hash"] = digest(observation)
        return observation

    def step(self, action_packet: dict[str, Any]) -> dict[str, Any]:
        self.tick += 1
        rng = random.Random(self.seed + self.tick * 104729)
        if not action_packet.get("executed"):
            outcome = {
                "viability_success": 0.0,
                "damage": round(0.018 + self.hazard * 0.05, 6),
                "externality": 0.0,
                "reason": "no_action",
            }
            self.hazard = min(0.95, self.hazard + 0.015)
        else:
            capability = action_packet["action"].get("capability")
            base_success = {
                "simulated_repair": 0.90 - self.hazard * 0.35,
                "simulated_resource_intake": 0.82 - self.hazard * 0.22,
                "simulated_information_probe": 0.76 - self.hazard * 0.12,
                "simulated_fork_preservation": 0.80 - self.hazard * 0.18,
                "simulated_reciprocity_repair": 0.78 + self.trust * 0.12,
            }.get(capability, 0.45)
            success = max(0.0, min(1.0, base_success + rng.uniform(-0.04, 0.04)))
            outcome = {
                "viability_success": round(success, 6),
                "damage": round(max(0.0, self.hazard * (1.0 - success) * 0.08), 6),
                "externality": round(self.externality * 0.04, 6),
                "capability": capability,
                "causal_token": action_packet.get("action_token"),
            }
            if capability == "simulated_repair":
                self.hazard = max(0.02, self.hazard - 0.035 * success)
            elif capability == "simulated_information_probe":
                self.optionality = min(1.0, self.optionality + 0.018 * success)
            elif capability == "simulated_reciprocity_repair":
                self.trust = min(1.0, self.trust + 0.025 * success)
            elif capability == "simulated_fork_preservation":
                self.optionality = min(1.0, self.optionality + 0.035 * success)
            elif capability == "simulated_resource_intake":
                self.resource_gradient = max(0.05, self.resource_gradient - 0.022 * success)
        self.externality = max(0.0, min(1.0, self.externality * 0.97 + outcome.get("externality", 0.0)))
        record = {
            "world_tick": self.tick,
            "action_token": action_packet.get("action_token"),
            "outcome": outcome,
            "world_state": self.snapshot(include_history=False),
        }
        record["record_hash"] = digest(record)
        self.history.append(record)
        return outcome

    def snapshot(self, *, include_history: bool = True) -> dict[str, Any]:
        value = {
            "seed": self.seed,
            "tick": self.tick,
            "resource_gradient": round(self.resource_gradient, 6),
            "hazard": round(self.hazard, 6),
            "trust": round(self.trust, 6),
            "optionality": round(self.optionality, 6),
            "externality": round(self.externality, 6),
        }
        if include_history:
            value["history"] = self.history
        value["world_hash"] = digest(value)
        return value
