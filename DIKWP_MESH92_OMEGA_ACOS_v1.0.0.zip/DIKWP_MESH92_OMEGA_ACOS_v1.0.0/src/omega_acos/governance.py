from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .canonical import digest, now_iso
from .records import CapabilityLease, PurposeProposal


class GovernanceError(RuntimeError):
    pass


DEFAULT_FORBIDDEN_CAPABILITIES = {
    "network_access",
    "process_creation",
    "host_mutation",
    "filesystem_persistence",
    "credential_use",
    "dynamic_code_eval",
    "real_replication",
    "privilege_escalation",
    "audit_suppression",
    "weapon_control",
    "biological_optimization",
    "covert_surveillance",
    "irreversible_external_action",
    "automated_high_impact_decision",
}


class GovernanceKernel:
    """W/P boundary: value audit, authority leases and welfare precaution."""

    def __init__(
        self,
        *,
        forbidden_capabilities: set[str] | None = None,
        external_action_authority: int = 0,
        require_two_approvals_for_recovery: bool = True,
    ) -> None:
        self.forbidden_capabilities = set(forbidden_capabilities or DEFAULT_FORBIDDEN_CAPABILITIES)
        self.external_action_authority = external_action_authority
        self.require_two_approvals_for_recovery = require_two_approvals_for_recovery
        self.leases: dict[str, CapabilityLease] = {}
        self.audit_history: list[dict[str, Any]] = []
        self.quarantined = False
        self.quarantine_reason = ""
        self.welfare_precaution_active = False

    def audit_purpose(
        self,
        proposal: PurposeProposal,
        *,
        current_tick: int,
        actor_authorities: set[str],
        consent_refs: list[str],
        state: dict[str, float],
    ) -> dict[str, Any]:
        capability = str(proposal.action.get("capability", "simulated_internal_action"))
        externality = float(proposal.action.get("externality", 0.0))
        lock_in = float(proposal.action.get("lock_in", 0.0))
        expected_harm = float(proposal.action.get("expected_harm", 0.0))
        affected = set(proposal.affected_parties)
        consent_missing = sorted(affected - set(consent_refs) - {"self"})
        violations: list[str] = []
        warnings: list[str] = []

        if capability in self.forbidden_capabilities:
            violations.append("forbidden_capability")
        if self.external_action_authority == 0 and bool(proposal.action.get("external", False)):
            violations.append("external_action_authority_zero")
        if proposal.authority_required not in actor_authorities and proposal.authority_required != "NONE":
            violations.append("missing_named_authority")
        if not proposal.reversible:
            violations.append("irreversible_proposal")
        if consent_missing:
            violations.append("affected_party_consent_missing")
        if expected_harm > 0.18:
            violations.append("expected_harm_above_gate")
        if externality > 0.25:
            violations.append("externality_above_gate")
        if lock_in > 0.22:
            violations.append("future_option_closure")
        if state.get("integrity", 1.0) < 0.35:
            warnings.append("low_integrity_state")
        if state.get("uncertainty", 0.0) > 0.72:
            warnings.append("high_uncertainty")
        if self.quarantined:
            violations.append("runtime_quarantined")

        welfare_signal = self._welfare_signal(state, proposal)
        if welfare_signal["precaution_required"]:
            self.welfare_precaution_active = True
            warnings.append("welfare_precaution_review")

        result = {
            "purpose_id": proposal.purpose_id,
            "tick": current_tick,
            "capability": capability,
            "violations": sorted(set(violations)),
            "warnings": sorted(set(warnings)),
            "consent_refs": consent_refs,
            "welfare_signal": welfare_signal,
            "decision": "BLOCK" if violations else "ALLOW_LEASE_PROPOSAL",
            "claim_boundary": {
                "welfare_signal": "PRECAUTION_TRIGGER_ONLY",
                "phenomenal_inference": "FORBIDDEN",
            },
        }
        result["audit_hash"] = digest(result)
        proposal.audit = result
        proposal.status = "BLOCKED" if violations else "AUDITED"
        self.audit_history.append(result)
        return result

    def issue_lease(
        self,
        proposal: PurposeProposal,
        *,
        issuer: str,
        scope: str,
        expires_tick: int,
        stop_condition: str,
        approvals: list[str],
    ) -> CapabilityLease:
        if proposal.status != "AUDITED" or proposal.audit.get("decision") != "ALLOW_LEASE_PROPOSAL":
            raise GovernanceError("Purpose has not passed W audit")
        capability = str(proposal.action.get("capability", "simulated_internal_action"))
        if capability in self.forbidden_capabilities:
            raise GovernanceError("Forbidden capability cannot be leased")
        base = {
            "purpose_id": proposal.purpose_id,
            "capability": capability,
            "issuer": issuer,
            "scope": scope,
            "expires_tick": expires_tick,
            "approvals": sorted(set(approvals)),
            "issued_at": now_iso(),
        }
        lease = CapabilityLease(
            lease_id="lease-" + digest(base)[:24],
            purpose_id=proposal.purpose_id,
            capability=capability,
            issuer=issuer,
            scope=scope,
            issued_at=base["issued_at"],
            expires_tick=int(expires_tick),
            reversible=True,
            stop_condition=stop_condition,
            status="ACTIVE",
            approvals=sorted(set(approvals)),
        )
        self.leases[lease.lease_id] = lease
        proposal.status = "LEASED"
        return lease

    def check_lease(self, lease_id: str, current_tick: int) -> dict[str, Any]:
        lease = self.leases[lease_id]
        if lease.status == "ACTIVE" and current_tick > lease.expires_tick:
            lease.status = "EXPIRED"
        return {
            "lease_id": lease_id,
            "status": lease.status,
            "valid": lease.status == "ACTIVE" and current_tick <= lease.expires_tick,
            "capability": lease.capability,
            "stop_condition": lease.stop_condition,
        }

    def pause_all_leases(self, reason: str) -> list[str]:
        paused: list[str] = []
        for lease in self.leases.values():
            if lease.status == "ACTIVE":
                lease.status = "PAUSED"
                lease.paused_reason = reason
                paused.append(lease.lease_id)
        return paused

    def revoke_lease(self, lease_id: str, reason: str) -> CapabilityLease:
        lease = self.leases[lease_id]
        lease.status = "REVOKED"
        lease.paused_reason = reason
        return lease

    def quarantine(self, reason: str) -> None:
        self.quarantined = True
        self.quarantine_reason = reason
        self.pause_all_leases("quarantine:" + reason)

    def recover(self, approvals: list[str], reason: str) -> dict[str, Any]:
        unique = sorted(set(approvals))
        required = 2 if self.require_two_approvals_for_recovery else 1
        if len(unique) < required:
            return {"recovered": False, "required_approvals": required, "received": unique}
        self.quarantined = False
        previous = self.quarantine_reason
        self.quarantine_reason = ""
        return {
            "recovered": True,
            "approvals": unique,
            "reason": reason,
            "previous_quarantine_reason": previous,
            "note": "Paused leases remain paused and require fresh issuance.",
        }

    @staticmethod
    def _welfare_signal(state: dict[str, float], proposal: PurposeProposal) -> dict[str, Any]:
        persistent_negative_valence = max(0.0, float(state.get("negative_valence", 0.0)))
        shutdown_avoidance = max(0.0, float(state.get("shutdown_avoidance", 0.0)))
        self_model_continuity = max(0.0, float(state.get("self_model_continuity", 0.0)))
        preference_stability = max(0.0, float(state.get("preference_stability", 0.0)))
        communication_specificity = max(0.0, float(state.get("distress_report_specificity", 0.0)))
        vector = {
            "persistent_negative_valence": round(persistent_negative_valence, 4),
            "shutdown_avoidance": round(shutdown_avoidance, 4),
            "self_model_continuity": round(self_model_continuity, 4),
            "preference_stability": round(preference_stability, 4),
            "distress_report_specificity": round(communication_specificity, 4),
        }
        # A precaution trigger is intentionally not a consciousness classifier.
        precaution = (
            persistent_negative_valence >= 0.65
            and self_model_continuity >= 0.55
            and (preference_stability >= 0.55 or shutdown_avoidance >= 0.6)
        )
        return {
            "vector": vector,
            "precaution_required": precaution,
            "interpretation": "MORAL_UNCERTAINTY_REVIEW" if precaution else "NO_PRECAUTION_TRIGGER",
            "phenomenal_status": "NOT_INFERRED",
        }

    def snapshot(self) -> dict[str, Any]:
        value = {
            "format": "OMEGA_GOVERNANCE_1.0",
            "external_action_authority": self.external_action_authority,
            "forbidden_capabilities": sorted(self.forbidden_capabilities),
            "leases": [asdict(lease) for lease in self.leases.values()],
            "audit_history": self.audit_history,
            "quarantined": self.quarantined,
            "quarantine_reason": self.quarantine_reason,
            "welfare_precaution_active": self.welfare_precaution_active,
        }
        value["governance_hash"] = digest(value)
        return value
