from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

from .canonical import canonical_json, digest, now_iso

ZERO_HASH = "0" * 64


class LedgerIntegrityError(RuntimeError):
    pass


class EventLedger:
    """Append-only, hash-chained event ledger.

    The ledger is deliberately simple: one canonical JSON object per line. A valid
    event binds sequence, type, payload, actor, identity version, timestamp and the
    prior event hash. The ledger never edits an earlier event; corrections are new
    events that reference the target.
    """

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else None
        self.events: list[dict[str, Any]] = []
        if self.path and self.path.exists():
            self.events = self._read_path(self.path)
            report = self.verify()
            if not report["valid"]:
                raise LedgerIntegrityError(f"Invalid ledger: {report}")

    @staticmethod
    def _read_path(path: Path) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if not raw.strip():
                continue
            try:
                events.append(json.loads(raw))
            except json.JSONDecodeError as exc:
                raise LedgerIntegrityError(f"Invalid JSON at line {line_number}: {exc}") from exc
        return events

    @property
    def head(self) -> str:
        return self.events[-1]["event_hash"] if self.events else ZERO_HASH

    def append(
        self,
        event_type: str,
        payload: dict[str, Any],
        *,
        actor: str,
        identity_version: int,
        timestamp: str | None = None,
        tags: Iterable[str] = (),
    ) -> dict[str, Any]:
        base = {
            "sequence": len(self.events) + 1,
            "event_type": event_type,
            "timestamp": timestamp or now_iso(),
            "actor": actor,
            "identity_version": int(identity_version),
            "payload": payload,
            "tags": sorted(set(tags)),
            "prev_hash": self.head,
        }
        event = {**base, "event_hash": digest(base)}
        self.events.append(event)
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(canonical_json(event) + "\n")
        return event

    def correction(
        self,
        target_hash: str,
        reason: str,
        corrected_payload: dict[str, Any],
        *,
        actor: str,
        identity_version: int,
    ) -> dict[str, Any]:
        return self.append(
            "CORRECTION",
            {
                "target_hash": target_hash,
                "reason": reason,
                "corrected_payload": corrected_payload,
            },
            actor=actor,
            identity_version=identity_version,
            tags=("correction",),
        )

    def verify(self) -> dict[str, Any]:
        previous = ZERO_HASH
        for index, event in enumerate(self.events, start=1):
            base = {key: value for key, value in event.items() if key != "event_hash"}
            expected = digest(base)
            if event.get("sequence") != index:
                return {"valid": False, "checked": index - 1, "reason": "sequence", "event": index}
            if event.get("prev_hash") != previous:
                return {"valid": False, "checked": index - 1, "reason": "previous_hash", "event": index}
            if event.get("event_hash") != expected:
                return {"valid": False, "checked": index - 1, "reason": "event_hash", "event": index}
            previous = expected
        return {"valid": True, "events": len(self.events), "head": previous}

    def select(self, event_type: str | None = None, tag: str | None = None) -> list[dict[str, Any]]:
        selected = self.events
        if event_type:
            selected = [event for event in selected if event["event_type"] == event_type]
        if tag:
            selected = [event for event in selected if tag in event.get("tags", [])]
        return list(selected)

    def export(self) -> dict[str, Any]:
        report = self.verify()
        return {
            "format": "OMEGA_EVENT_LEDGER_1.0",
            "verification": report,
            "events": self.events,
            "ledger_digest": digest({"head": self.head, "events": len(self.events)}),
        }
