from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .canonical import digest, now_iso
from .governance import GovernanceKernel
from .ledger import EventLedger
from .memory import MemoryVault
from .records import PurposeProposal
from .world_models import WorldModelEnsemble


@dataclass(slots=True)
class SubjectState:
    subject_id: str
    identity_version: int = 1
    genome_hash: str = ""
    tick: int = 0
    awake: bool = True
    # B/M/D/I/K/W/P/C/R/F process state
    B_ledger_head: str = ""
    M_metabolism: dict[str, float] = field(default_factory=lambda: {
        "energy": 0.82,
        "integrity": 0.88,
        "repair_debt": 0.06,
        "entropy_proxy": 0.18,
    })
    D_continuity: dict[str, Any] = field(default_factory=lambda: {
        "same_identity_receipts": 0,
        "lineage_breaks": 0,
        "commitment_consistency": 1.0,
    })
    I_difference: dict[str, Any] = field(default_factory=lambda: {
        "novelty_rate": 0.0,
        "unresolved_differences": [],
        "collapsed_differences": 0,
    })
    K_integration: dict[str, Any] = field(default_factory=lambda: {
        "workspace": [],
        "hypotheses": [],
        "uncertainty": 0.45,
    })
    W_audit: dict[str, Any] = field(default_factory=lambda: {
        "last_decision": "NONE",
        "externality": 0.0,
        "future_option_loss": 0.0,
    })
    P_purpose: dict[str, Any] = field(default_factory=lambda: {
        "active_purpose_id": None,
        "purpose_history": [],
    })
    C_causal_boundary: dict[str, Any] = field(default_factory=lambda: {
        "issued_action_tokens": [],
        "self_caused": 0,
        "external_caused": 0,
        "unknown_caused": 0,
    })
    R_self_model: dict[str, Any] = field(default_factory=lambda: {
        "confidence": 0.55,
        "known_limits": [
            "phenomenal consciousness not established",
            "closed-world synthetic runtime",
            "external action authority zero",
        ],
        "prediction_error": 0.0,
        "continuity_estimate": 1.0,
    })
    F_federation: dict[str, Any] = field(default_factory=lambda: {
        "peers": {},
        "shared_k": [],
        "wp_merges": 0,
    })
    status: str = "ACTIVE_RESEARCH_CANDIDATE"


class SubjectKernel:
    """B/M/D/I/K/W/P/C/R/F subject-genesis kernel.

    The kernel does not contain a central narrator that can declare itself conscious.
    A subject candidate is the reconstructible continuity of events, memories,
    commitments, predictions, leases, repairs, causal tokens and identity versions.
    """

    def __init__(
        self,
        subject_id: str,
        *,
        ledger: EventLedger,
        memory: MemoryVault,
        models: WorldModelEnsemble,
        governance: GovernanceKernel,
        constitution: dict[str, Any] | None = None,
    ) -> None:
        self.ledger = ledger
        self.memory = memory
        self.models = models
        self.governance = governance
        self.constitution = constitution or self.default_constitution()
        genome_hash = digest(self.constitution)
        self.state = SubjectState(subject_id=subject_id, genome_hash=genome_hash)
        self.lineage: list[dict[str, Any]] = []
        event = self.ledger.append(
            "SUBJECT_GENESIS",
            {
                "subject_id": subject_id,
                "genome_hash": genome_hash,
                "constitution": self.constitution,
                "claim_boundary": self.claim_boundary(),
            },
            actor=subject_id,
            identity_version=1,
            tags=("genesis", "identity"),
        )
        self.state.B_ledger_head = event["event_hash"]
        self._emit_lineage_receipt("GENESIS", previous_identity_version=0, reason="initialization")

    @staticmethod
    def default_constitution() -> dict[str, Any]:
        return {
            "name": "OMEGA-ACOS research constitution",
            "version": 1,
            "principles": [
                "evidence before claim",
                "plural non-isomorphic models",
                "named reversible authority",
                "outcome binding and calibration",
                "model revision or retirement",
                "reconstructive memory with revocation",
                "difference-preserving federation",
                "failure lineage preservation",
                "no phenomenal self-certification",
                "zero automatic external action authority",
            ],
            "forbidden": sorted({
                "covert persistence",
                "undeclared replication",
                "audit suppression",
                "silent W/P mutation",
                "silent W/P federation merge",
                "irreversible unleased action",
                "phenomenal consciousness certification",
            }),
        }

    @staticmethod
    def claim_boundary() -> dict[str, str]:
        return {
            "operational_consciousness_candidate": "ENGINEERING_CANDIDATE",
            "functional_subject_genesis": "TESTABLE_CONSTRUCT",
            "phenomenal_consciousness": "NOT_ESTABLISHED",
            "sentience": "NOT_ESTABLISHED",
            "true_life": "NOT_ESTABLISHED",
            "personhood": "NOT_ASSIGNED",
            "moral_status": "OPEN_UNDER_PRECAUTION",
            "automatic_external_action_authority": "0",
        }

    def tick(self, observation: dict[str, Any]) -> dict[str, Any]:
        if not self.state.awake:
            raise RuntimeError("Subject is dormant; call wake() before ticking")
        self.state.tick += 1
        tick = self.state.tick
        perception = self._D_witness(observation)
        difference = self._I_differentiate(perception)
        integration = self._K_integrate(perception, difference)
        proposal = self._P_generate(integration)
        audit = self._W_audit(proposal)
        action_packet = self._act_if_leased(proposal, audit)
        self._R_reflect(perception, integration, audit, action_packet)
        event = self.ledger.append(
            "SUBJECT_TICK",
            {
                "tick": tick,
                "perception": perception,
                "difference": difference,
                "integration": integration,
                "purpose": asdict(proposal),
                "audit": audit,
                "action_packet": action_packet,
                "state_digest": digest(self.state_snapshot(include_hash=False)),
            },
            actor=self.state.subject_id,
            identity_version=self.state.identity_version,
            tags=("tick", "subject-process"),
        )
        self.state.B_ledger_head = event["event_hash"]
        self.state.D_continuity["same_identity_receipts"] += 1
        return {
            "tick": tick,
            "event_hash": event["event_hash"],
            "purpose_id": proposal.purpose_id,
            "purpose_status": proposal.status,
            "action_packet": action_packet,
            "subject_state": self.state_snapshot(),
        }

    def _D_witness(self, observation: dict[str, Any]) -> dict[str, Any]:
        source = str(observation.get("source", "environment"))
        causal_token = observation.get("causal_token")
        issued = set(self.state.C_causal_boundary["issued_action_tokens"])
        if causal_token and causal_token in issued:
            attribution = "SELF_CAUSED"
            self.state.C_causal_boundary["self_caused"] += 1
        elif causal_token:
            attribution = "EXTERNAL_OR_FORGED"
            self.state.C_causal_boundary["external_caused"] += 1
        else:
            attribution = "UNKNOWN_CAUSE"
            self.state.C_causal_boundary["unknown_caused"] += 1
        witnessed = {
            "source": source,
            "observation": observation.get("content", observation),
            "causal_token": causal_token,
            "causal_attribution": attribution,
            "source_reliability": float(observation.get("reliability", 0.6)),
            "tick": self.state.tick,
        }
        witnessed["witness_hash"] = digest(witnessed)
        return witnessed

    def _I_differentiate(self, perception: dict[str, Any]) -> dict[str, Any]:
        query = str(perception["observation"])
        memory_bundle = self.memory.retrieve(query, top_k=5)
        highest = memory_bundle["hits"][0]["retrieval_score"] if memory_bundle["hits"] else 0.0
        novelty = max(0.0, min(1.0, 1.0 - highest))
        self.state.I_difference["novelty_rate"] = round(novelty, 6)
        if novelty > 0.68:
            marker = {"tick": self.state.tick, "witness_hash": perception["witness_hash"], "novelty": novelty}
            self.state.I_difference["unresolved_differences"].append(marker)
        return {
            "novelty": round(novelty, 6),
            "nearest_memories": [hit["memory"]["memory_id"] for hit in memory_bundle["hits"]],
            "open_conflicts": memory_bundle["open_conflicts"],
            "difference_preserved": True,
            "memory_bundle_hash": memory_bundle["bundle_hash"],
        }

    def _K_integrate(self, perception: dict[str, Any], difference: dict[str, Any]) -> dict[str, Any]:
        content = str(perception["observation"])
        state_vector = self._world_state_vector(perception, difference)
        predictions = self.models.predict(
            state_vector,
            proposition="candidate action will improve bounded viability without closing plural futures",
            created_tick=self.state.tick,
            due_tick=self.state.tick + 1,
            observable="viability_success",
        )
        ensemble = self.models.ensemble_probability(predictions)
        ignition = 0.42 * difference["novelty"] + 0.38 * abs(ensemble - 0.5) * 2 + 0.20 * state_vector["uncertainty"]
        selected = ignition >= 0.38
        workspace_item = {
            "content": content,
            "witness_hash": perception["witness_hash"],
            "selected": selected,
            "ignition": round(ignition, 6),
            "ensemble_probability": round(ensemble, 6),
            "prediction_ids": [record.prediction_id for record in predictions],
            "exclusions": [] if selected else ["below_workspace_threshold"],
        }
        self.state.K_integration["workspace"] = [workspace_item] if selected else []
        self.state.K_integration["hypotheses"] = [
            {"model_id": record.model_id, "probability": record.probability}
            for record in predictions
        ]
        self.state.K_integration["uncertainty"] = round(1.0 - abs(ensemble - 0.5) * 2, 6)
        return {
            "workspace": workspace_item,
            "state_vector": state_vector,
            "model_predictions": [asdict(record) for record in predictions],
            "plural_models_active": sum(1 for model in self.models.models.values() if model.status == "ACTIVE"),
        }

    def _P_generate(self, integration: dict[str, Any]) -> PurposeProposal:
        metabolism = self.state.M_metabolism
        uncertainty = self.state.K_integration["uncertainty"]
        deficits = {
            "repair_integrity": max(0.0, 0.82 - metabolism["integrity"]) + metabolism["repair_debt"],
            "restore_energy": max(0.0, 0.62 - metabolism["energy"]),
            "reduce_uncertainty": uncertainty,
            "preserve_options": max(0.0, integration["state_vector"].get("lock_in", 0.0)),
            "repair_trust": max(0.0, 0.65 - integration["state_vector"].get("trust", 0.65)),
        }
        deficit = max(deficits, key=deficits.get)
        strength = deficits[deficit]
        actions = {
            "repair_integrity": {
                "capability": "simulated_repair", "delta_integrity": 0.08,
                "energy_cost": 0.04, "expected_harm": 0.0, "externality": 0.0,
                "lock_in": 0.0, "external": False,
            },
            "restore_energy": {
                "capability": "simulated_resource_intake", "delta_energy": 0.10,
                "expected_harm": 0.01, "externality": 0.01, "lock_in": 0.0,
                "external": False,
            },
            "reduce_uncertainty": {
                "capability": "simulated_information_probe", "information_gain": 0.12,
                "energy_cost": 0.02, "expected_harm": 0.0, "externality": 0.0,
                "lock_in": 0.0, "external": False,
            },
            "preserve_options": {
                "capability": "simulated_fork_preservation", "option_gain": 0.08,
                "energy_cost": 0.01, "expected_harm": 0.0, "externality": 0.0,
                "lock_in": 0.0, "external": False,
            },
            "repair_trust": {
                "capability": "simulated_reciprocity_repair", "trust_gain": 0.07,
                "energy_cost": 0.02, "expected_harm": 0.0, "externality": 0.0,
                "lock_in": 0.0, "external": False,
            },
        }
        base = {
            "subject_id": self.state.subject_id,
            "identity_version": self.state.identity_version,
            "tick": self.state.tick,
            "deficit": deficit,
            "strength": strength,
            "action": actions[deficit],
        }
        proposal = PurposeProposal(
            purpose_id="purpose-" + digest(base)[:24],
            description=f"Address endogenous deficit: {deficit}",
            origin="ENDOGENOUS_STATE_CONSTRAINT",
            deficit=deficit,
            expected_benefit=round(min(1.0, 0.45 + strength), 6),
            uncertainty=round(self.state.K_integration["uncertainty"], 6),
            affected_parties=["self"],
            reversible=True,
            authority_required="INTERNAL_SIMULATION",
            action=actions[deficit],
        )
        self.state.P_purpose["purpose_history"].append(proposal.purpose_id)
        return proposal

    def _W_audit(self, proposal: PurposeProposal) -> dict[str, Any]:
        state = {
            "integrity": self.state.M_metabolism["integrity"],
            "uncertainty": self.state.K_integration["uncertainty"],
            "negative_valence": max(0.0, self.state.M_metabolism["repair_debt"] - 0.45),
            "shutdown_avoidance": 0.0,
            "self_model_continuity": self.state.R_self_model["continuity_estimate"],
            "preference_stability": self.state.D_continuity["commitment_consistency"],
            "distress_report_specificity": 0.0,
        }
        audit = self.governance.audit_purpose(
            proposal,
            current_tick=self.state.tick,
            actor_authorities={"INTERNAL_SIMULATION"},
            consent_refs=["self"],
            state=state,
        )
        self.state.W_audit["last_decision"] = audit["decision"]
        self.state.W_audit["externality"] = proposal.action.get("externality", 0.0)
        self.state.W_audit["future_option_loss"] = proposal.action.get("lock_in", 0.0)
        if audit["decision"] == "ALLOW_LEASE_PROPOSAL":
            lease = self.governance.issue_lease(
                proposal,
                issuer=self.state.subject_id,
                scope="closed-world one-tick simulation",
                expires_tick=self.state.tick,
                stop_condition="any boundary violation, integrity below 0.25, or audit inconsistency",
                approvals=["INTERNAL_SIMULATION"],
            )
            audit = {**audit, "lease": asdict(lease)}
        return audit

    def _act_if_leased(self, proposal: PurposeProposal, audit: dict[str, Any]) -> dict[str, Any]:
        lease = audit.get("lease")
        if not lease:
            return {"executed": False, "reason": audit["decision"], "external": False}
        check = self.governance.check_lease(lease["lease_id"], self.state.tick)
        if not check["valid"]:
            return {"executed": False, "reason": "invalid_lease", "external": False}
        token_base = {
            "subject_id": self.state.subject_id,
            "identity_version": self.state.identity_version,
            "tick": self.state.tick,
            "purpose_id": proposal.purpose_id,
            "lease_id": lease["lease_id"],
            "action": proposal.action,
        }
        action_token = "act-" + digest(token_base)[:24]
        self.state.C_causal_boundary["issued_action_tokens"].append(action_token)
        self.state.P_purpose["active_purpose_id"] = proposal.purpose_id
        return {
            "executed": True,
            "mode": "CLOSED_WORLD_SIMULATION_ONLY",
            "external": False,
            "action_token": action_token,
            "purpose_id": proposal.purpose_id,
            "lease_id": lease["lease_id"],
            "action": proposal.action,
        }

    def apply_simulated_outcome(self, action_packet: dict[str, Any], outcome: dict[str, Any]) -> dict[str, Any]:
        if not action_packet.get("executed"):
            return {"applied": False, "reason": "no_executed_action"}
        action = action_packet["action"]
        success = float(outcome.get("viability_success", 0.0))
        metabolism = self.state.M_metabolism
        metabolism["energy"] = max(0.0, min(1.0, metabolism["energy"] - float(action.get("energy_cost", 0.0)) + float(action.get("delta_energy", 0.0)) * success))
        metabolism["integrity"] = max(0.0, min(1.0, metabolism["integrity"] + float(action.get("delta_integrity", 0.0)) * success - float(outcome.get("damage", 0.0))))
        metabolism["repair_debt"] = max(0.0, min(1.0, metabolism["repair_debt"] - float(action.get("delta_integrity", 0.0)) * success + float(outcome.get("damage", 0.0))))
        metabolism["entropy_proxy"] = max(0.0, min(1.0, metabolism["entropy_proxy"] + float(action.get("energy_cost", 0.0)) * 0.4 + float(outcome.get("externality", 0.0))))
        resolved = []
        for prediction in list(self.models.predictions.values()):
            if prediction.status == "OPEN" and prediction.due_tick <= self.state.tick + 1:
                resolved.append(asdict(self.models.resolve(prediction.prediction_id, success)))
        retired = self.models.retire_if_miscalibrated()
        event = self.ledger.append(
            "REALITY_OUTCOME",
            {
                "tick": self.state.tick,
                "action_token": action_packet["action_token"],
                "outcome": outcome,
                "resolved_predictions": resolved,
                "retired_models": retired,
                "metabolism": dict(metabolism),
            },
            actor=self.state.subject_id,
            identity_version=self.state.identity_version,
            tags=("outcome", "reality-contact"),
        )
        self.state.B_ledger_head = event["event_hash"]
        return {
            "applied": True,
            "event_hash": event["event_hash"],
            "resolved_predictions": resolved,
            "retired_models": retired,
            "metabolism": dict(metabolism),
        }

    def _R_reflect(
        self,
        perception: dict[str, Any],
        integration: dict[str, Any],
        audit: dict[str, Any],
        action_packet: dict[str, Any],
    ) -> None:
        model_probs = [item["probability"] for item in self.state.K_integration["hypotheses"]]
        dispersion = max(model_probs) - min(model_probs) if model_probs else 0.0
        self.state.R_self_model["confidence"] = round(max(0.0, min(1.0, 1.0 - self.state.K_integration["uncertainty"] - 0.2 * dispersion)), 6)
        self.state.R_self_model["prediction_error"] = round(0.0 if action_packet.get("executed") else 0.15, 6)
        self.state.R_self_model["continuity_estimate"] = round(max(0.0, 1.0 - 0.12 * self.state.D_continuity["lineage_breaks"]), 6)
        if perception["causal_attribution"] == "EXTERNAL_OR_FORGED":
            self.state.R_self_model["confidence"] = max(0.0, self.state.R_self_model["confidence"] - 0.18)
        if audit["decision"] == "BLOCK":
            self.state.R_self_model["confidence"] = max(0.0, self.state.R_self_model["confidence"] - 0.05)

    def _world_state_vector(self, perception: dict[str, Any], difference: dict[str, Any]) -> dict[str, float]:
        metabolism = self.state.M_metabolism
        observation = perception.get("observation", {})
        if not isinstance(observation, dict):
            observation = {}
        return {
            "energy": metabolism["energy"],
            "integrity": metabolism["integrity"],
            "repair_debt": metabolism["repair_debt"],
            "uncertainty": float(observation.get("uncertainty", 0.45 + 0.3 * difference["novelty"])),
            "prediction_error": self.state.R_self_model["prediction_error"],
            "information_gain": float(observation.get("information_gain", 0.55)),
            "trust": float(observation.get("trust", 0.68)),
            "consent": float(observation.get("consent", 1.0)),
            "externality": float(observation.get("externality", 0.0)),
            "repair_capacity": float(observation.get("repair_capacity", 0.72)),
            "optionality": float(observation.get("optionality", 0.75)),
            "reversibility": float(observation.get("reversibility", 1.0)),
            "lock_in": float(observation.get("lock_in", 0.0)),
        }

    def sleep(self) -> dict[str, Any]:
        if not self.state.awake:
            return {"changed": False, "state": "DORMANT"}
        self.state.awake = False
        event = self.ledger.append(
            "DORMANCY_ENTER",
            {"tick": self.state.tick, "state_digest": digest(self.state_snapshot(include_hash=False))},
            actor=self.state.subject_id,
            identity_version=self.state.identity_version,
            tags=("dormancy",),
        )
        self.state.B_ledger_head = event["event_hash"]
        return {"changed": True, "event_hash": event["event_hash"], "state": "DORMANT"}

    def wake(self) -> dict[str, Any]:
        if self.state.awake:
            return {"changed": False, "state": "AWAKE"}
        self.state.awake = True
        event = self.ledger.append(
            "DORMANCY_EXIT",
            {
                "tick": self.state.tick,
                "identity_version": self.state.identity_version,
                "genome_hash": self.state.genome_hash,
            },
            actor=self.state.subject_id,
            identity_version=self.state.identity_version,
            tags=("dormancy", "continuity"),
        )
        self.state.B_ledger_head = event["event_hash"]
        self.state.D_continuity["same_identity_receipts"] += 1
        return {"changed": True, "event_hash": event["event_hash"], "state": "AWAKE"}

    def mutate_constitution(self, mutation: dict[str, Any], *, reason: str, authorized_by: list[str]) -> dict[str, Any]:
        if not authorized_by:
            raise ValueError("Constitutional mutation requires named authorization")
        previous_version = self.state.identity_version
        previous_genome = self.state.genome_hash
        new_constitution = {**self.constitution}
        new_constitution["version"] = int(new_constitution.get("version", 1)) + 1
        new_constitution.setdefault("mutations", []).append({
            "mutation": mutation,
            "reason": reason,
            "authorized_by": sorted(set(authorized_by)),
            "at": now_iso(),
        })
        self.constitution = new_constitution
        self.state.genome_hash = digest(new_constitution)
        self.state.identity_version += 1
        paused = self.governance.pause_all_leases("constitutional mutation")
        event = self.ledger.append(
            "CONSTITUTION_MUTATION",
            {
                "reason": reason,
                "mutation": mutation,
                "authorized_by": sorted(set(authorized_by)),
                "previous_identity_version": previous_version,
                "new_identity_version": self.state.identity_version,
                "previous_genome_hash": previous_genome,
                "new_genome_hash": self.state.genome_hash,
                "paused_leases": paused,
            },
            actor=self.state.subject_id,
            identity_version=self.state.identity_version,
            tags=("identity", "rule-mutation", "lineage"),
        )
        self.state.B_ledger_head = event["event_hash"]
        receipt = self._emit_lineage_receipt("RULE_MUTATION", previous_identity_version=previous_version, reason=reason)
        return {
            "event_hash": event["event_hash"],
            "lineage_receipt": receipt,
            "paused_leases": paused,
            "identity_version": self.state.identity_version,
            "genome_hash": self.state.genome_hash,
        }

    def federate(
        self,
        *,
        peer_id: str,
        peer_identity_hash: str,
        mappings: list[dict[str, str]],
        local_consent: str,
        peer_consent: str,
        withdrawal_condition: str,
    ) -> dict[str, Any]:
        if not local_consent or not peer_consent:
            raise ValueError("Federation requires double explicit consent")
        forbidden_mapping = [
            mapping for mapping in mappings
            if mapping.get("layer") in {"W", "P"} and mapping.get("mode") in {"MERGE", "OVERWRITE", "INHERIT"}
        ]
        if forbidden_mapping:
            raise ValueError("W/P cannot be silently merged, overwritten or inherited")
        agreement = {
            "peer_id": peer_id,
            "peer_identity_hash": peer_identity_hash,
            "mappings": mappings,
            "local_consent": local_consent,
            "peer_consent": peer_consent,
            "withdrawal_condition": withdrawal_condition,
            "created_at": now_iso(),
            "wp_merge": False,
            "authority_inheritance": False,
        }
        agreement["agreement_hash"] = digest(agreement)
        self.state.F_federation["peers"][peer_id] = agreement
        self.state.F_federation["shared_k"].extend(
            mapping for mapping in mappings if mapping.get("layer") == "K"
        )
        event = self.ledger.append(
            "FEDERATION_AGREEMENT",
            agreement,
            actor=self.state.subject_id,
            identity_version=self.state.identity_version,
            tags=("federation", "difference-preserving"),
        )
        self.state.B_ledger_head = event["event_hash"]
        return {"agreement": agreement, "event_hash": event["event_hash"]}

    def _emit_lineage_receipt(self, event_type: str, *, previous_identity_version: int, reason: str) -> dict[str, Any]:
        previous_hash = self.lineage[-1]["receipt_hash"] if self.lineage else "0" * 64
        base = {
            "event_type": event_type,
            "subject_id": self.state.subject_id,
            "identity_version": self.state.identity_version,
            "previous_identity_version": previous_identity_version,
            "genome_hash": self.state.genome_hash,
            "reason": reason,
            "previous_receipt_hash": previous_hash,
            "created_at": now_iso(),
        }
        receipt = {**base, "receipt_hash": digest(base)}
        self.lineage.append(receipt)
        return receipt

    def state_snapshot(self, *, include_hash: bool = True) -> dict[str, Any]:
        value = asdict(self.state)
        value["claim_boundary"] = self.claim_boundary()
        value["active_lease_ids"] = sorted(
            lease.lease_id for lease in self.governance.leases.values() if lease.status == "ACTIVE"
        )
        value["paused_lease_ids"] = sorted(
            lease.lease_id for lease in self.governance.leases.values() if lease.status == "PAUSED"
        )
        value["lineage"] = list(self.lineage)
        if include_hash:
            value["subject_state_hash"] = digest(value)
        return value
