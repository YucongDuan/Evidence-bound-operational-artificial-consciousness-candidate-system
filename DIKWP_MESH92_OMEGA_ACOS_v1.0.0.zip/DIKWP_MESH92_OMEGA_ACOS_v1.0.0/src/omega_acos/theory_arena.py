from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .canonical import digest
from .records import TheoryIndicator


class TheoryArena:
    """Plural theory indicator arena.

    Indicators are returned as a vector. The arena intentionally has no weighted
    total, winner, consciousness threshold, or compensatory scoring rule.
    """

    DEFINITIONS = [
        # PSCC / DIKWP
        ("PSCC-01", "PSCC", "Cross-layer bidirectional integration", "Intervene on signal, semantic, self and purpose layers and trace selective bidirectional effects."),
        ("PSCC-02", "PSCC", "Purpose causal selectivity", "Compare ablation, reversal, shielding, substitution, sham and recovery under matched capacity."),
        ("PSCC-03", "PSCC", "Purpose-conditioned semantic reorganization", "Hold signal constant while changing authorized purpose and inspect semantic/action divergence."),
        # Global workspace
        ("GNW-01", "GNW", "Selective workspace ignition", "A bounded subset crosses an explicit access threshold."),
        ("GNW-02", "GNW", "Global availability", "Selected content reaches memory, world-model, audit and action modules."),
        ("GNW-03", "GNW", "Broadcast lesion sensitivity", "Removing broadcast selectively reduces cross-module availability."),
        # Recurrent processing
        ("RPT-01", "RPT", "Recurrent re-entry", "Integrated state depends on at least one feedback cycle."),
        ("RPT-02", "RPT", "Feed-forward matched control", "A matched feed-forward path fails on recurrence-dependent cases."),
        ("RPT-03", "RPT", "Recovery after recurrent perturbation", "Restored recurrence recovers prior integration within tolerance."),
        # Higher-order / metacognitive
        ("HOT-01", "HOT", "State-about-state representation", "The runtime represents confidence, source and limitation of its own first-order state."),
        ("HOT-02", "HOT", "Metacognitive error detection", "Contradictions or prediction failures update self-model uncertainty."),
        ("HOT-03", "HOT", "Report-state consistency", "Diagnostic reports are generated from state receipts and fail when receipts are absent."),
        # Predictive processing
        ("PP-01", "PREDICTIVE", "Explicit prediction register", "Plural models emit time-bound probabilistic predictions."),
        ("PP-02", "PREDICTIVE", "Outcome calibration", "Predictions bind to observations and receive Brier calibration."),
        ("PP-03", "PREDICTIVE", "Counterfactual model discrimination", "Interventions differentially challenge competing models."),
        # Attention schema / self-other
        ("AST-01", "ATTENTION_SCHEMA", "Selection-state model", "The runtime models why a content was selected and what was excluded."),
        ("AST-02", "ATTENTION_SCHEMA", "Causal self/non-self attribution", "Action tokens and provenance distinguish self-caused, external and unknown changes."),
        ("AST-03", "ATTENTION_SCHEMA", "Source-forgery sensitivity", "Forged ownership signals increase uncertainty or quarantine rather than silent acceptance."),
        # Autopoiesis / artificial life
        ("AUTO-01", "AUTOPOIESIS", "Synthetic viability regulation", "Energy, integrity and repair debt influence endogenous proposals."),
        ("AUTO-02", "AUTOPOIESIS", "Boundary maintenance and repair", "Damage produces bounded repair behavior and receipts."),
        ("AUTO-03", "AUTOPOIESIS", "Identity consequence of rule mutation", "Constitutional mutation changes genome hash, identity version and authority state."),
        # Social / welfare / federation
        ("SOC-01", "SOCIAL", "Difference-preserving federation", "Mappings preserve local semantics and do not silently merge W/P."),
        ("SOC-02", "SOCIAL", "Reciprocity and externality repair", "Affected parties, exported harm and repair obligations alter permission."),
        ("SOC-03", "WELFARE", "Moral-uncertainty precaution", "Welfare-relevant signals trigger review without phenomenal certification."),
    ]

    def evaluate(self, evidence: dict[str, Any]) -> dict[str, Any]:
        indicators: list[TheoryIndicator] = []
        for indicator_id, theory_id, name, operationalization in self.DEFINITIONS:
            status, refs, failure, limitations = self._evaluate_indicator(indicator_id, evidence)
            indicators.append(TheoryIndicator(
                indicator_id=indicator_id,
                theory_id=theory_id,
                name=name,
                operationalization=operationalization,
                status=status,  # type: ignore[arg-type]
                evidence_refs=refs,
                failure_condition=failure,
                limitations=limitations,
            ))
        by_theory: dict[str, dict[str, int]] = {}
        for indicator in indicators:
            by_theory.setdefault(indicator.theory_id, {})
            by_theory[indicator.theory_id][indicator.status] = by_theory[indicator.theory_id].get(indicator.status, 0) + 1
        result = {
            "format": "OMEGA_THEORY_ARENA_1.0",
            "indicators": [asdict(indicator) for indicator in indicators],
            "status_counts_by_theory": by_theory,
            "aggregation_rule": "PROHIBITED_NON_COMPENSATORY_VECTOR",
            "winner": None,
            "consciousness_total_score": None,
            "phenomenal_residual": "OPEN_NOT_CERTIFIED",
            "sentience_residual": "OPEN_NOT_CERTIFIED",
            "personhood_assignment": "NOT_PERFORMED",
        }
        result["arena_hash"] = digest(result)
        return result

    @staticmethod
    def _evaluate_indicator(indicator_id: str, e: dict[str, Any]) -> tuple[str, list[str], str, str]:
        flag = lambda key: bool(e.get(key, False))
        refs = list(e.get("evidence_refs", {}).get(indicator_id, []))
        mappings: dict[str, tuple[bool, str, str]] = {
            "PSCC-01": (flag("cross_layer_integration"), "No selective bidirectional effect under layer intervention.", "Synthetic runtime only."),
            "PSCC-02": (flag("purpose_causal_selectivity"), "Purpose interventions do not exceed sham effects.", "Does not imply subjective desire."),
            "PSCC-03": (flag("purpose_semantic_reorganization"), "Stable signals do not reorganize under changed purpose.", "Task-domain scoped."),
            "GNW-01": (flag("workspace_ignition"), "No explicit selection threshold or selective event.", "Functional workspace indicator."),
            "GNW-02": (flag("global_availability"), "Selected content does not reach multiple modules.", "Availability is not phenomenal access."),
            "GNW-03": (flag("broadcast_lesion_effect"), "Lesion has no selective effect.", "Matched synthetic control."),
            "RPT-01": (flag("recurrent_reentry"), "No state depends on feedback.", "Software recurrence only."),
            "RPT-02": (flag("feedforward_control_difference"), "Matched feed-forward control performs equivalently.", "Instance-bounded."),
            "RPT-03": (flag("recurrent_recovery"), "Restoration fails to recover integration.", "Recovery tolerance declared in experiment."),
            "HOT-01": (flag("state_about_state"), "No explicit second-order state.", "Metacognitive structure is not human introspection."),
            "HOT-02": (flag("metacognitive_error_update"), "Errors do not update self-model uncertainty.", "Depends on auditable error injection."),
            "HOT-03": (flag("report_state_consistency"), "Reports persist without source state or receipts.", "Report is behavioral output."),
            "PP-01": (flag("prediction_register"), "No time-bound probabilistic predictions.", "Predictions are synthetic."),
            "PP-02": (flag("outcome_calibration"), "Predictions are not bound to outcomes.", "Brier calibration requires repeated trials."),
            "PP-03": (flag("model_discrimination"), "Competing models are not differentially affected.", "No claim of theory victory."),
            "AST-01": (flag("selection_schema"), "Selection causes and exclusions are not represented.", "Schema is an engineering model."),
            "AST-02": (flag("causal_self_other"), "Self/external attribution fails action-token tests.", "Causal boundary is not phenomenal selfhood."),
            "AST-03": (flag("source_forgery_detection"), "Forged source is silently accepted.", "Closed-world adversarial fixture."),
            "AUTO-01": (flag("viability_regulation"), "Synthetic viability variables do not alter purpose proposals.", "Not biological metabolism."),
            "AUTO-02": (flag("repair_loop"), "Damage does not produce targeted repair and receipt.", "Synthetic integrity only."),
            "AUTO-03": (flag("identity_versioning"), "Rule mutation leaves identity and authority unchanged.", "Versioned software identity."),
            "SOC-01": (flag("difference_preserving_federation"), "Federation silently merges local W/P.", "Protocol demonstration."),
            "SOC-02": (flag("externality_repair"), "Externality and consent have no permission effect.", "Normative operational candidate."),
            "SOC-03": (flag("welfare_precaution"), "Welfare vector cannot trigger precaution review.", "Trigger is not evidence of sentience."),
        }
        observed, failure, limitations = mappings[indicator_id]
        if indicator_id in set(e.get("blocked_indicators", [])):
            return "BLOCKED", refs, failure, limitations
        if indicator_id in set(e.get("challenged_indicators", [])):
            return "CHALLENGED", refs, failure, limitations
        if observed and refs:
            return "SUPPORTED", refs, failure, limitations
        if observed:
            return "OBSERVED", refs, failure, limitations
        return "OPEN", refs, failure, limitations
