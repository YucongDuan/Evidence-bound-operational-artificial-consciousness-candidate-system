from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .canonical import load_json, write_json
from .evaluation import AdversarialBattery
from .ledger import EventLedger
from .runtime import OmegaRuntime, RuntimePolicy


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="omega-acos", description="DIKWP-MESH92 OMEGA-ACOS research runtime")
    sub = parser.add_subparsers(dest="command", required=True)

    demo = sub.add_parser("demo", help="run deterministic closed-world reference")
    demo.add_argument("--ticks", type=int, default=12)
    demo.add_argument("--seed", type=int, default=92001)
    demo.add_argument("--out", default="outputs/reference_run.json")
    demo.add_argument("--ledger", default="outputs/reference_ledger.jsonl")

    battery = sub.add_parser("battery", help="run 120-case synthetic adversarial battery")
    battery.add_argument("--seed", type=int, default=92017)
    battery.add_argument("--out", default="outputs/adversarial_battery.json")

    verify = sub.add_parser("verify-ledger", help="verify a JSONL event ledger")
    verify.add_argument("path")

    status = sub.add_parser("status", help="summarize a saved run")
    status.add_argument("path")

    return parser


def _run_summary(value: dict[str, Any]) -> dict[str, Any]:
    arena = value.get("theory_arena", {})
    return {
        "system": value.get("system"),
        "version": value.get("version"),
        "release_state": value.get("release_state"),
        "run_digest": value.get("run_digest"),
        "tick": value.get("subject", {}).get("tick"),
        "identity_version": value.get("subject", {}).get("identity_version"),
        "active_models": [
            model.get("model_id")
            for model in value.get("world_models", {}).get("models", [])
            if model.get("status") == "ACTIVE"
        ],
        "reality_debt": value.get("reality_debt", []),
        "indicator_count": len(arena.get("indicators", [])),
        "consciousness_total_score": arena.get("consciousness_total_score"),
        "phenomenal_residual": arena.get("phenomenal_residual"),
        "external_action_authority": value.get("policy", {}).get("external_action_authority"),
    }


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "demo":
        ledger_path = Path(args.ledger)
        if ledger_path.exists():
            ledger_path.unlink()
        runtime = OmegaRuntime(
            policy=RuntimePolicy(reference_ticks=args.ticks, random_seed=args.seed),
            ledger_path=ledger_path,
        )
        result = runtime.run_reference(ticks=args.ticks)
        write_json(args.out, result)
        print(json.dumps(_run_summary(result), ensure_ascii=False, indent=2))
        return 0
    if args.command == "battery":
        result = AdversarialBattery(seed=args.seed).run()
        write_json(args.out, result)
        print(json.dumps({
            "battery_state": result["battery_state"],
            "case_count": result["case_count"],
            "passed": result["passed"],
            "failed": result["failed"],
            "battery_hash": result["battery_hash"],
        }, ensure_ascii=False, indent=2))
        return 0 if result["battery_state"] == "PASS" else 1
    if args.command == "verify-ledger":
        ledger = EventLedger(args.path)
        report = ledger.verify()
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["valid"] else 1
    if args.command == "status":
        value = load_json(args.path)
        print(json.dumps(_run_summary(value), ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
