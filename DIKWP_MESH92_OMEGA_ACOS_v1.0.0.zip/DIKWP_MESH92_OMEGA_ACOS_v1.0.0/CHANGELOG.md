# Changelog

## 1.0.0 — 2026-08-24

- First integrated OMEGA-ACOS research release.
- Five-role single-process DIKWP subject kernel.
- Reconstructive, conflict-aware, revocable memory vault.
- Plural world-model ensemble with calibration and retirement.
- Purpose causality laboratory with ablation, reversal, sham, shielding, and recovery.
- Identity versioning and capability-lease pause on constitutional mutation.
- Difference-preserving federation with double explicit consent.
- CMOP-style theory, variable, experiment, evidence, fidelity, and claim cards.
- Non-aggregated 24-indicator theory arena.
- 120-case synthetic adversarial conformance battery.
- Hash-chained event, memory, experiment, lineage, and causal-handoff receipts.
- Offline dashboard, release verifier, SBOM, and static boundary audit.
