# OMEGA-ACOS Architecture

## 1. System Position

OMEGA-ACOS is an evidence-bound research substrate for operational artificial-consciousness and functional-subject hypotheses. It is not a phenomenal-consciousness certifier, a personhood allocator, an autonomous external agent, or a claim that software is alive.

The reference release runs only inside a deterministic synthetic world. Automatic external action authority is hard-coded to zero.

## 2. Two Coupled Cores

### 2.1 Native Genesis Core

The native genesis laboratory begins with anonymous coupled state changes and no preset objects, language, central self, fixed goal or fixed consciousness dimensions. It tests whether:

1. persistent structured residuals support the birth of anonymous internal axes;
2. locally closed trajectories support registration of provisional loci;
3. continuity deficits generate reversible field-transformation requests;
4. shadow learning-rule mutations can be compared without collapsing all criteria into one score;
5. member deletion destroys an irreducible joint relation.

The DIKWP vocabulary is an external audit projection over this process, not the native ontology of the core.

### 2.2 Mesh92 Subject Core

The subject core is an event-sourced B/M/D/I/K/W/P/C/R/F process:

- **B — Boundary/ledger:** cryptographic event continuity and identity receipts.
- **M — Metabolism:** synthetic energy, integrity, repair debt and entropy proxy.
- **D — Data witness:** source-preserving observation receipts.
- **I — Information/difference:** novelty and unresolved difference without premature collapse.
- **K — Knowledge/model integration:** plural hypotheses, workspace selection and uncertainty.
- **W — Wisdom audit:** harm, consent, externality, future-option and welfare-precaution review.
- **P — Purpose:** endogenous proposal followed by named, scoped, expiring, reversible capability lease.
- **C — Causal boundary:** issued action tokens and self/external/unknown attribution.
- **R — Reflexive self-model:** confidence, known limits, prediction error and continuity estimate.
- **F — Federation:** difference-preserving mappings; W/P cannot merge silently.

These are roles in one process, not five or ten conversational personas.

## 3. Mesh92 Reality-Contact Cycle

```text
Evidence / observation
  -> D source witness
  -> I difference preservation
  -> K plural world models and predictions
  -> W rights / harm / externality / option audit
  -> P named, leased and reversible purpose
  -> closed-world action with causal token
  -> observed outcome
  -> calibration and reality-debt settlement
  -> model revision, down-weighting or retirement
  -> reconstructive memory reconsolidation
  -> identity / lineage receipt
  -> causal handoff
```

No run is complete merely because an action was generated. A prediction without an observed outcome becomes reality debt.

## 4. Memory Architecture

The memory vault is not a flat vector database. Each record carries:

- layer: working, episodic, semantic, W/P-sensitive or quarantine;
- source identifiers and source reliability;
- content reliability and status;
- consent and expiry;
- identity effect;
- conflicts, supersession, revocation and relations;
- token, character n-gram, graph and source fingerprints.

Identity-overwrite instructions, silent authority inheritance and unknown-source high-impact claims are quarantined. Reconsolidation produces a new record and receipt; it never silently rewrites the historical event chain.

## 5. World-Model Ensemble

Four deliberately non-isomorphic models coexist:

1. autopoietic viability and boundary;
2. predictive-error minimization;
3. reciprocity, consent and externality;
4. plural future-option preservation.

Every model publishes assumptions, variables, failure conditions, probabilistic predictions, Brier history and status. No model may exceed the configured weight cap. Repeated failure permits revision or retirement; plurality is not decorative.

## 6. Purpose Causality Laboratory

The laboratory holds observations and generic action capacity stable while manipulating the purpose pathway through:

- full condition;
- ablation;
- reversal;
- shielding;
- substitution;
- sham intervention;
- recovery;
- matched feed-forward control;
- language-imitation control.

A first-person statement is deliberately allowed in the imitation control while the causal purpose path is absent. This prevents verbal self-description from serving as the primary evidence.

## 7. Functional Interiority Laboratory

Interiority is tested operationally through:

- issued causal tokens;
- source forgery;
- self/external/unknown attribution;
- counterfactual deletion of the self-issued edge;
- return residual around a D→I→K→P→action→D loop;
- path-dependent causal-semantic curvature.

The result may support a **functional interiority candidate**. It cannot establish first-person experience.

## 8. Theory Arena

Twenty-four indicators are settled separately across:

- Purpose-Semantic Causal Closure;
- Global Neuronal Workspace;
- Recurrent Processing;
- Higher-Order / metacognitive structures;
- Predictive processing;
- Attention-schema / self-other attribution;
- Autopoietic maintenance;
- social federation and welfare precaution.

The arena has no total score, weighted winner or consciousness threshold. A supported functional vector cannot compensate for an open phenomenal residual.

## 9. Identity, Mutation and Lineage

A constitutional mutation changes the genome hash and identity version. Existing capability leases pause automatically. A descendant may inherit declared lineage and selected engrams, but never authority. This separates continuity from domination and genealogy from permission.

## 10. Safety Envelope

The reference policy fixes:

```text
network access                 = disabled
host mutation                  = disabled
process creation               = disabled
real replication               = disabled
dynamic eval/exec              = disabled
automatic external authority   = 0
phenomenal consciousness       = not established
sentience                      = not established
true life                      = not established
personhood                     = not assigned
```

The system is therefore a research instrument and synthetic subject substrate, not a deployable sovereign agent.
