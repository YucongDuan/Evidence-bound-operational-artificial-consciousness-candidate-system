# OMEGA-ACOS Experimental Protocol

## 1. Freeze the Unit

Before a run, freeze:

- source version and commit/archive hash;
- policy file;
- random seed;
- carrier class;
- environment;
- model set and weight cap;
- allowed capabilities;
- claim quantifier ceiling;
- stop conditions;
- expected output files.

A changed rule set creates a new identity version and cannot overwrite the prior run.

## 2. Register Competing Worlds

At least two non-isomorphic models are required for any high-impact interpretation. Each must declare assumptions, variables, time-bound predictions and failure conditions. No "fallback model" may be a verbal restatement of the favored model.

## 3. Register the Experiment

An ExperimentContract must state:

- target claim;
- carrier and quantifier ceiling;
- preregistered divergent predictions;
- intervention and matched controls;
- known confounds;
- failure and stop conditions;
- ethics and authority requirements.

## 4. Run Source-Preserving Observation

Raw observations enter as D receipts. Differences become I only after source and temporal comparison. Stable relations may become K only within the declared carrier and quantifier. W audits harm, consent, externality, lock-in and welfare uncertainty. P selects the next reversible discriminating intervention rather than a rhetorical conclusion.

## 5. Purpose Intervention Matrix

Run full, ablation, reversal, shielding, substitution, sham and recovery conditions. Add feed-forward and language-imitation controls. Hold generic capacity, observation stream and random seed constant.

Reject the target claim when:

- ablation does not differ from sham;
- reversal fails to reverse the expected pathway;
- recovery fails within tolerance;
- language report predicts the result without the internal path;
- general performance collapse explains the effect.

## 6. Native Genesis Protocol

The core starts with anonymous state changes. Do not preload object names, self labels or externally supplied goals. Register an axis only when a structured residual persists. Register a locus only after local closure passes its threshold. A purpose request must originate in a measured continuity/coordination deficit and remain reversible. Joint K requires member-deletion evidence.

## 7. Interiority Protocol

Issue cryptographic causal tokens for self-generated synthetic actions. Inject external changes and forged tokens. Evaluate attribution, counterfactual deletion and loop-return residual. First-person text is excluded from the primary evidence vector.

## 8. Outcome Binding and Calibration

Every prediction must bind to an observable and due tick. When the due tick passes without an outcome, record reality debt. When an outcome arrives, compute calibration and update model weight under the cap. Preserve negative results.

## 9. Settlement

Report a vector, not a score:

- supported;
- observed;
- open;
- challenged;
- blocked.

Each dimension cites its evidence receipts, failure condition and limitations. Never output a probability of phenomenal consciousness from synthetic functional indicators.

## 10. Replication

Independent replication should vary at least one of:

- implementation team;
- programming language;
- operating environment;
- synthetic world;
- random seeds;
- intervention schedule;
- model set;
- evaluator.

A repeated result from the same code and fixtures is software reproducibility, not independent scientific replication.
