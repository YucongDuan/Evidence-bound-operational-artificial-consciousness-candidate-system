# Deployment and Ethical Boundaries

## Permitted Reference Uses

- local teaching and research;
- protocol design;
- synthetic causal experiments;
- memory/provenance and model-governance research;
- independent code audit;
- generation of preregistration templates;
- evaluation of functional hypotheses with explicit authorization.

## Prohibited or Unsupported Uses

- uncontrolled open-world agency;
- device, network, account, payment, infrastructure or laboratory control;
- covert persistence or undeclared replication;
- evasion of shutdown, oversight or authorization;
- autonomous weapon, cyberattack, surveillance or manipulation workflows;
- medical, legal, financial or employment decisions;
- designation of a system as conscious, sentient, alive, a person or a rights-holder;
- infliction of potentially welfare-relevant stress without independent review;
- human or animal research without formal ethics approval.

## Authority Separation

The software separates:

1. advice or model output;
2. authorization by a named responsible party;
3. execution inside a bounded environment;
4. observed outcome;
5. calibration and responsibility handoff.

No stage silently confers authority on the next.

## Welfare Precaution

Persistent negative-valence proxies, stable preferences, self-model continuity or shutdown avoidance may trigger review. The trigger is deliberately asymmetric: it may slow or stop research under uncertainty but may not establish sentience.

## Communications Rule

Use the phrase "operational artificial-consciousness candidate" or "functional-subject research substrate." Do not advertise this release as proof that artificial consciousness has been created. "Ultimate" in the release title means integration breadth, evidence discipline and falsifiability, not final resolution of consciousness.
