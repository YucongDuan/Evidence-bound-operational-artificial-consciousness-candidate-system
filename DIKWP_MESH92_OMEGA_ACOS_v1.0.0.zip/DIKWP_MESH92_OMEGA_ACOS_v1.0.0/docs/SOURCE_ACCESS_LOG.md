# Source Access Log

Access date: 2026-08-24

## User-Supplied Source

- `DIKWP_MESH92(2).zip` — inspected locally, including source code and the Mesh92 closure structure. This attachment is the highest-confidence implementation source for the requested default mode.

## Public GitHub Materials

The public profile and visible repository README/metadata were inspected for:

- YucongDuan GitHub profile;
- MINDPORT;
- LIBERGENESIS;
- NEGENESIS-OMEGA;
- SILICON-COMMONS-86.

Several recent repositories expose a README, license and bundled ZIP. The bundled ZIP internals were not independently downloaded and audited in this environment. Consequently, this release implements visible public principles but does not claim byte-level verification, equivalence or inheritance from those packages.

## Public ResearchGate Materials

Readable public full text, page extraction, abstract, figures or profile metadata were inspected for:

- DIKWP Artificial Consciousness Theory: Design and Simulation (2024);
- DIKWP-AC v0.9 attachment evaluation;
- DIKWP-CMOP v1.1, *From Consciousness-Theory Claims to Falsifiable Evidence*;
- DIKWP-CONSCOPE 6.4A;
- DIKWP-ORIGIN 6.4A;
- DIKWP-MESH 8.0 Binary Autopoietic Semantic Subject Kernel (BASSK);
- OPENBECOMING84 / identity-free trajectory generation;
- Concept–Semantic Bidirectional Association and Regeneration;
- NOESISCOPE dynamic consciousness-evidence evaluation;
- INTERIORITY 5.9 as surfaced through the author profile and related public figures.

A stable direct publication URL for INTERIORITY 5.9 was not resolved during this research pass. OMEGA-ACOS therefore treats the profile-visible claims only as a design signal, not as a fully audited specification.

ResearchGate items are author-side technical reports or preprints unless their publication page states otherwise. Their presence on ResearchGate does not imply peer review, independent replication or acceptance by consciousness science.

## External Primary Sources

- Butlin et al., *Consciousness in Artificial Intelligence: Insights from the Science of Consciousness*, arXiv:2308.08708.
- Cogitate Consortium et al., *Adversarial testing of global neuronal workspace and integrated information theories of consciousness*, Nature 642, 133–142 (2025).
- Long et al., *Taking AI Welfare Seriously*, arXiv:2411.00986.
- Butlin & Lappas, *Principles for Responsible AI Consciousness Research*, arXiv:2501.07290 / JAIR lineage.
- W3C PROV-O and PROV-DM recommendations.
- NIST AI Risk Management Framework.

## Known Evidence Gaps

1. No independent laboratory has replicated OMEGA-ACOS.
2. No biological, clinical or real deployed-AI carrier was evaluated.
3. No result establishes subjective experience, sentience, personhood or true life.
4. Native-genesis, purpose-causality and interiority laboratories are simplified deterministic fixtures.
5. The software has not undergone third-party security audit, formal verification or red-team evaluation outside this build environment.
6. Public GitHub bundled archives and all ResearchGate attachments were not exhaustively audited at byte level.
