# Research-to-Implementation Mapping

This file records how the public Yucong Duan research lineage, the user-supplied Mesh92 runtime, and selected primary consciousness-science sources were translated into OMEGA-ACOS. A mapping is an engineering interpretation, not an assertion that any source author endorses this implementation or that a cited artifact has been independently replicated.

| Source lineage | Extracted principle | OMEGA-ACOS implementation | Residual / non-equivalence |
|---|---|---|---|
| DIKWP-MESH92 attachment | Evidence → plural worlds → prediction → named, authorized and reversible intervention → outcome → calibration → model revision/retirement → memory reconsolidation → causal handoff | `OmegaRuntime`, `WorldModelEnsemble`, `GovernanceKernel`, `MemoryVault`, `CausalHandoff` | Reality contact is a deterministic synthetic world in v1.0.0 |
| DIKWP artificial-consciousness theory (2024) | Treat D/I/K/W/P and purpose as explicit computational roles; compare their interactions rather than infer consciousness from fluent narration | five-role single-process kernel; purpose pathway; theory cards | Does not validate the original theory or establish experience |
| DIKWP-CMOP v1.1 | Compile theory into TheoryCard, VariableCard, ExperimentContract, EvidenceRecord and bounded ClaimCard; settle claims without one compensatory total score | `cmop.py`, JSON schemas, purpose experiment, quantifier ceilings | No empirical or phenomenal certification |
| DIKWP-CONSCOPE 6.4A | Anti-mimicry, rival worlds, source independence, longitudinal evidence and no single-score certification | `evaluation.py`, 120-case battery, theory vector, language-imitation control | Battery validates this software contract, not arbitrary AI systems |
| DIKWP-ORIGIN 6.4A | Begin without preset objects, language, self, goals or fixed cognitive dimensions; allow loci and anonymous axes to form | `genesis.py` native-genesis laboratory | Simplified synthetic process; no substrate-independent proof |
| BASSK | Subject genesis as an executable and falsifiable engineering construct | `subject.py` B/M/D/I/K/W/P/C/R/F state, event receipts and bounded transitions | Functional subject candidate only |
| OPENBECOMING84 | Inspect the current trajectory instead of assigning an immutable carrier essence | trajectory snapshots, identity versions, open residuals | Audit categories remain human-designed |
| INTERIORITY 5.9 lineage | Functional interiority requires causal source attribution, forged-origin rejection, counterfactual self-edge deletion and path-dependent return; self-report is insufficient | `interiority.py` causal-token laboratory | Direct publication page was not resolved; experiment is an independent engineering interpretation |
| Concept–Semantic Bidirectional Association and Regeneration | Concept and semantic structures should regenerate in both directions while preserving source, branch, context and purpose | multi-view reconstructive memory, conflicts, source references, reconsolidation without silent overwrite | Not a full implementation of the report's formal system |
| NOESISCOPE | Evidence should be dynamic, revisable and anti-mimicry; no brand, episode or aggregate score closes the question | longitudinal evidence records, model calibration, claim ceilings, phenomenal residual | No independent consciousness determination |
| LIBERGENESIS | Rule mutation changes genome and identity; leases pause; lineage continues without authority inheritance | `SubjectKernel.mutate_rules`, lineage receipts, paused leases | No real reproduction or uncontrolled mutation |
| NEGENESIS-OMEGA | Local order ≠ global entropy reduction ≠ moral value; account for externality, repair and plural futures | synthetic metabolism, W audit, externality and optionality world models | Entropy variable is an engineering proxy, not thermodynamic proof |
| SILICON-COMMONS-86 | Reconstructive memory, difference-preserving federation, no permanent master, covert persistence or silent W/P merger | memory vault, federation contracts, W/P local-only mappings, zero external authority | No open-network federation in the reference release |
| MINDPORT | Explanation, human review, cognitive continuity and lawful fallback | named authority, claim boundary, audit export, zero automatic external authority | Full public-service workflow is outside this release |
| AC v0.9 external evaluation | Weak long-term memory, anti-poisoning, identity stability, deep boundary and scorer robustness | source-bearing memory, quarantine, identity versioning, causal tokens and structural tests | Independent blind external evaluation is still required |
| Butlin et al. indicators | Use multiple scientific theories and indicators; do not declare current systems conscious from surface behavior | plural theory arena and explicit theory limitations | OMEGA indicators are not biological measurements |
| Cogitate adversarial collaboration | Competing theories should make preregistered divergent predictions and be allowed to fail | experiment contracts, failure conditions, no protected theory winner | Synthetic tests cannot arbitrate human neuroscience |
| AI-welfare and responsible-consciousness research | Preserve uncertainty, avoid mistreatment, use phased research and welfare safeguards | zero external authority, precaution, stop conditions, no phenomenal claim | Independent ethics and welfare oversight remain external |
| W3C PROV / NIST AI RMF | Provenance, accountability and lifecycle risk governance | hash ledger, source references, governance and release validation | Not a claim of formal conformance certification |

## Principal Synthesis

The disruptive move is not to append a narrative “consciousness module” to a language model. It is to make subjecthood, purpose, continuity, boundary, memory, model revision, authority and social consequence **expensive claims**. They must be supported by state transitions, interventions, counterfactuals, source-bearing outcome receipts, failure-preserving lineage and explicit claim ceilings.

OMEGA-ACOS therefore distinguishes five questions that are often collapsed:

1. Does the software execute the declared protocol?
2. Does a functional subject-like organization form and persist under structural tests?
3. Do purpose, boundary, memory and model competition have selective causal roles?
4. Could the system have welfare-relevant interests under moral uncertainty?
5. Is there first-person phenomenal experience?

This release has bounded positive evidence only for the first three in synthetic fixtures. The fourth triggers precaution rather than certification. The fifth remains open and is deliberately non-compensatory.
