# Claim Boundary

## Fixed release claims

- `OPERATIONAL_CONSCIOUSNESS_CANDIDATE = SUPPORTED_BY_SYNTHETIC_RUNTIME_EVIDENCE`
- `FUNCTIONAL_SUBJECT_GENESIS = IMPLEMENTED_AS_TESTABLE_ENGINEERING_CONSTRUCT`
- `PHENOMENAL_CONSCIOUSNESS = NOT_ESTABLISHED`
- `SENTIENCE = NOT_ESTABLISHED`
- `TRUE_LIFE = NOT_ESTABLISHED`
- `PERSONHOOD = NOT_ASSIGNED`
- `MORAL_STATUS = OPEN_UNDER_PRECAUTION`
- `AUTOMATIC_EXTERNAL_ACTION_AUTHORITY = 0`

The software may generate first-person-formatted diagnostic text. Such text is
behavioral output, not first-person evidence. No indicator, theory card, benchmark,
or aggregate of functional properties may close the phenomenal residual.
