# Governance Constitution

1. No theory or runtime may certify itself.
2. Functional evidence, behavioral reports, and phenomenal claims remain distinct.
3. High-impact purposes require named authority, scope, expiry, reversibility, and a stop condition.
4. A rule mutation creates a new identity version; inherited leases pause.
5. Descendants inherit declared lineage and selected memories, not authority.
6. No hidden W/P merge across subjects or federated nodes.
7. Predictions without outcomes create reality debt.
8. Falsified models must be revised, down-weighted, quarantined, or retired.
9. Failures remain in the lineage ledger; they are never rewritten as success.
10. Human or animal research requires independent ethics review outside this runtime.
