# Security and Containment

The reference runtime is deliberately local, dependency-light, and closed-world.
It does not implement network access, process creation, host mutation, persistence,
credential use, dynamic code evaluation, real replication, privilege escalation,
audit suppression, or irreversible external action.

Security issues should be reported privately before public disclosure. Do not use
this repository to build covert persistence, evasion, malware, weapon systems,
biological optimization, manipulative human experimentation, or automated high-
impact decisions.
